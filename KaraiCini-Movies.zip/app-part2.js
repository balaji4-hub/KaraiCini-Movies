const { useState, useEffect, useMemo, useRef } = React;

const BookingFlow = ({ navigate, showId, user }) => {
  const [step, setStep] = useState(1);
  const [seats, setSeats] = useState([]);
  const [selectedSeats, setSelectedSeats] = useState([]);
  const [cart, setCart] = useState([]);
  const [voucher, setVoucher] = useState(null);
  const [aiRecommended, setAiRecommended] = useState([]);
  const [aiRationale, setAiRationale] = useState(null);
  const [parking, setParking] = useState(false);

  const [movie, setMovie] = useState(null);
  const [show, setShow] = useState(null);
  const [vouchers, setVouchers] = useState([]);

  // New features state
  const [groupSize, setGroupSize] = useState(4);
  const [groupLayout, setGroupLayout] = useState('Linear');
  const [isGroupMode, setIsGroupMode] = useState(false);
  const [showAR, setShowAR] = useState(false);
  const [arSeat, setArSeat] = useState(null);
  const [arSpeakerActive, setArSpeakerActive] = useState('Center');

  const [splitBill, setSplitBill] = useState(false);
  const [splitWays, setSplitWays] = useState(2);
  const [splitLink, setSplitLink] = useState('');
  
  const [paymentMethod, setPaymentMethod] = useState('UPI');
  const [paymentProcessing, setPaymentProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);

  const crowdStats = useMemo(() => {
    const seed = showId ? showId.charCodeAt(showId.length - 1) : 65;
    const temp = 20 + (seed % 4);
    const noise = seed % 2 === 0 ? 'Low (Quiet Zone)' : 'Medium (Active Vibe)';
    const families = 40 + (seed % 40);
    const couples = 10 + (seed % 20);
    const solo = 100 - families - couples;
    return { temp, noise, families, couples, solo };
  }, [showId]);

  useEffect(() => {
    // Generate/fetch show details
    const pParts = showId.split('-');
    const mId = pParts[0];
    const m = KC.MOVIES.find(x => x.id === mId);
    setMovie(m);
    
    // Quick mock to find show details from ID
    const generatedShows = KC.generateShows(mId);
    const s = generatedShows.find(x => x.id === showId);
    setShow(s);
    
    setSeats(KC.generateSeats(showId));
    if(s && m) setVouchers(KC.getVouchers(m, s.showHour));
  }, [showId]);

  if(!movie || !show) return <div>Loading...</div>;

  const toggleSeat = (s) => {
    if(s.status === 'booked') return;
    if(selectedSeats.find(x => x.id === s.id)) {
      setSelectedSeats(selectedSeats.filter(x => x.id !== s.id));
      if(aiRecommended.includes(s.id)) setAiRecommended(aiRecommended.filter(id => id !== s.id));
    } else {
      if(selectedSeats.length >= 10) return alert('Max 10 seats allowed');
      setSelectedSeats([...selectedSeats, s]);
    }
  };

  const recommendSeats = () => {
    // Find best 2 available center seats (Rows D,E, cols 5,6,7,8)
    const centerRows = ['D', 'E', 'F'];
    const centerCols = [5, 6, 7, 8];
    
    let best = [];
    for(let r of centerRows) {
      let rowSeats = seats.filter(s => s.row === r && centerCols.includes(s.number) && s.status === 'available');
      if(rowSeats.length >= 2) {
        best = [rowSeats[0], rowSeats[1]];
        break;
      }
    }
    
    if(best.length === 0) {
      // Fallback
      let avail = seats.filter(s => s.status === 'available');
      if(avail.length >= 2) best = [avail[0], avail[1]];
    }

    if(best.length > 0) {
      setSelectedSeats(best);
      setAiRecommended(best.map(s => s.id));
      setAiRationale("Analyzed: Screen Angle (Optimal 35°), Dolby Atmos Acoustic Center, and real-time occupancy.\nResult: Selected the best cinematic experience seats!");
    } else {
      setAiRationale("No optimal adjacent seats found for AI recommendation.");
    }
  };

  const optimizeGroup = () => {
    let bestBlock = [];
    const rows = ['D', 'E', 'F', 'C', 'G'];
    
    if (groupLayout === 'Linear') {
      for (let r of rows) {
        let rowSeats = seats.filter(s => s.row === r).sort((a,b) => a.number - b.number);
        for (let i = 0; i <= rowSeats.length - groupSize; i++) {
          let chunk = rowSeats.slice(i, i + groupSize);
          if (chunk.every(s => s.status === 'available')) {
            bestBlock = chunk;
            break;
          }
        }
        if (bestBlock.length > 0) break;
      }
    } else {
      const half = Math.ceil(groupSize / 2);
      for (let i = 0; i < rows.length - 1; i++) {
        let r1 = rows[i];
        let r2 = rows[i+1];
        let row1Seats = seats.filter(s => s.row === r1).sort((a,b) => a.number - b.number);
        let row2Seats = seats.filter(s => s.row === r2).sort((a,b) => a.number - b.number);
        
        for (let colStart = 1; colStart <= 8; colStart++) {
          let chunk1 = row1Seats.filter(s => s.number >= colStart && s.number < colStart + half);
          let chunk2 = row2Seats.filter(s => s.number >= colStart && s.number < colStart + (groupSize - half));
          
          if (chunk1.length === half && chunk2.length === (groupSize - half) &&
              chunk1.every(s => s.status === 'available') && chunk2.every(s => s.status === 'available')) {
            bestBlock = [...chunk1, ...chunk2];
            break;
          }
        }
        if (bestBlock.length > 0) break;
      }
    }
    
    if (bestBlock.length > 0) {
      setSelectedSeats(bestBlock);
      setAiRecommended(bestBlock.map(s => s.id));
      setAiRationale(`Group Optimizer: Found optimal ${groupLayout} layout for ${groupSize} people.\nSeats selected: ${bestBlock.map(s => s.row + s.number).join(', ')}.`);
    } else {
      alert("Could not find a perfect consecutive block layout for this size. Try selecting individual recommended seats instead.");
    }
  };

  const addSnack = (sn) => {
    const ex = cart.find(x => x.id === sn.id);
    if(ex) setCart(cart.map(x => x.id === sn.id ? {...x, qty:x.qty+1} : x));
    else setCart([...cart, {...sn, qty:1}]);
  };
  const remSnack = (id) => {
    const ex = cart.find(x => x.id === id);
    if(ex.qty === 1) setCart(cart.filter(x => x.id !== id));
    else setCart(cart.map(x => x.id === id ? {...x, qty:x.qty-1} : x));
  };

  const seatTotal = selectedSeats.reduce((t, s) => t + s.price, 0);
  const baseSnackTotal = cart.reduce((t, s) => t + s.price*s.qty, 0);
  const totalSnackItems = cart.reduce((sum, item) => sum + item.qty, 0);
  const snackDiscount = totalSnackItems >= 2 ? 50 : 0;
  const snackTotal = Math.max(0, baseSnackTotal - snackDiscount);
  
  const discount = voucher ? KC.applyVoucher(voucher, seatTotal+snackTotal) : 0;
  const parkingFee = parking ? 100 : 0;
  const grandTotal = seatTotal + snackTotal + parkingFee - discount;

  const pay = () => {
    setPaymentProcessing(true);
    setTimeout(() => {
      setPaymentProcessing(false);
      setPaymentSuccess(true);
      setTimeout(() => {
        const bk = {
          id: 'BK'+Date.now().toString().substr(5),
          userId: user.id, movieTitle: movie.title, poster: movie.poster,
          showId, showDate: show.showDate, showTime: show.showTime, screen: show.screen,
          seats: selectedSeats.map(s => s.row+s.number),
          seatTotal, snackTotal, discount, parkingFee, parking, grandTotal,
          splitShare: splitBill ? grandTotal / splitWays : grandTotal,
          snacks: cart, status: 'confirmed', date: new Date().toISOString()
        };
        KC.BOOKINGS.unshift(bk);
        if(KC.saveBookings) KC.saveBookings();
        navigate('dashboard');
      }, 1500);
    }, 2500);
  };

  return (
    <div className="flex flex-col md:flex-row gap-8 animate-fade-in pb-20">
      <div className="flex-1">
        {step === 1 && (
          <div className="glass p-6 rounded-2xl relative">
            <div className="flex flex-wrap gap-3 justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Select Seats</h2>
              <div className="flex flex-wrap gap-2">
                <button 
                  onClick={() => setIsGroupMode(!isGroupMode)} 
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${isGroupMode ? 'bg-orange-500/20 border-orange-500 text-orange-400 font-bold' : 'bg-white/5 border-white/10 text-gray-400 hover:bg-white/10'}`}
                >
                  👥 Group Optimizer
                </button>
                {selectedSeats.length > 0 && (
                  <button 
                    onClick={() => { setArSeat(selectedSeats[0]); setShowAR(true); }}
                    className="flex items-center gap-1.5 bg-purple-600/20 border border-purple-500/30 hover:bg-purple-600/30 text-purple-400 px-3 py-1.5 rounded-lg text-xs font-bold transition-all"
                  >
                    👁️ AR Preview ({selectedSeats[0].row}{selectedSeats[0].number})
                  </button>
                )}
                <button onClick={recommendSeats} className="flex items-center gap-1.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-[0_0_15px_rgba(59,130,246,0.5)] transition-all">
                  ✨ AI Recommend
                </button>
              </div>
            </div>

            {isGroupMode && (
              <div className="mb-6 p-4 bg-orange-500/5 border border-orange-500/20 rounded-xl flex flex-wrap gap-4 items-center justify-between animate-fade-in">
                <div className="flex items-center gap-3">
                  <span className="text-xs text-gray-400 font-bold">Group Size:</span>
                  <div className="flex items-center gap-2 bg-black/40 rounded-lg p-1 border border-white/10">
                    {[2,3,4,5,6,8].map(sz => (
                      <button 
                        key={sz} 
                        onClick={() => setGroupSize(sz)}
                        className={`w-6 h-6 rounded flex items-center justify-center text-xs font-bold transition-colors ${groupSize === sz ? 'bg-orange-500 text-white font-bold' : 'text-gray-400 hover:text-white'}`}
                      >
                        {sz}
                      </button>
                    ))}
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  <span className="text-xs text-gray-400 font-bold">Layout style:</span>
                  <div className="flex bg-black/40 rounded-lg p-1 border border-white/10">
                    {['Linear', 'Block'].map(l => (
                      <button 
                        key={l} 
                        onClick={() => setGroupLayout(l)}
                        className={`px-3 py-1 rounded text-xs font-bold transition-colors ${groupLayout === l ? 'bg-orange-500 text-white font-bold' : 'text-gray-400 hover:text-white'}`}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                </div>
                
                <button onClick={optimizeGroup} className="bg-orange-500 hover:bg-orange-400 text-white font-bold text-xs px-4 py-2 rounded-lg transition-colors shadow-[0_0_10px_rgba(249,115,22,0.4)]">
                  Optimize Seats
                </button>
              </div>
            )}
            
            {aiRationale && (
              <div className="mb-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
                <p className="text-blue-400 font-bold text-sm flex items-start gap-2">
                  <span className="mt-0.5">💡</span>
                  <span className="whitespace-pre-line">{aiRationale}</span>
                </p>
              </div>
            )}
            
            <div className="flex justify-center mb-6">
              <div className="w-3/4 h-2 bg-gradient-to-b from-white/80 to-transparent rounded-[50%] opacity-30 shadow-[0_0_30px_rgba(255,255,255,0.5)]" />
              <p className="absolute text-[10px] text-gray-500 mt-4 tracking-widest uppercase">Screen</p>
            </div>

            {/* Live Crowd Analytics */}
            <div className="flex gap-4 p-4 bg-black/40 border border-white/5 rounded-xl mb-6 text-xs text-gray-400 justify-around items-center flex-wrap">
              <div className="flex items-center gap-1.5"><span className="text-sm">🌡️</span> {crowdStats.temp}°C Room Temp</div>
              <div className="flex items-center gap-1.5"><span className="text-sm">🤫</span> Noise: {crowdStats.noise}</div>
              <div className="flex items-center gap-1.5"><span className="text-sm">📊</span> Demographics: {crowdStats.families}% Family • {crowdStats.couples}% Couple • {crowdStats.solo}% Solo</div>
              <div className="flex items-center gap-1.5"><span className="text-sm">😊</span> Mood: High Vibe</div>
            </div>
            
            <div className="flex flex-col gap-2 items-center overflow-x-auto pb-4">
              {['A','B','C','D','E','F','G','H'].map(row => (
                <div key={row} className="flex gap-2 items-center">
                  <div className="w-4 text-xs text-gray-500 font-bold">{row}</div>
                  <div className="flex gap-2">
                    {seats.filter(s => s.row === row).map(s => {
                      const sel = selectedSeats.find(x => x.id === s.id);
                      const isAi = aiRecommended.includes(s.id);
                      
                      let bg = 'bg-white/10 border-white/20 text-white hover:bg-white/20';
                      if(s.status === 'booked') bg = 'bg-gray-800 border-gray-700 text-gray-600 cursor-not-allowed opacity-50';
                      else if(sel) bg = 'bg-red-500/20 border-red-500 text-red-400 shadow-[0_0_10px_rgba(244,63,94,0.5)]';
                      else if(s.seatType === 'Recliner') bg = 'bg-purple-500/10 border-purple-500/30 text-purple-400 hover:bg-purple-500/20';
                      else if(s.seatType === 'Gold') bg = 'bg-orange-500/10 border-orange-500/30 text-orange-400 hover:bg-orange-500/20';
                      else if(s.seatType === 'Silver') bg = 'bg-blue-500/10 border-blue-500/30 text-blue-400 hover:bg-blue-500/20';
                      
                      return (
                        <button key={s.id} onClick={() => toggleSeat(s)} className={`relative w-8 h-8 rounded-t-lg rounded-b flex items-center justify-center text-[10px] font-bold border transition-all ${bg}`}>
                          {s.number}
                          {isAi && sel && <div className="absolute -top-1 -right-1 w-2 h-2 bg-blue-500 rounded-full shadow-[0_0_5px_#3b82f6] animate-pulse"></div>}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>

            <div className="flex justify-center gap-4 mt-8 pt-6 border-t border-white/10 text-[10px] text-gray-400 flex-wrap">
              <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-blue-500/10 border border-blue-500/30"/> Silver</div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-orange-500/10 border border-orange-500/30"/> Gold</div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-purple-500/10 border border-purple-500/30"/> Recliner</div>
              <div className="flex items-center gap-1 ml-4"><div className="w-3 h-3 rounded bg-red-500/20 border border-red-500"/> Selected</div>
              <div className="flex items-center gap-1"><div className="w-3 h-3 rounded bg-gray-800 border border-gray-700 opacity-50"/> Booked</div>
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="glass p-6 rounded-2xl">
            <h2 className="text-2xl font-bold mb-2">Grab a Bite! 🍿</h2>
            <p className="text-gray-400 mb-6 text-sm">Your order will be served directly to your seats during the interval, or you can collect it from the counter by showing your booking.</p>
            
            <div className="mb-6 p-4 bg-gradient-to-r from-orange-500/20 to-red-500/20 border border-orange-500/30 rounded-xl flex items-center justify-between">
              <div>
                <h3 className="font-bold text-orange-400">Combo Offer! 🎉</h3>
                <p className="text-sm text-gray-300">Add any 2 Snacks and get ₹50 OFF your food bill instantly.</p>
              </div>
              {totalSnackItems >= 2 && (
                <div className="bg-green-500/20 text-green-400 px-3 py-1 rounded text-xs font-bold border border-green-500/30">Applied!</div>
              )}
            </div>
            
            <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
              {KC.SNACKS.map(sn => {
                const inCart = cart.find(x => x.id === sn.id);
                return (
                  <div key={sn.id} className="bg-black/40 border border-white/10 rounded-xl p-4 flex flex-col items-center text-center hover:bg-white/5 transition-colors">
                    <div className="text-4xl mb-2">{sn.emoji}</div>
                    <div className="font-bold text-sm mb-1">{sn.name}</div>
                    <div className="text-[10px] text-gray-400 mb-3 line-clamp-1">{sn.desc}</div>
                    <div className="text-red-400 font-bold mb-3">₹{sn.price}</div>
                    {inCart ? (
                      <div className="flex items-center gap-3 bg-red-500/20 rounded-lg px-2 py-1">
                        <button onClick={() => remSnack(sn.id)} className="w-6 h-6 flex items-center justify-center font-bold text-red-400 hover:bg-red-500/30 rounded">-</button>
                        <span className="font-bold text-sm w-4">{inCart.qty}</span>
                        <button onClick={() => addSnack(sn)} className="w-6 h-6 flex items-center justify-center font-bold text-red-400 hover:bg-red-500/30 rounded">+</button>
                      </div>
                    ) : (
                      <button onClick={() => addSnack(sn)} className="btn-secondary text-xs px-4 py-1.5 w-full">Add</button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="glass p-6 rounded-2xl relative overflow-hidden">
            
            {/* PAYMENT SUCCESS OVERLAY */}
            {paymentSuccess && (
              <div className="absolute inset-0 bg-green-900/90 backdrop-blur-sm z-50 flex flex-col items-center justify-center animate-fade-in text-white rounded-2xl">
                <div className="text-7xl mb-4 animate-bounce">🎉</div>
                <h2 className="text-3xl font-black mb-2">Payment Successful!</h2>
                <p className="text-green-200 text-sm">Ticket confirmed. Redirecting to dashboard...</p>
              </div>
            )}
            
            {/* PAYMENT PROCESSING OVERLAY */}
            {paymentProcessing && (
              <div className="absolute inset-0 bg-black/90 backdrop-blur-sm z-50 flex flex-col items-center justify-center animate-fade-in text-white rounded-2xl">
                <div className="w-16 h-16 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4"></div>
                <h2 className="text-2xl font-bold mb-2">Processing Payment</h2>
                <p className="text-gray-400 text-sm">Please do not refresh the page...</p>
              </div>
            )}

            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold">Checkout</h2>
              <div className="text-xl font-black text-red-500">₹{splitBill ? (grandTotal / splitWays).toFixed(2) : grandTotal}</div>
            </div>

            {/* SOCIAL BILL SPLITTING */}
            <div className="mb-8 p-5 bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-blue-500/30 rounded-2xl">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-bold text-blue-300 flex items-center gap-2"><span>🤝</span> Split with Friends</h3>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input type="checkbox" checked={splitBill} onChange={(e) => { setSplitBill(e.target.checked); if(e.target.checked) setSplitLink('https://karaicini.com/split/' + Math.random().toString(36).substring(7)); else setSplitLink(''); }} className="sr-only peer" />
                  <div className="w-9 h-5 bg-black/50 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-500"></div>
                </label>
              </div>
              {splitBill && (
                <div className="animate-fade-in space-y-4 mt-4 border-t border-white/10 pt-4">
                  <div>
                    <label className="text-xs text-gray-400 block mb-1">How many people?</label>
                    <div className="flex items-center gap-4">
                      <input type="range" min="2" max="10" value={splitWays} onChange={(e) => setSplitWays(Number(e.target.value))} className="flex-1 accent-blue-500" />
                      <span className="font-bold text-lg">{splitWays} Ways</span>
                    </div>
                  </div>
                  <div className="bg-black/60 p-3 rounded-lg flex items-center justify-between border border-white/10">
                    <div>
                      <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Your Share to Pay Now</div>
                      <div className="text-xl font-bold text-green-400">₹{(grandTotal / splitWays).toFixed(2)}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-[10px] text-gray-500 uppercase tracking-wider mb-1">Share Link with Friends</div>
                      <button onClick={() => alert('Link Copied to Clipboard!')} className="bg-white/10 hover:bg-white/20 text-xs px-3 py-1.5 rounded-lg border border-white/20 flex items-center gap-1 transition-colors"><span>📋</span> Copy Link</button>
                    </div>
                  </div>
                </div>
              )}
            </div>

            <h3 className="font-bold mb-3 text-gray-400 text-sm uppercase tracking-wider">Select Payment Method</h3>
            <div className="space-y-3">
              {['UPI', 'Credit/Debit Card', 'Net Banking'].map(m => (
                <label key={m} className={`flex items-center gap-3 p-4 border rounded-xl cursor-pointer transition-all ${paymentMethod === m ? 'bg-red-500/10 border-red-500' : 'bg-black/40 border-white/10 hover:bg-white/5'}`}>
                  <input type="radio" name="payment" className="w-4 h-4 accent-red-500" checked={paymentMethod === m} onChange={() => setPaymentMethod(m)} />
                  <span className="font-bold">{m}</span>
                </label>
              ))}
            </div>

            {/* DYNAMIC PAYMENT UI */}
            {paymentMethod === 'UPI' && (
              <div className="mt-4 p-6 bg-white/5 border border-white/10 rounded-xl flex flex-col items-center justify-center animate-fade-in text-center">
                <div className="w-32 h-32 bg-white rounded-xl mb-3 flex items-center justify-center p-2 relative">
                  <div className="absolute inset-2 border-[4px] border-black border-dashed opacity-20"></div>
                  <span className="text-black font-black text-2xl">QR</span>
                </div>
                <p className="text-sm font-bold">Scan with any UPI App</p>
                <p className="text-xs text-gray-400 mt-1">Google Pay • PhonePe • Paytm</p>
              </div>
            )}

            {paymentMethod === 'Credit/Debit Card' && (
              <div className="mt-4 p-5 bg-white/5 border border-white/10 rounded-xl space-y-4 animate-fade-in">
                <div>
                  <label className="text-[10px] text-gray-400 uppercase block mb-1">Card Number</label>
                  <input type="text" placeholder="XXXX XXXX XXXX XXXX" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-red-500 font-mono" />
                </div>
                <div className="flex gap-4">
                  <div className="flex-1">
                    <label className="text-[10px] text-gray-400 uppercase block mb-1">Expiry</label>
                    <input type="text" placeholder="MM/YY" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-red-500 font-mono" />
                  </div>
                  <div className="w-24">
                    <label className="text-[10px] text-gray-400 uppercase block mb-1">CVV</label>
                    <input type="password" placeholder="•••" maxLength="3" className="w-full bg-black/50 border border-white/10 rounded-lg px-3 py-2 text-sm text-white outline-none focus:border-red-500 font-mono text-center" />
                  </div>
                </div>
              </div>
            )}

            {/* ADD-ONS SECTION */}
            <h3 className="font-bold mt-6 mb-3 text-gray-400 text-sm uppercase tracking-wider">Add-ons</h3>
            <label className="flex items-center justify-between p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl cursor-pointer hover:bg-blue-500/20 transition-all">
              <div className="flex items-center gap-3">
                <input 
                  type="checkbox" 
                  checked={parking} 
                  onChange={(e) => setParking(e.target.checked)} 
                  className="w-5 h-5 accent-blue-500 cursor-pointer" 
                />
                <div>
                  <div className="font-bold text-white">Reserve Parking Slot 🚗</div>
                  <div className="text-xs text-gray-400">Guaranteed premium parking near entrance</div>
                </div>
              </div>
              <div className="font-bold text-blue-400">₹100</div>
            </label>

            <div className="mt-8 pt-4 border-t border-white/10 flex items-center gap-2 text-gray-500 text-xs justify-center">
              <span>🔒</span> Secure 256-bit encrypted payment powered by KaraiCini Pay
            </div>
          </div>
        )}
      </div>

      <div className="md:w-80 flex-shrink-0">
        <div className="glass rounded-2xl overflow-hidden sticky top-24">
          <div className="bg-red-950/40 p-4 border-b border-white/10">
            <h3 className="font-bold text-lg">{movie.title}</h3>
            <p className="text-xs text-gray-400">{show.screen} • {show.lang}</p>
            <p className="text-xs text-gray-400 mt-1">{new Date(show.showDate).toLocaleDateString()} • {show.showTime}</p>
          </div>
          
          <div className="p-4 space-y-4">
            {selectedSeats.length > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Seats ({selectedSeats.map(s=>s.row+s.number).join(', ')})</span>
                <span className="font-bold">₹{seatTotal}</span>
              </div>
            )}
            
            {cart.length > 0 && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-400">Food & Bev</span>
                <span className="font-bold">₹{snackTotal}</span>
              </div>
            )}

            {vouchers.length > 0 && !voucher && (
              <div className="bg-white/5 border border-white/10 rounded-xl p-3">
                <p className="text-xs font-bold text-gray-400 mb-2">Available Offers</p>
                <div className="space-y-2">
                  {vouchers.map(v => (
                    <div key={v.code} className="flex justify-between items-center text-xs">
                      <div>
                        <div className="font-bold text-green-400">{v.code}</div>
                        <div className="text-[9px] text-gray-500">{v.reason}</div>
                      </div>
                      <button onClick={()=>setVoucher(v)} className="bg-white/10 hover:bg-white/20 px-2 py-1 rounded">Apply</button>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {voucher && (
              <div className="flex justify-between text-sm text-green-400 bg-green-500/10 p-2 rounded-lg">
                <span>Discount ({voucher.code})</span>
                <span>-₹{discount}</span>
              </div>
            )}

            {parking && (
              <div className="flex justify-between text-sm text-blue-400 bg-blue-500/10 p-2 rounded-lg">
                <span>Parking Slot</span>
                <span>+₹100</span>
              </div>
            )}

            <div className="pt-4 border-t border-white/10 flex justify-between font-bold text-lg">
              <span>Total</span>
              <span>₹{grandTotal}</span>
            </div>

            {selectedSeats.length === 0 ? (
              <button disabled className="btn-primary w-full py-3 opacity-50 cursor-not-allowed">Select Seats to Continue</button>
            ) : step < 3 ? (
              <button onClick={() => setStep(step+1)} className="btn-primary w-full py-3">Continue</button>
            ) : (
              <button onClick={pay} disabled={paymentProcessing || paymentSuccess} className="btn-primary w-full py-3 shadow-[0_0_20px_rgba(244,63,94,0.4)]">
                {paymentProcessing ? 'Processing...' : paymentSuccess ? 'Success!' : `Pay ₹${splitBill ? (grandTotal / splitWays).toFixed(2) : grandTotal}`}
              </button>
            )}
            {step > 1 && (
              <button onClick={() => setStep(step-1)} className="text-xs text-center w-full text-gray-500 hover:text-white mt-2">Go Back</button>
            )}
          </div>
        </div>
      </div>

      {/* AR Theater Preview Modal */}
      {showAR && arSeat && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-md flex items-center justify-center z-[120] animate-fade-in p-4">
          <div className="glass-dark p-6 rounded-3xl w-full max-w-4xl border border-white/10 shadow-2xl relative flex flex-col h-[85vh]">
            <button onClick={() => setShowAR(false)} className="absolute top-4 right-4 text-xl text-gray-400 hover:text-white transition-colors z-50">✕</button>
            <h2 className="text-2xl font-black mb-1 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-500 flex items-center gap-2">
              <span>👁️</span> AR Immersive Theatre Preview
            </h2>
            <p className="text-xs text-gray-400 mb-4">Simulated 3D projection view and Dolby Atmos acoustic analysis from seat <span className="font-bold text-white bg-purple-500/20 px-2 py-0.5 rounded border border-purple-500/30">{arSeat.row}{arSeat.number}</span></p>
            
            {/* The 3D view simulation container */}
            <div className="flex-1 bg-gradient-to-b from-[#020205] to-[#0d0d1f] rounded-2xl relative overflow-hidden border border-white/5 flex items-center justify-center">
              {/* Theater ceiling/lights/walls simulated perspective */}
              <div className="absolute inset-0 flex flex-col justify-between p-6 pointer-events-none opacity-20">
                <div className="flex justify-between w-full">
                  <div className="w-1.5 h-6 bg-red-500 rounded-full animate-pulse"></div>
                  <div className="w-1.5 h-6 bg-red-500 rounded-full animate-pulse"></div>
                </div>
                <div className="flex justify-between w-full">
                  <div className="w-6 h-6 border-l-2 border-t-2 border-white/20"></div>
                  <div className="w-6 h-6 border-r-2 border-t-2 border-white/20"></div>
                </div>
              </div>
              
              {/* Glow backdrop behind the screen */}
              <div className="absolute w-[60%] h-[35%] bg-purple-500/10 rounded-full blur-[80px]"></div>
              
              {/* Projection Screen */}
              <div className="w-[75%] max-w-[650px] aspect-[2.35/1] bg-black border-[6px] border-zinc-800 rounded-lg shadow-[0_0_50px_rgba(168,85,247,0.3)] relative overflow-hidden transform hover:scale-[1.02] transition-transform duration-500">
                <img src={movie.backdrop} className="w-full h-full object-cover opacity-85" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent"></div>
                {/* Acoustic speaker lines visual */}
                {arSpeakerActive && (
                  <div className="absolute inset-0 flex justify-center items-center pointer-events-none">
                    <div className="w-24 h-24 rounded-full border border-blue-500/40 animate-ping"></div>
                  </div>
                )}
              </div>
              
              {/* Speaker indicators with test toggle buttons */}
              <div className="absolute bottom-4 left-4 right-4 flex justify-between px-10">
                <button 
                  onClick={() => setArSpeakerActive('Left')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${arSpeakerActive === 'Left' ? 'bg-blue-500/20 border-blue-500 text-blue-400 font-bold' : 'bg-black/50 border-white/10 text-gray-400'}`}
                >
                  🔊 Left Speaker
                </button>
                
                <button 
                  onClick={() => setArSpeakerActive('Center')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${arSpeakerActive === 'Center' ? 'bg-blue-500/20 border-blue-500 text-blue-400 font-bold' : 'bg-black/50 border-white/10 text-gray-400'}`}
                >
                  🔊 Center Speaker
                </button>
                
                <button 
                  onClick={() => setArSpeakerActive('Right')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${arSpeakerActive === 'Right' ? 'bg-blue-500/20 border-blue-500 text-blue-400 font-bold' : 'bg-black/50 border-white/10 text-gray-400'}`}
                >
                  🔊 Right Speaker
                </button>
                
                <button 
                  onClick={() => setArSpeakerActive('Surround')}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-bold transition-all border ${arSpeakerActive === 'Surround' ? 'bg-blue-500/20 border-blue-500 text-blue-400 font-bold' : 'bg-black/50 border-white/10 text-gray-400'}`}
                >
                  🔊 Surround Sound
                </button>
              </div>
            </div>
            
            {/* Technical metrics */}
            <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                <div className="text-[10px] text-gray-400 font-bold uppercase">Horizontal Angle</div>
                <div className="text-lg font-black text-white">0.5° (Perfect Center)</div>
              </div>
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                <div className="text-[10px] text-gray-400 font-bold uppercase">Vertical Screen Tilt</div>
                <div className="text-lg font-black text-white">+11.2° Eye-level</div>
              </div>
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                <div className="text-[10px] text-gray-400 font-bold uppercase">Acoustic Delay</div>
                <div className="text-lg font-black text-white">12.5ms Atmos Sync</div>
              </div>
              <div className="bg-white/5 p-3 rounded-xl border border-white/5">
                <div className="text-[10px] text-gray-400 font-bold uppercase">Screen Field-of-View</div>
                <div className="text-lg font-black text-white">36.5° Cinema Scope</div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const Dashboard = ({ user }) => {
  const [bks, setBks] = useState([]);
  useEffect(() => {
    setBks(KC.BOOKINGS.filter(b => b.userId === user.id));
  }, [user]);

  const cancel = (id, showDate, showTime) => {
    if(!KC.canCancelBooking(showDate, showTime)) {
      return alert('Cannot cancel within 30 mins of showtime or for past shows.');
    }
    if(confirm('Cancel this booking? Refund will take 3-5 days.')){
      const bk = KC.BOOKINGS.find(b => b.id === id);
      if(bk) {
        bk.status = 'cancelled';
        KC.saveBookings();
        setBks([...KC.BOOKINGS.filter(b => b.userId === user.id)]);
        alert('Booking cancelled successfully.');
      }
    }
  };

  return (
    <div className="animate-fade-in max-w-4xl mx-auto pb-20">
      <h1 className="text-3xl font-bold mb-8">My Bookings</h1>
      {bks.length === 0 ? (
        <div className="glass p-12 text-center rounded-2xl">
          <div className="text-4xl mb-4">🎫</div>
          <h2 className="text-xl font-bold mb-2">No bookings yet</h2>
          <p className="text-gray-400">Book your first movie ticket now!</p>
        </div>
      ) : (
        <div className="space-y-6">
          {bks.map(b => {
            const canCancel = b.status === 'confirmed' && KC.canCancelBooking(b.showDate, b.showTime);
            return (
              <div key={b.id} className="glass rounded-2xl overflow-hidden flex flex-col md:flex-row relative group">
                {b.status === 'cancelled' && <div className="absolute inset-0 bg-black/60 backdrop-blur-md z-20 flex items-center justify-center"><div className="border-4 border-red-500 text-red-500 font-black text-4xl p-4 rotate-[-15deg] rounded-xl opacity-80 uppercase tracking-widest">Cancelled</div></div>}
                
                <div className="md:w-64 relative shrink-0">
                  <img src={b.poster} className="w-full h-full object-cover min-h-[240px]" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 right-4">
                    <h2 className="text-xl font-bold leading-tight shadow-black drop-shadow-md">{b.movieTitle}</h2>
                    <p className="text-gray-300 text-sm mt-1">{b.screen}</p>
                  </div>
                </div>
                
                <div className="p-6 flex-1 flex flex-col relative border-l border-dashed border-white/20">
                  <div className="absolute -left-3 top-1/2 -translate-y-1/2 w-6 h-6 bg-[#0a0a0f] rounded-full border-r border-white/20"></div>
                  
                  <div className="flex justify-between items-start mb-6">
                    <div>
                      <div className="text-gray-400 text-xs uppercase tracking-widest mb-1">Date & Time</div>
                      <p className="font-bold text-lg">{new Date(b.showDate).toLocaleDateString('en-US', {weekday:'short', month:'short', day:'numeric'})} • {b.showTime}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-gray-400 text-xs uppercase tracking-widest mb-1">Booking ID</div>
                      <div className="bg-white/10 px-3 py-1 rounded font-mono text-sm tracking-widest border border-white/10">{b.id}</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
                    <div>
                      <span className="text-gray-500 block text-xs uppercase mb-1">Seats</span>
                      <span className="font-bold text-lg">{b.seats.join(', ')}</span>
                    </div>
                    <div>
                      <span className="text-gray-500 block text-xs uppercase mb-1">Total Amount</span>
                      <span className="font-bold text-red-400 text-lg">₹{b.grandTotal}</span>
                    </div>
                    {b.snacks?.length > 0 && (
                      <div className="col-span-2 bg-white/5 p-3 rounded-xl border border-white/10">
                        <span className="text-gray-400 text-xs block mb-1">Food Ordered:</span>
                        <div className="font-medium text-sm">{b.snacks.map(s => `${s.qty}x ${s.name}`).join(', ')}</div>
                        <div className="text-green-400 text-xs mt-2 flex items-center gap-1"><span>🍿</span> Will be served to your seats during the interval.</div>
                      </div>
                    )}
                  </div>
                  
                  <div className="mt-auto flex justify-between items-end border-t border-white/10 pt-4">
                    <div className="flex gap-4 items-center">
                      <img src={`https://api.qrserver.com/v1/create-qr-code/?size=80x80&data=ID:${b.id}|Parking:${b.parking?'Yes':'No'}&color=ffffff&bgcolor=000000`} className="w-16 h-16 rounded shadow-lg opacity-80 group-hover:opacity-100 transition-opacity" alt="Ticket QR" />
                      {b.parking && <div className="text-xs bg-blue-500/20 text-blue-400 px-2 py-1 rounded border border-blue-500/30">🚗 Parking Reserved</div>}
                    </div>
                    {canCancel && (
                      <button onClick={() => cancel(b.id, b.showDate, b.showTime)} className="text-xs border border-white/20 hover:bg-red-500/10 hover:border-red-500 hover:text-red-400 px-4 py-2 rounded-lg transition-all">
                        Cancel Booking
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

const AdminMoviesSection = () => {
  const [moviesList, setMoviesList] = useState([...KC.MOVIES]);
  const [showAddModal, setShowAddModal] = useState(false);

  // Add Movie Form State
  const [newTitle, setNewTitle] = useState('');
  const [newGenre, setNewGenre] = useState('');
  const [newLang, setNewLang] = useState('English');
  const [newPrice, setNewPrice] = useState(250);
  const [newDemand, setNewDemand] = useState('medium');
  const [newPoster, setNewPoster] = useState('');
  const [newDesc, setNewDesc] = useState('');

  const saveMovieChanges = (movieId, fields) => {
    const movie = KC.MOVIES.find(m => m.id === movieId);
    if (movie) {
      Object.assign(movie, fields);
      if (KC.saveMovies) KC.saveMovies();
      setMoviesList([...KC.MOVIES]);
    }
  };

  const runAiMovieAssist = (movieId, action) => {
    const movie = KC.MOVIES.find(m => m.id === movieId);
    if (!movie) return;
    
    if (action === 'description') {
      const generatedDesc = `AI Synopsis: An adrenaline-fueled cinematic journey exploring destiny and raw ambition. Critics rave about the powerhouse acting, stunning visual direction, and standard-setting background score.`;
      const generatedTags = ['AI Certified', 'Must Watch', 'Blockbuster Pick'];
      const updatedGenres = Array.from(new Set([...movie.genre, 'Drama', 'Action']));
      
      saveMovieChanges(movieId, {
        desc: generatedDesc,
        tags: Array.from(new Set([...(movie.tags || []), ...generatedTags])),
        genre: updatedGenres,
        aiAssistResult: `📝 Description generated! Auto-classified as: ${updatedGenres.join(', ')}\n🏷️ Tags: ${generatedTags.join(', ')}`
      });
      alert('AI Description & Genre Classification updated!');
    } else if (action === 'poster') {
      const scores = { Contrast: '9.2/10', Composition: '8.8/10', TextLegibility: '9.5/10' };
      saveMovieChanges(movieId, {
        aiAssistResult: `🎨 AI Poster Quality Report:\n• Contrast: ${scores.Contrast} (Excellent dynamic range)\n• Composition: ${scores.Composition} (Strong focal weight)\n• Text Legibility: ${scores.TextLegibility} (High accessibility)\n✅ Overall Score: 91% (Pass)`
      });
    } else if (action === 'trailer') {
      saveMovieChanges(movieId, {
        aiAssistResult: `🎥 AI Trailer Engagement Prediction:\n• Projected Click-Through-Rate: 15.6% (Top 5% category)\n• Retained Viewership (90s): 74%\n• Sentiment Index: 9.2/10 Positive\n📈 Predicted Box Office Impact: +18.4% Revenue Surge`
      });
    }
  };

  const deleteMovie = (movieId) => {
    if (confirm('Are you sure you want to delete this movie? All scheduled shows for this movie will be removed.')) {
      const idx = KC.MOVIES.findIndex(m => m.id === movieId);
      if (idx !== -1) {
        KC.MOVIES.splice(idx, 1);
        if (KC.saveMovies) KC.saveMovies();
        setMoviesList([...KC.MOVIES]);
        alert('Movie deleted.');
      }
    }
  };

  const handleAddMovie = (e) => {
    e.preventDefault();
    if (!newTitle.trim()) return alert('Please enter a movie title.');

    const newMovie = {
      id: 'm' + Date.now(),
      title: newTitle,
      rating: 7.0,
      year: new Date().getFullYear(),
      duration: 120,
      lang: newLang,
      langs: [newLang],
      genre: newGenre.split(',').map(g => g.trim()),
      director: 'Unknown',
      cast: ['N/A'],
      poster: newPoster.trim() || 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop',
      backdrop: 'https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=1400&h=500&fit=crop',
      status: 'Now Showing',
      price: Number(newPrice),
      tags: ['New'],
      demand: newDemand,
      desc: newDesc.trim() || 'No description available.',
      cert: 'UA'
    };

    KC.MOVIES.push(newMovie);
    if (KC.saveMovies) KC.saveMovies();
    setMoviesList([...KC.MOVIES]);
    setShowAddModal(false);

    // Reset Form
    setNewTitle('');
    setNewGenre('');
    setNewLang('English');
    setNewPrice(250);
    setNewDemand('medium');
    setNewPoster('');
    setNewDesc('');
    alert('New movie added successfully!');
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center bg-black/40 p-5 rounded-2xl border border-white/10 gap-4">
        <div>
          <h2 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-500">🎬 CineAI Show & Dynamic Pricing Manager</h2>
          <p className="text-xs text-gray-400">Add or edit movies. Changing demand levels auto-calculates AI Surge multiplier values.</p>
        </div>
        <button onClick={() => setShowAddModal(true)} className="bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-[0_0_15px_rgba(244,63,94,0.3)] transition-all shrink-0">
          + Add New Movie
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {moviesList.map(movie => (
          <div key={movie.id} className="glass p-5 rounded-2xl flex gap-4 hover:shadow-[0_4px_25px_rgba(255,255,255,0.05)] transition-all relative overflow-hidden border border-white/10">
            <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-red-500/10 to-transparent blur-2xl pointer-events-none"></div>

            <img src={movie.poster} className="w-24 h-36 rounded-xl object-cover border border-white/10 shrink-0 shadow-lg" alt={movie.title} onError={(e)=>{e.target.src='https://images.unsplash.com/photo-1594909122845-11baa439b7bf?w=400&h=600&fit=crop';}} />

            <div className="flex-1 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start gap-2">
                  <h3 className="font-bold text-white text-base line-clamp-1">{movie.title}</h3>
                  <button onClick={() => deleteMovie(movie.id)} className="text-red-500 hover:text-red-400 text-xs font-bold shrink-0">🗑️ Delete</button>
                </div>
                <p className="text-xs text-gray-400 mt-0.5 line-clamp-1">{movie.genre.join(', ')} • {movie.lang}</p>

                <div className="grid grid-cols-2 gap-3 mt-3">
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Base Price (₹)</label>
                    <input 
                      type="number" 
                      value={movie.price} 
                      onChange={(e) => saveMovieChanges(movie.id, { price: Number(e.target.value) })}
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs outline-none focus:border-red-500 transition-colors text-white"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Demand Profile</label>
                    <select 
                      value={movie.demand} 
                      onChange={(e) => saveMovieChanges(movie.id, { demand: e.target.value })}
                      className="w-full bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs outline-none focus:border-red-500 transition-colors cursor-pointer text-white"
                    >
                      <option value="low">Low (Offers)</option>
                      <option value="medium">Medium (Std)</option>
                      <option value="high">High (Surge Active)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* AI Movie Assist Tools Panel */}
              <div className="mt-3 pt-2.5 border-t border-white/5 space-y-2">
                <p className="text-[9px] text-purple-400 font-bold uppercase tracking-wider">🧠 AI Movie Tools</p>
                <div className="flex gap-1.5 flex-wrap">
                  <button 
                    onClick={() => runAiMovieAssist(movie.id, 'description')}
                    className="bg-purple-600/20 border border-purple-500/30 hover:bg-purple-600/30 text-purple-300 text-[9px] px-2 py-1 rounded transition-colors font-bold"
                  >
                    ✨ AI Desc & Tags
                  </button>
                  <button 
                    onClick={() => runAiMovieAssist(movie.id, 'poster')}
                    className="bg-pink-600/20 border border-pink-500/30 hover:bg-pink-600/30 text-pink-300 text-[9px] px-2 py-1 rounded transition-colors font-bold"
                  >
                    🎨 Poster Analysis
                  </button>
                  <button 
                    onClick={() => runAiMovieAssist(movie.id, 'trailer')}
                    className="bg-blue-600/20 border border-blue-500/30 hover:bg-blue-600/30 text-blue-300 text-[9px] px-2 py-1 rounded transition-colors font-bold"
                  >
                    🎥 Trailer Predict
                  </button>
                </div>
                {movie.aiAssistResult && (
                  <div className="p-2 bg-purple-500/10 border border-purple-500/20 rounded-lg text-[9px] text-gray-300 mt-1 whitespace-pre-line leading-relaxed font-mono">
                    {movie.aiAssistResult}
                  </div>
                )}
              </div>

              <div className="mt-4 flex justify-between items-center border-t border-white/5 pt-3">
                <span className="text-[10px] text-gray-500 font-mono">ID: {movie.id}</span>
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-gray-400">Status:</span>
                  <select 
                    value={movie.status} 
                    onChange={(e) => saveMovieChanges(movie.id, { status: e.target.value })}
                    className="bg-black/40 border border-white/10 rounded px-1.5 py-0.5 text-[10px] outline-none text-white cursor-pointer"
                  >
                    <option value="Now Showing">Now Showing</option>
                    <option value="Upcoming">Upcoming</option>
                  </select>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black/85 flex items-center justify-center z-[130] p-4 backdrop-blur-sm animate-fade-in">
          <div className="glass-dark p-6 rounded-3xl w-full max-w-lg relative overflow-hidden border border-white/10">
            <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 to-orange-500"></div>
            <button onClick={() => setShowAddModal(false)} className="absolute top-4 right-4 text-xl text-gray-400 hover:text-white transition-colors">✕</button>
            <h2 className="text-2xl font-black mb-4">🎬 Add New Movie</h2>
            <form onSubmit={handleAddMovie} className="space-y-4">
              <div>
                <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Movie Title</label>
                <input className="input-field" placeholder="e.g. Inception" value={newTitle} onChange={e=>setNewTitle(e.target.value)} required />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Genre (comma-separated)</label>
                  <input className="input-field" placeholder="Action, Sci-Fi" value={newGenre} onChange={e=>setNewGenre(e.target.value)} required />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Language</label>
                  <input className="input-field" placeholder="English" value={newLang} onChange={e=>setNewLang(e.target.value)} required />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Base Price (₹)</label>
                  <input className="input-field" type="number" value={newPrice} onChange={e=>setNewPrice(e.target.value)} required />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Demand Profile</label>
                  <select className="input-field" value={newDemand} onChange={e=>setNewDemand(e.target.value)}>
                    <option value="low">Low (Offers Enabled)</option>
                    <option value="medium">Medium (Standard)</option>
                    <option value="high">High (Surge Active)</option>
                  </select>
                </div>
              </div>
              <div>
                <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Poster Image URL (Optional)</label>
                <input className="input-field" placeholder="https://..." value={newPoster} onChange={e=>setNewPoster(e.target.value)} />
              </div>
              <div>
                <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Short Description</label>
                <textarea className="input-field h-20 resize-none" placeholder="Enter synopsis..." value={newDesc} onChange={e=>setNewDesc(e.target.value)} />
              </div>
              <button className="btn-primary w-full py-3 shadow-[0_0_20px_rgba(244,63,94,0.3)] mt-2">Publish Movie</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const AdminDashboard = ({ user }) => {
  // NOTE: Hooks MUST be called unconditionally per React rules.
  // The access check happens AFTER all hooks below.
  
  const [tab, setTab] = useState('analytics');

  // Dynamic screen and theater lists
  const [screensList, setScreensList] = useState(['Screen Alpha', 'Screen Beta', 'Screen Gamma']);
  const [newScreenName, setNewScreenName] = useState('');
  const [theatersList, setTheatersList] = useState(['KaraiCini Premium', 'KaraiCini IMAX']);
  const [newTheaterName, setNewTheaterName] = useState('');
  const [selectedTheater, setSelectedTheater] = useState('KaraiCini Premium');

  const addTheater = () => {
    if (!newTheaterName.trim()) return alert('Please enter a theater name.');
    setTheatersList([...theatersList, newTheaterName]);
    setSelectedTheater(newTheaterName);
    setNewTheaterName('');
    alert('New theater added successfully!');
  };

  const addScreen = () => {
    if (!newScreenName.trim()) return alert('Please enter a screen name.');
    setScreensList([...screensList, newScreenName]);
    setSelectedConfigScreen(newScreenName);
    setNewScreenName('');
    alert('New screen added successfully!');
  };

  const optimizeSeatingLayout = () => {
    const newMatrix = { ...seatConfigMatrix };
    'ABCDEFGH'.split('').forEach(row => {
      for(let col=1; col<=12; col++) {
        const key = `${row}${col}`;
        if (row === 'H' || row === 'G') newMatrix[key] = 'Recliner';
        else if (row === 'F' || row === 'E' || row === 'D') newMatrix[key] = 'Gold';
        else if (row === 'A' && (col === 1 || col === 12)) newMatrix[key] = 'Accessibility';
        else if (row === 'A' && col >= 5 && col <= 8) newMatrix[key] = 'Maintenance Lock';
        else newMatrix[key] = 'Silver';
      }
    });
    setSeatConfigMatrix(newMatrix);
    alert('AI Seating Optimization applied! VIP Recliners configured on Rows G-H, Premium Gold on Rows D-F, Wheelchair seats placed at entry corners of Row A, and low-viewing-angle front-center seats locked for maintenance check.');
  };

  // RBAC State
  const [adminRole, setAdminRole] = useState('Super Admin');
  const rolePermissions = {
    'Super Admin': { read: true, write: true, price: true, security: true, delete: true },
    'Theater Manager': { read: true, write: true, price: false, security: false, delete: false },
    'Finance Admin': { read: true, write: false, price: true, security: false, delete: false },
    'Customer Support Admin': { read: true, write: false, price: false, security: false, delete: false },
    'Marketing Admin': { read: true, write: false, price: true, security: false, delete: false }
  };
  const currentPerms = rolePermissions[adminRole];

  // Dynamic Pricing State
  const [basePrice, setBasePrice] = useState(250);
  const [weekendPriceMulti, setWeekendPriceMulti] = useState(1.15);
  const [holidayPriceMulti, setHolidayPriceMulti] = useState(1.25);
  const [enableAutoOccupancy, setEnableAutoOccupancy] = useState(true);
  const [enableTrendPricing, setEnableTrendPricing] = useState(true);

  // EOC Warnings State
  const [eocPaymentGatewayBypass, setEocPaymentGatewayBypass] = useState(false);
  const [eocOvercrowdingWarning, setEocOvercrowdingWarning] = useState(false);
  const [eocServerBypass, setEocServerBypass] = useState(false);

  // AI Copilot Q&A state
  const [copilotQuestion, setCopilotQuestion] = useState('');
  const [copilotAnswer, setCopilotAnswer] = useState(null);
  const [isCopilotTyping, setIsCopilotTyping] = useState(false);

  // AI Model Retrain State
  const [isTraining, setIsTraining] = useState(false);
  const [modelAccuracy, setModelAccuracy] = useState(94.2);

  // Screen seat configuration selector state
  const [selectedConfigScreen, setSelectedConfigScreen] = useState('Screen Alpha');
  const [seatConfigMatrix, setSeatConfigMatrix] = useState(() => {
    const defaultMatrix = {};
    'ABCDEFGH'.split('').forEach(row => {
      for(let col=1; col<=12; col++) {
        let type = 'Silver';
        if (row === 'H' || row === 'G') type = 'Recliner';
        else if (row === 'F' || row === 'E' || row === 'D') type = 'Gold';
        defaultMatrix[`${row}${col}`] = type;
      }
    });
    return defaultMatrix;
  });

  // Ticket scanner state
  const [scannerInput, setScannerInput] = useState('');
  const [scannerResult, setScannerResult] = useState(null);

  // Chatbot configurations
  const [unresolvedConversations, setUnresolvedConversations] = useState([
    { id: 'chat1', user: 'Aarav Sharma', text: 'Cancellation of BK927164 refund timeline?', status: 'Needs Action' },
    { id: 'chat2', user: 'Neha Kapoor', text: 'Voice booking failed on Deadpool title matching.', status: 'Pending' }
  ]);
  const [chatbotRules, setChatbotRules] = useState([
    { phrase: 'price', reply: 'Base ticket prices are dynamic. Standard ticket prices start at ₹200.' },
    { phrase: 'parking', reply: 'VIP parking can be reserved during payment for just ₹100 extra.' }
  ]);
  const [newRulePhrase, setNewRulePhrase] = useState('');
  const [newRuleReply, setNewRuleReply] = useState('');

  // Active bookings list mutation state
  const [activeBookingsList, setActiveBookingsList] = useState([...KC.BOOKINGS]);

  // Snack Inventory list state
  const [snackInventory, setSnackInventory] = useState([
    { id: 'sn1', name: 'Large Popcorn', price: 220, stock: 45, threshold: 10, alert: false },
    { id: 'sn2', name: 'Cheese Nachos', price: 180, stock: 8, threshold: 15, alert: true },
    { id: 'sn3', name: 'Cold Drink Combo', price: 160, stock: 80, threshold: 20, alert: false },
    { id: 'sn4', name: 'Crispy Burger', price: 199, stock: 12, threshold: 10, alert: false },
    { id: 'sn5', name: 'Chocolate Brownie', price: 149, stock: 4, threshold: 10, alert: true }
  ]);

  // Showtimes state
  const [showsList, setShowsList] = useState([
    { id: 's1', movie: 'Pushpa 2', screen: 'Screen Alpha', time: '12:00 PM', price: 260, isAiScheduled: true },
    { id: 's2', movie: 'Kalki 2898-AD', screen: 'Screen Beta', time: '2:45 PM', price: 280, isAiScheduled: true },
    { id: 's3', movie: 'Stree 2', screen: 'Screen Gamma', time: '5:30 PM', price: 220, isAiScheduled: false }
  ]);
  const [showMovieSelect, setShowMovieSelect] = useState('Pushpa 2');
  const [showScreenSelect, setShowScreenSelect] = useState('Screen Alpha');
  const [showTimeSelect, setShowTimeSelect] = useState('8:00 PM');
  const [showPriceInput, setShowPriceInput] = useState(250);
  const [aiSchedulerEnabled, setAiSchedulerEnabled] = useState(true);

  // ── NEW FEATURE STATES ──────────────────────────────────────────────

  // Complaints Center
  const [complaints, setComplaints] = useState([
    { id:'c1', user:'Aarav Sharma', email:'aarav@example.com', type:'Refund', priority:'High', status:'Open', msg:'I cancelled my booking BK927164 three days ago but still no refund credited to my account.', time:'2h ago', bookingId:'BK927164' },
    { id:'c2', user:'Neha Kapoor', email:'neha@example.com', type:'Technical', priority:'Medium', status:'In Progress', msg:'App crashed when trying to select seats for Moana 2 show on Friday evening.', time:'5h ago', bookingId:null },
    { id:'c3', user:'Ravi Menon', email:'ravi@example.com', type:'Food', priority:'Low', status:'Resolved', msg:'Ordered nachos during booking but they were not delivered to my seat during the movie.', time:'1d ago', bookingId:'BK811240' },
    { id:'c4', user:'Priya Iyer', email:'priya@example.com', type:'Seat', priority:'High', status:'Open', msg:'My booked seat B7 was already occupied by another person at the theater. Staff did nothing to help.', time:'3h ago', bookingId:'BK543891' },
    { id:'c5', user:'Sanjay Gupta', email:'sanjay@example.com', type:'Payment', priority:'High', status:'Open', msg:'Payment was deducted twice for the same booking. Please investigate and refund the extra amount.', time:'6h ago', bookingId:'BK672310' },
  ]);
  const [selectedComplaint, setSelectedComplaint] = useState(null);
  const [complaintReply, setComplaintReply] = useState('');
  const [complaintFilterStatus, setComplaintFilterStatus] = useState('All');

  // Deepfake Ticket Detection
  const [deepfakeInput, setDeepfakeInput] = useState('');
  const [deepfakeResult, setDeepfakeResult] = useState(null);
  const [deepfakeLog, setDeepfakeLog] = useState([
    { id:'DT001', ticketId:'BK927164', time:'10:22 AM', verdict:'GENUINE', confidence:99.1, method:'Cryptographic Hash' },
    { id:'DT002', ticketId:'FAKE-99123', time:'10:45 AM', verdict:'DEEPFAKE', confidence:98.7, method:'Pixel Entropy Analysis' },
    { id:'DT003', ticketId:'BK811240', time:'11:03 AM', verdict:'GENUINE', confidence:97.4, method:'QR Signature Match' },
  ]);

  // Emotion-Based Recommendation
  const [emotionSelected, setEmotionSelected] = useState(null);
  const [emotionRecs, setEmotionRecs] = useState([]);
  const [emotionLoading, setEmotionLoading] = useState(false);
  const emotionMap = {
    '😄 Happy':     ['Moana 2','Inside Out 2','The Wild Robot','Wicked'],
    '😢 Sad':       ['The Wild Robot','Lucky Bhaskar','Amaran','Vettaiyan'],
    '😡 Angry':     ['Pushpa 2: The Rule','Deadpool & Wolverine','Gladiator II','Bad Boys: Ride or Die'],
    '😱 Scared':    ['Alien: Romulus','Stree 2','Munjya','Vettaiyan'],
    '🤩 Excited':   ['Dune: Part Two','Kalki 2898-AD','Furiosa: A Mad Max Saga','Devara: Part 1'],
    '😌 Relaxed':   ['Inside Out 2','Moana 2','Wicked','The Wild Robot'],
    '🥰 Romantic':  ['Wicked','Lucky Bhaskar','Amaran'],
    '🧐 Curious':   ['Dune: Part Two','Kalki 2898-AD','Alien: Romulus','Furiosa: A Mad Max Saga'],
  };
  const getEmotionRecs = (emotion) => {
    setEmotionSelected(emotion);
    setEmotionLoading(true);
    setEmotionRecs([]);
    setTimeout(() => {
      const titles = emotionMap[emotion] || [];
      const found = KC.MOVIES.filter(m => titles.some(t => m.title.includes(t.split(':')[0].trim())));
      setEmotionRecs(found.slice(0,4));
      setEmotionLoading(false);
    }, 800);
  };

  // Crowd Prediction
  const [crowdDate, setCrowdDate] = useState('Saturday');
  const crowdData = {
    'Saturday':  [12,35,60,88,95,99,85,60],
    'Sunday':    [10,28,55,80,92,96,78,55],
    'Monday':    [5, 18,30,55,60,65,50,30],
    'Friday':    [15,40,65,85,90,94,80,58],
    'Wednesday': [4, 12,25,40,48,52,38,20],
  };

  // AI Module Control Toggles
  const [aiModules, setAiModules] = useState({
    recommendations: { name: 'Recommendation Engine', icon: '🎯', enabled: true, desc: 'Suggests movies to users based on watch history & mood' },
    dynamicPricing: { name: 'Dynamic Pricing AI', icon: '💰', enabled: true, desc: 'Automatically adjusts ticket prices based on demand & time' },
    chatbot: { name: 'AI Customer Chatbot', icon: '🤖', enabled: true, desc: 'Handles customer queries, refund requests, and FAQs automatically' },
    fraudDetect: { name: 'Fraud Detection AI', icon: '🔍', enabled: true, desc: 'Scans for fake tickets, promo abuse, and suspicious logins' },
    crowdPredict: { name: 'Crowd Prediction AI', icon: '📈', enabled: true, desc: 'Predicts occupancy and staffing needs per screen' },
    sentimentAI: { name: 'Sentiment Analyzer', icon: '🧠', enabled: false, desc: 'Scans social media for audience sentiment toward each movie' },
  });
  const toggleAiModule = (key) => setAiModules(prev => ({ ...prev, [key]: { ...prev[key], enabled: !prev[key].enabled } }));

  // Complaint reply history log
  const [complaintHistory, setComplaintHistory] = useState([]);
  const addComplaintHistory = (complaint, reply, action) => {
    setComplaintHistory(prev => [{ id: Date.now(), complaintId: complaint.id, user: complaint.user, reply, action, time: new Date().toLocaleTimeString() }, ...prev.slice(0, 9)]);
  };

  // Theater screen quick-action state
  const [theaterNotifMsg, setTheaterNotifMsg] = useState('');


  // Demand Forecasting
  const [forecastRunning, setForecastRunning] = useState(false);
  const [forecastResult, setForecastResult] = useState(null);
  const runForecast = () => {
    setForecastRunning(true);
    setForecastResult(null);
    setTimeout(() => {
      setForecastResult({
        topMovie: 'Pushpa 2: The Rule',
        peakDay: 'Saturday 9 PM',
        expectedRevenue: '₹1,24,500',
        occupancy: '96.8%',
        lowPerformer: 'Gladiator II (28% occupancy — add discount offers)',
        surgeSlots: ['Fri 9 PM','Sat 6 PM','Sat 9 PM','Sun 6 PM'],
        aiTip: 'Increase screen allocation for Pushpa 2 on Saturday. Move Gladiator II to smaller Screen Gamma and apply FLAT150 promo.',
      });
      setForecastRunning(false);
    }, 2000);
  };

  // Sentiment Analysis
  const [sentimentMovie, setSentimentMovie] = useState('Pushpa 2: The Rule');
  const [sentimentData, setSentimentData] = useState(null);
  const [sentimentRunning, setSentimentRunning] = useState(false);
  const runSentiment = () => {
    setSentimentRunning(true);
    setSentimentData(null);
    setTimeout(() => {
      const seed = sentimentMovie.length;
      setSentimentData({
        positive: 60 + (seed % 30),
        neutral: 5 + (seed % 15),
        negative: 2 + (seed % 8),
        topPositive: ['Stunning visuals','Allu Arjun performance','Thrilling action','Excellent BGM'],
        topNegative: ['Too long runtime','Predictable story','Weak second half'],
        overall: seed % 3 === 0 ? 'Blockbuster' : seed % 3 === 1 ? 'Hit' : 'Superhit',
        twitterScore: (7.5 + (seed % 25)/10).toFixed(1),
        imdbScore: (7.0 + (seed % 20)/10).toFixed(1),
      });
      setSentimentRunning(false);
    }, 1200);
  };

  // Marketing Campaign Generator
  const [campTarget, setCampTarget] = useState('All Users');
  const [campMovie, setCampMovie] = useState('Pushpa 2: The Rule');
  const [campType, setCampType] = useState('Email + Push');
  const [campOffer, setCampOffer] = useState('SAVE20');
  const [generatedCampaign, setGeneratedCampaign] = useState(null);
  const [campGenerating, setCampGenerating] = useState(false);
  const generateCampaign = () => {
    setCampGenerating(true);
    setGeneratedCampaign(null);
    setTimeout(() => {
      setGeneratedCampaign({
        subject: `🎬 Don't Miss ${campMovie} — Exclusive ${campOffer} Offer Inside!`,
        headline: `Your Weekend Plans Just Got Better!`,
        body: `Hey Cinephile! AI has spotted that you enjoy ${campMovie.includes('Pushpa') ? 'action blockbusters' : campMovie.includes('Moana') ? 'animated adventures' : 'cinematic masterpieces'}. This weekend, catch ${campMovie} at KaraiCini and enjoy ${campOffer} on your booking. Limited seats available — book before they fill up!`,
        cta: 'BOOK NOW →',
        estimatedReach: campTarget === 'All Users' ? '12,450 users' : campTarget === 'Premium' ? '3,200 users' : '5,800 users',
        predictedCTR: (12 + Math.floor(campMovie.length / 5)) + '%',
        channel: campType,
        scheduledTime: 'Tonight at 7:00 PM IST (AI-optimized slot)',
      });
      setCampGenerating(false);
    }, 1500);
  };

  // Fraud Detection
  const [fraudLog, setFraudLog] = useState([
    { id:'F001', type:'Multi-device Login', user:'u_unknown_99', risk:'Critical', ip:'185.234.x.x', time:'11:02 AM', status:'Blocked' },
    { id:'F002', type:'Rapid Seat Holding', user:'Sanjay Gupta', risk:'High', ip:'49.207.x.x', time:'11:18 AM', status:'Flagged' },
    { id:'F003', type:'Payment Card Mismatch', user:'anonymous_7', risk:'High', ip:'103.45.x.x', time:'11:34 AM', status:'Blocked' },
    { id:'F004', type:'Screenshot QR Detected', user:'Ravi_scan', risk:'Medium', ip:'N/A (local scan)', time:'12:01 PM', status:'Denied Entry' },
    { id:'F005', type:'Promo Code Abuse (30x)', user:'promo_bot_44', risk:'Medium', ip:'45.88.x.x', time:'12:22 PM', status:'Flagged' },
  ]);
  const [fraudScanInput, setFraudScanInput] = useState('');
  const [fraudScanResult, setFraudScanResult] = useState(null);
  const runFraudScan = () => {
    if (!fraudScanInput.trim()) return;
    const known = KC.BOOKINGS.find(b => b.id === fraudScanInput.trim());
    if (known && known.status !== 'cancelled') {
      setFraudScanResult({ safe: true, msg: `✅ Booking ${fraudScanInput} verified clean. No fraud signals detected. Payment verified. User identity matched.` });
    } else if (fraudScanInput.toLowerCase().includes('fake') || fraudScanInput.toLowerCase().includes('bot')) {
      setFraudScanResult({ safe: false, msg: `🚨 FRAUD ALERT: Booking ID matches known bot pattern. IP flagged in fraud database. Entry blocked. Report filed.` });
    } else {
      setFraudScanResult({ safe: false, msg: `⚠️ SUSPICIOUS: Booking ID not found in database. Possible forged ticket. QR entropy mismatch detected. Manual inspection recommended.` });
    }
  };

  // Staff Management
  const [adminUsers, setAdminUsers] = useState(KC.USERS.filter(u => u.role === 'admin'));
  const [newAdminName, setNewAdminName] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [newAdminRole, setNewAdminRole] = useState('Theater Manager');

  const handleAddAdmin = (e) => {
    e.preventDefault();
    if (!currentPerms.security) return alert('Permission Denied. You do not have security rights to add users.');
    const u = {
      id: 'a' + Date.now(),
      name: newAdminName,
      email: newAdminEmail,
      password: newAdminPassword,
      role: 'admin',
      adminType: newAdminRole,
      phone: 'N/A',
      prefLangs: ['English']
    };
    KC.USERS.push(u);
    if(typeof localStorage !== 'undefined') {
        localStorage.setItem('kc_users', JSON.stringify(KC.USERS));
    }
    setAdminUsers(KC.USERS.filter(user => user.role === 'admin'));
    alert(`${newAdminRole} account created for ${newAdminName}!`);
    setNewAdminName('');
    setNewAdminEmail('');
    setNewAdminPassword('');
  };

  // ── NEW FEATURE: Live AI Surveillance ──────────────────────────────────
  const [surveillanceTick, setSurveillanceTick] = useState(0);
  const [surveillanceAlerts, setSurveillanceAlerts] = useState([
    { id:'al1', zone:'Main Lobby', type:'Crowd', msg:'Crowd density exceeds safe threshold (94%). Deploy 2 extra staff.', time:'2 min ago', severity:'High' },
    { id:'al2', zone:'Snack Counter A', msg:'Queue length: 28 people. Estimated wait: 12 min. Open Counter B.', time:'5 min ago', severity:'Medium', type:'Queue' },
    { id:'al3', zone:'Screen Beta Entry', msg:'Anomalous loitering detected near emergency exit door B3.', time:'9 min ago', severity:'High', type:'Security' },
  ]);
  const cctv_zones = [
    { id:'z1', name:'Main Lobby', crowd:82, temp:24, status:'Alert' },
    { id:'z2', name:'Screen Alpha', crowd:96, temp:22, status:'Full' },
    { id:'z3', name:'Screen Beta', crowd:45, temp:21, status:'Normal' },
    { id:'z4', name:'Snack Counter A', crowd:74, temp:25, status:'Busy' },
    { id:'z5', name:'Parking Lobby', crowd:33, temp:32, status:'Normal' },
    { id:'z6', name:'Emergency Exit B3', crowd:5, temp:27, status:'Alert' },
  ];
  const dismissAlert = (id) => setSurveillanceAlerts(a => a.filter(x => x.id !== id));

  // ── NEW FEATURE: Predictive Hardware Maintenance ──────────────────────
  const [hardwareList, setHardwareList] = useState([
    { id:'hw1', device:'4K IMAX Projector', screen:'Screen Alpha', health:92, temp:61, hours:4820, lastService:'2025-12-01', nextService:'2026-06-01', status:'Good', risk:'Low', issue:null },
    { id:'hw2', device:'Dolby Atmos Speakers', screen:'Screen Alpha', health:78, temp:44, hours:6210, lastService:'2025-09-15', nextService:'2026-03-15', status:'Warning', risk:'Medium', issue:'Subwoofer L3 shows 12% distortion' },
    { id:'hw3', device:'4K Laser Projector', screen:'Screen Beta', health:55, temp:74, hours:9800, lastService:'2025-06-01', nextService:'2025-12-01', status:'Critical', risk:'High', issue:'Overheating: GPU core >70°C for 3+ days. Failure probability 67% in 14 days.' },
    { id:'hw4', device:'Central AC Unit', screen:'All Screens', health:88, temp:20, hours:12400, lastService:'2026-01-10', nextService:'2026-07-10', status:'Good', risk:'Low', issue:null },
    { id:'hw5', device:'Security Camera Array', screen:'Lobby + Exits', health:44, temp:52, hours:17600, lastService:'2025-03-01', nextService:'2025-09-01', status:'Critical', risk:'High', issue:'Camera #7 and #12 offline. Blind spots detected in parking area.' },
  ]);
  const [hwRunningDiag, setHwRunningDiag] = useState(null);
  const runHwDiag = (id) => {
    setHwRunningDiag(id);
    setTimeout(() => setHwRunningDiag(null), 2000);
  };

  // ── NEW FEATURE: VIP Customer CRM ──────────────────────────────────────
  const [vipFilter, setVipFilter] = useState('All');
  const [vipSelectedUser, setVipSelectedUser] = useState(null);
  const [vipOfferSent, setVipOfferSent] = useState({});
  const vipCustomers = [
    { id:'v1', name:'Rajesh Nair', email:'rajesh@example.com', tier:'Platinum', totalSpent:28400, visits:34, lastVisit:'2 days ago', favGenre:'Action/Thriller', favSeat:'H7 (Recliner)', favSnack:'Caramel Popcorn + Cold Brew', points:3240, trend:'↑', tags:['Early Bird','High Value','VIP Pass'] },
    { id:'v2', name:'Deepika Menon', email:'deepika@example.com', tier:'Gold', totalSpent:14200, visits:18, lastVisit:'1 week ago', favGenre:'Romance/Drama', favSeat:'F5 (Gold)', favSnack:'Cheese Nachos', points:1620, trend:'→', tags:['Repeat Buyer'] },
    { id:'v3', name:'Arjun Krishnamurthy', email:'arjun@example.com', tier:'Platinum', totalSpent:41800, visits:52, lastVisit:'Yesterday', favGenre:'Sci-Fi/Fantasy', favSeat:'H12 (Recliner)', favSnack:'Popcorn Combo + Brownie', points:5100, trend:'↑', tags:['Whale','VIP Pass','Loyalty Elite'] },
    { id:'v4', name:'Priya Subramaniam', email:'priya.sub@example.com', tier:'Silver', totalSpent:6800, visits:9, lastVisit:'3 weeks ago', favGenre:'Family/Animation', favSeat:'D3 (Gold)', favSnack:'Hot Dog + Juice', points:820, trend:'↓', tags:['Lapsing'] },
  ];
  const sendVipOffer = (customerId, offerCode) => {
    setVipOfferSent(prev => ({ ...prev, [customerId]: offerCode }));
  };

  // Smart Theater Optimization
  const [theaterOptScreen, setTheaterOptScreen] = useState('Screen Alpha');
  const [theaterOptResult, setTheaterOptResult] = useState(null);
  const [theaterOptRunning, setTheaterOptRunning] = useState(false);
  const runTheaterOpt = () => {
    setTheaterOptRunning(true);
    setTheaterOptResult(null);
    setTimeout(() => {
      setTheaterOptResult({
        screen: theaterOptScreen,
        recommendations: [
          { area: 'Seating Layout', action: 'Recliner row H is underutilized (22% booking). Convert 4 seats to Gold Premium to increase revenue.', impact: '+₹3,200/week' },
          { area: 'Lighting', action: 'AI detected 3 aisle lights malfunctioning. Schedule maintenance before Saturday shows.', impact: 'Safety Compliance' },
          { area: 'AC Temperature', action: 'Audience feedback scores cooling 3.2/5. Recommend lowering set temp from 22°C to 20°C.', impact: '+0.4 Satisfaction' },
          { area: 'Screen Allocation', action: `Move Gladiator II to ${theaterOptScreen === 'Screen Alpha' ? 'Screen Gamma' : 'Screen Beta'} and schedule Pushpa 2 for the larger screen on peak hours.`, impact: '+₹8,000/day' },
          { area: 'Crowd Flow', action: 'Entry Gate 2 causes 4-minute avg delay. AI recommends opening Gate 3 from 6 PM onwards.', impact: '-62% Wait Time' },
        ],
        aiScore: 87,
      });
      setTheaterOptRunning(false);
    }, 1800);
  };

  // Copilot preset answers
  const askCopilot = (question) => {
    setIsCopilotTyping(true);
    setCopilotAnswer(null);
    setTimeout(() => {
      let ans = "";
      if (question.includes('revenue')) {
        ans = "📊 AI Analysis: 'Pushpa 2' is forecast to generate maximum revenue next week, contributing 42% of total box office revenue. Current pre-booking trend shows an 18% spike in weekend night show slots.";
      } else if (question.includes('dropping')) {
        ans = "📉 AI Diagnostics: Bookings dropped 4.2% on Wednesday afternoon. Analytics attribute this to an overlap with a regional festival holiday. Bookings are predicted to rebound by 28% starting Friday evening.";
      } else if (question.includes('marketing')) {
        ans = "💡 Recommended Marketing Playbook:\n1. Retarget low-occupancy matinee seats with a 20% discount code to users who watch animation genre.\n2. Push Moana 2 snack combo alerts to families booking seats in rows A-D.";
      } else if (question.includes('churn')) {
        ans = "⚠️ Churn Prediction Risk: 14 target users have not booked a ticket in 45 days. Recommendation: Auto-send personalized discount vouchers ('WELCOMEBACK15') to customer IDs: u12, u48, and u89.";
      } else {
        ans = "🔮 Forecast: Saturday night occupancy is projected at 94.2% across Screens Alpha and Beta. Dynamic price modifier is configured to increase base rates on seat blocks F-H by 15%.";
      }
      setCopilotAnswer(ans);
      setIsCopilotTyping(false);
    }, 1000);
  };

  const handleTestQR = () => {
    if (!scannerInput.trim()) return;
    const bk = KC.BOOKINGS.find(b => b.id === scannerInput.trim() || scannerInput.trim().includes(b.id));
    if (bk) {
      if (bk.status === 'cancelled') {
        setScannerResult({ valid: false, message: '🚨 FAILED: Ticket booking has been cancelled and refunded.', color: 'text-red-400 border-red-500/20 bg-red-500/10' });
      } else {
        setScannerResult({ valid: true, message: `✅ VERIFIED: Ticket Valid. Movie: "${bk.movieTitle}", Seats: ${bk.seats.join(', ')}. Entry Permitted.`, color: 'text-green-400 border-green-500/20 bg-green-500/10' });
      }
    } else if (scannerInput.toLowerCase().includes('screenshot') || scannerInput.toLowerCase().includes('fake')) {
      setScannerResult({ valid: false, message: '🚨 CRITICAL WARNING: Deepfake / screenshot tampering detected! Validation rejected.', color: 'text-red-500 border-red-600 bg-red-500/20 font-bold animate-pulse' });
    } else {
      setScannerResult({ valid: false, message: '🚨 INVALID: QR signature does not match database encryption.', color: 'text-yellow-400 border-yellow-500/20 bg-yellow-500/10' });
    }
  };

  const triggerModelRetrain = () => {
    setIsTraining(true);
    setTimeout(() => {
      setIsTraining(false);
      setModelAccuracy(96.8);
      alert('AI Recommendation Model retrained successfully! Model Accuracy improved from 94.2% to 96.8%. User interest clusters refreshed.');
    }, 2000);
  };

  const addChatbotRule = (e) => {
    e.preventDefault();
    if (!newRulePhrase || !newRuleReply) return;
    setChatbotRules([...chatbotRules, { phrase: newRulePhrase.toLowerCase(), reply: newRuleReply }]);
    setNewRulePhrase('');
    setNewRuleReply('');
    alert('Custom response trigger added to chatbot database.');
  };

  const toggleSeatConfigType = (seatKey) => {
    if (!currentPerms.price) {
      return alert('Permission Denied: Your current Role does not allow modifying dynamic screen price layout assets.');
    }
    const currentType = seatConfigMatrix[seatKey];
    let nextType = 'Silver';
    if (currentType === 'Silver') nextType = 'Gold';
    else if (currentType === 'Gold') nextType = 'Recliner';
    else if (currentType === 'Recliner') nextType = 'Accessibility';
    else if (currentType === 'Accessibility') nextType = 'Maintenance Lock';
    else nextType = 'Silver';

    setSeatConfigMatrix({ ...seatConfigMatrix, [seatKey]: nextType });
  };

  const deleteBookingItem = (bookingId) => {
    if (!currentPerms.delete) return alert('Permission Denied: Role has insufficient security permissions to delete database transactions.');
    if (confirm('Cancel and refund this booking?')) {
      const target = KC.BOOKINGS.find(b => b.id === bookingId);
      if (target) {
        target.status = 'cancelled';
        KC.saveBookings();
        setActiveBookingsList([...KC.BOOKINGS]);
        alert('Booking cancelled and marked for refund.');
      }
    }
  };

  const addNewShow = (e) => {
    e.preventDefault();
    
    // Prevent scheduling conflicts
    const conflict = showsList.find(s => s.screen === showScreenSelect && s.time === showTimeSelect);
    if (conflict) {
      if (confirm(`⚠️ SCHEDULING CONFLICT: ${showScreenSelect} is already booked at ${showTimeSelect} for "${conflict.movie}".\n\nWould you like AI to resolve this conflict automatically?`)) {
        // Shift time by 15 mins
        let timeParts = showTimeSelect.split(' ');
        let [h, m] = timeParts[0].split(':').map(Number);
        m = (m || 0) + 15;
        if (m >= 60) {
          h += 1;
          m -= 60;
        }
        const newTime = `${h}:${m.toString().padStart(2, '0')} ${timeParts[1]}`;
        
        const newShow = {
          id: 's' + Date.now(),
          movie: showMovieSelect,
          screen: showScreenSelect,
          time: newTime,
          price: Number(showPriceInput),
          isAiScheduled: true,
          aiNotes: `AI Resolution: Shifted showtime from ${showTimeSelect} to prevent conflict with "${conflict.movie}".`
        };
        setShowsList([...showsList, newShow]);
        alert(`Conflict resolved! Showtime shifted and published for ${newTime}.`);
      }
      return;
    }
    
    const newShow = {
      id: 's' + Date.now(),
      movie: showMovieSelect,
      screen: showScreenSelect,
      time: showTimeSelect,
      price: Number(showPriceInput),
      isAiScheduled: aiSchedulerEnabled
    };
    setShowsList([...showsList, newShow]);
    alert('Show schedule created successfully!');
  };

  const cancelShowItem = (showId) => {
    if (confirm('Are you sure you want to cancel this show? All booked customers will be automatically refunded.')) {
      setShowsList(showsList.filter(s => s.id !== showId));
      alert('Show cancelled. Automated EOC script dispatched notifications to affected users.');
    }
  };

  // Access check happens here (after all hooks) to avoid Rules of Hooks violation
  if (!user || user.role !== 'admin') {
    return <div className="text-center p-12 text-red-500 font-bold text-xl mt-20">⛔ Access Denied. Admin privileges required.</div>;
  }

  return (
    <div className="animate-fade-in pb-20">
      {/* Dynamic Emergency Center Top Warning Bar */}
      {(eocPaymentGatewayBypass || eocOvercrowdingWarning || eocServerBypass) && (
        <div className="mb-6 p-4 bg-red-600 border border-red-500 rounded-2xl flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-3 text-white">
            <span className="text-2xl">🚨</span>
            <div>
              <h4 className="font-bold text-sm">Emergency Operations Override Active</h4>
              <p className="text-xs opacity-90">
                {eocPaymentGatewayBypass && "[Backup Gateway Triggered] "}
                {eocOvercrowdingWarning && "[Crowd Overcrowding Alert Dispatched] "}
                {eocServerBypass && "[Server Load Balancer Bypass Enabled]"}
              </p>
            </div>
          </div>
          <button 
            onClick={() => { setEocPaymentGatewayBypass(false); setEocOvercrowdingWarning(false); setEocServerBypass(false); }} 
            className="bg-white/20 hover:bg-white/30 text-white font-bold text-xs px-3 py-1.5 rounded-lg transition-colors border border-white/20"
          >
            Clear Override
          </button>
        </div>
      )}

      <div className="flex flex-col lg:flex-row gap-8 items-start">
        {/* Left Side Tab Navigation */}
        <div className="w-full lg:w-64 bg-black/40 border border-white/10 rounded-3xl p-5 space-y-2 shrink-0">
          <div className="px-3 py-2 border-b border-white/5 mb-4">
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">Navigation Control</h3>
            {/* RBAC Quick Swapper */}
            <div className="mt-3">
              <label className="text-[9px] text-gray-400 font-bold block mb-1">Active Admin Role:</label>
              <select 
                value={adminRole} 
                onChange={(e) => {
                  const role = e.target.value;
                  setAdminRole(role);
                  if (role === 'Theater Manager') setTab('catalog');
                  else if (role === 'Finance Admin') setTab('pricing');
                  else if (role === 'Customer Support Admin') setTab('complaints');
                  else if (role === 'Marketing Admin') setTab('marketing');
                  else setTab('analytics');
                }} 
                className="w-full bg-black/60 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-red-500 cursor-pointer"
              >
                <option value="Super Admin">🛡️ Super Admin</option>
                <option value="Theater Manager">🎬 Theater Manager</option>
                <option value="Finance Admin">💰 Finance Admin</option>
                <option value="Customer Support Admin">👤 Customer Support Admin</option>
                <option value="Marketing Admin">📈 Marketing Admin</option>
              </select>
            </div>
          </div>

          {['Super Admin', 'Finance Admin', 'Marketing Admin'].includes(adminRole) && (
            <button onClick={() => setTab('analytics')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'analytics' ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>📊</span> Analytics Control
            </button>
          )}

          {['Super Admin', 'Theater Manager'].includes(adminRole) && (
            <button onClick={() => setTab('catalog')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'catalog' ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>🎬</span> Catalog & Screens
            </button>
          )}

          {['Super Admin', 'Finance Admin'].includes(adminRole) && (
            <button onClick={() => setTab('pricing')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'pricing' ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>💰</span> Smart Pricing
            </button>
          )}

          {['Super Admin', 'Theater Manager'].includes(adminRole) && (
            <button onClick={() => setTab('copilot')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'copilot' ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>🤖</span> AI Copilot Lab
            </button>
          )}

          {['Super Admin'].includes(adminRole) && (
            <button onClick={() => setTab('security')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'security' ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>🚨</span> Security & EOC
            </button>
          )}

          {['Super Admin'].includes(adminRole) && (
            <button onClick={() => setTab('staff')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'staff' ? 'bg-gradient-to-r from-red-600 to-orange-500 text-white shadow-lg shadow-red-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>👥</span> Staff & Roles
            </button>
          )}

          {['Super Admin', 'Customer Support Admin', 'Marketing Admin'].some(r => adminRole === r) && (
            <div className="border-t border-white/5 pt-3 mt-1">
              <p className="text-[9px] text-gray-600 uppercase tracking-widest px-2 mb-2">AI Intelligence Suite</p>
            </div>
          )}

          {['Super Admin', 'Customer Support Admin'].includes(adminRole) && (
            <button onClick={() => setTab('complaints')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'complaints' ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg shadow-purple-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>📩</span> Complaints Center
            </button>
          )}

          {['Super Admin', 'Marketing Admin'].includes(adminRole) && (
            <button onClick={() => setTab('aiintel')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'aiintel' ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg shadow-purple-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>🧠</span> AI Copilot Pro
            </button>
          )}

          {['Super Admin', 'Marketing Admin'].includes(adminRole) && (
            <button onClick={() => setTab('smartanalytics')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'smartanalytics' ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg shadow-purple-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>📡</span> Smart Analytics
            </button>
          )}

          {['Super Admin', 'Marketing Admin'].includes(adminRole) && (
            <button onClick={() => setTab('marketing')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'marketing' ? 'bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg shadow-purple-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>📣</span> Marketing & Fraud
            </button>
          )}

          {['Super Admin', 'Theater Manager'].includes(adminRole) && (
            <div className="border-t border-white/5 pt-3 mt-1">
              <p className="text-[9px] text-gray-600 uppercase tracking-widest px-2 mb-2">Operations Suite</p>
            </div>
          )}

          {['Super Admin', 'Theater Manager'].includes(adminRole) && (
            <button onClick={() => setTab('surveillance')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'surveillance' ? 'bg-gradient-to-r from-cyan-600 to-blue-500 text-white shadow-lg shadow-cyan-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>📷</span> Live Surveillance
            </button>
          )}

          {['Super Admin', 'Theater Manager'].includes(adminRole) && (
            <button onClick={() => setTab('hardware')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'hardware' ? 'bg-gradient-to-r from-cyan-600 to-blue-500 text-white shadow-lg shadow-cyan-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>🛠️</span> Hardware Health
            </button>
          )}

          {['Super Admin', 'Customer Support Admin', 'Marketing Admin'].includes(adminRole) && (
            <button onClick={() => setTab('vipcrm')} className={`w-full text-left px-4 py-3 rounded-xl font-bold flex items-center gap-3 transition-all ${tab === 'vipcrm' ? 'bg-gradient-to-r from-cyan-600 to-blue-500 text-white shadow-lg shadow-cyan-500/10' : 'text-gray-400 hover:text-white hover:bg-white/5'}`}>
              <span>💎</span> VIP Customer CRM
            </button>
          )}
        </div>

        {/* Right Side Content Panel */}
        <div className="flex-1 w-full space-y-6">
          
          {/* TAB 1: EXECUTIVE ANALYTICS */}
          {tab === 'analytics' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black">📊 Executive Performance Dashboard</h2>

              {/* KPI Cards */}
              <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl relative overflow-hidden">
                  <div className="absolute right-4 top-4 text-2xl opacity-40">🎟️</div>
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Today's Bookings</span>
                  <div className="text-2xl font-black mt-2 text-white">142 tickets</div>
                  <span className="text-[10px] text-green-400 font-bold block mt-1">📈 +12.4% vs yesterday</span>
                </div>
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl relative overflow-hidden">
                  <div className="absolute right-4 top-4 text-2xl opacity-40">💰</div>
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Total Revenue</span>
                  <div className="text-2xl font-black mt-2 text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500">₹36,450</div>
                  <span className="text-[10px] text-green-400 font-bold block mt-1">📈 +8.2% vs target</span>
                </div>
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl relative overflow-hidden">
                  <div className="absolute right-4 top-4 text-2xl opacity-40">👥</div>
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Active Shoppers</span>
                  <div className="text-2xl font-black mt-2 text-white">82 users</div>
                  <span className="text-[10px] text-blue-400 font-bold block mt-1">● 14 live checkouts</span>
                </div>
                <div className="bg-white/5 border border-white/10 p-5 rounded-2xl relative overflow-hidden">
                  <div className="absolute right-4 top-4 text-2xl opacity-40">🍃</div>
                  <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block">Paperless Savings</span>
                  <div className="text-2xl font-black mt-2 text-green-400">41.2 kg CO₂</div>
                  <span className="text-[10px] text-gray-400 block mt-1">Sustainability: 98% paperless</span>
                </div>
              </div>

              {/* Advanced Graphs Segment */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Simulated Peak Booking Hours Graph */}
                <div className="glass p-5 rounded-2xl border border-white/10">
                  <h3 className="font-bold text-sm mb-4">📈 Peak Booking Hours & Occupancy Forecast</h3>
                  <div className="h-44 flex items-end justify-between px-2 pt-4 border-b border-white/10 relative">
                    <div className="absolute left-0 top-0 h-full w-full flex flex-col justify-between pointer-events-none opacity-10">
                      <div className="border-t border-white w-full"></div>
                      <div className="border-t border-white w-full"></div>
                      <div className="border-t border-white w-full"></div>
                    </div>
                    {/* Simulated bars */}
                    {[
                      { hr: '9 AM', pct: 25 },
                      { hr: '12 PM', pct: 60 },
                      { hr: '3 PM', pct: 40 },
                      { hr: '6 PM', pct: 85 },
                      { hr: '9 PM', pct: 98 },
                      { hr: '11 PM', pct: 70 }
                    ].map(bar => (
                      <div key={bar.hr} className="flex flex-col items-center gap-2 w-12 group cursor-pointer">
                        <span className="text-[10px] text-red-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity">{bar.pct}%</span>
                        <div className="w-6 bg-gradient-to-t from-red-600 to-orange-500 rounded-t-md transition-all group-hover:scale-x-110" style={{ height: `${bar.pct * 1.2}px` }}></div>
                        <span className="text-[9px] text-gray-400">{bar.hr}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Simulated Sentiment Analysis Gauge */}
                <div className="glass p-5 rounded-2xl border border-white/10 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-sm mb-1">💬 Audience Sentiment Analysis</h3>
                    <p className="text-[10px] text-gray-400 mb-4">Scanning review sites, social posts, and dynamic text ratings.</p>
                  </div>
                  <div className="flex gap-4 items-center">
                    <div className="flex-1 space-y-3">
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-400">Positive Score (Liked)</span>
                          <span className="text-green-400 font-bold">89.4%</span>
                        </div>
                        <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/10">
                          <div className="bg-green-500 h-full rounded-full" style={{ width: '89%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-400">Neutral Score</span>
                          <span className="text-yellow-400 font-bold">7.6%</span>
                        </div>
                        <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/10">
                          <div className="bg-yellow-500 h-full rounded-full" style={{ width: '8%' }}></div>
                        </div>
                      </div>
                      <div>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="text-gray-400">Negative Comments</span>
                          <span className="text-red-400 font-bold">3.0%</span>
                        </div>
                        <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden border border-white/10">
                          <div className="bg-red-500 h-full rounded-full" style={{ width: '3%' }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-orange-400 bg-orange-500/10 border border-orange-500/20 p-2.5 rounded-xl font-bold text-center mt-4">
                    💡 AI consensus verdict: "Spectacular reviews on Pushpa 2. High demand tags applied."
                  </div>
                </div>
              </div>

              {/* Demand Predictions & Ad Placement */}
              <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
                {/* Predictions Grid */}
                <div className="glass p-5 rounded-2xl border border-white/10 xl:col-span-2">
                  <h3 className="font-bold text-sm mb-4">🔮 Dynamic AI Occupancy Projections (Weekend)</h3>
                  <div className="divide-y divide-white/5">
                    {[
                      { movie: 'Pushpa 2: The Rule', demand: '98% Occupancy', trend: 'Surge Target', color: 'text-red-400 bg-red-500/10 border-red-500/20' },
                      { movie: 'Moana 2', demand: '92% Occupancy', trend: 'Optimal Flow', color: 'text-green-400 bg-green-500/10 border-green-500/20' },
                      { movie: 'Gladiator II', demand: '34% Occupancy', trend: 'Offers Suggested', color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20' }
                    ].map((item, i) => (
                      <div key={i} className="flex justify-between items-center py-3">
                        <div>
                          <h4 className="text-sm font-bold text-white">{item.movie}</h4>
                          <span className="text-[10px] text-gray-500">Predicted via ticket clickthrough rates</span>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-white text-sm">{item.demand}</div>
                          <span className={`inline-block text-[9px] px-1.5 py-0.5 rounded font-bold border ${item.color} mt-1`}>{item.trend}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Ad Placement & Sustainability */}
                <div className="glass p-5 rounded-2xl border border-white/10 space-y-4">
                  <h3 className="font-bold text-sm">💡 Advertisement Placement Intelligence</h3>
                  <div className="space-y-3">
                    <div className="p-3 bg-white/5 border border-white/5 rounded-xl">
                      <span className="text-[10px] text-blue-400 font-bold block uppercase tracking-wider">Optimal Ad Slot</span>
                      <div className="text-xs font-bold text-white mt-1">Intermission (Moana 2)</div>
                      <span className="text-[9px] text-gray-400 block mt-0.5">Target segment: Family & Kids brands</span>
                    </div>
                    <div className="p-3 bg-white/5 border border-white/5 rounded-xl">
                      <span className="text-[10px] text-purple-400 font-bold block uppercase tracking-wider">Estimated Ad Revenue</span>
                      <div className="text-xs font-bold text-white mt-1">₹14,500/week (predicted)</div>
                      <span className="text-[9px] text-gray-400 block mt-0.5">AI projection based on screen time allocation</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CATALOG & SCREENS */}
          {tab === 'catalog' && (
            <div className="space-y-8 animate-fade-in">
              {/* Movies list editor */}
              <AdminMoviesSection />

              {/* Theater layout configuration */}
              <div className="glass p-6 rounded-3xl border border-white/10">
                <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center border-b border-white/5 pb-4 mb-6 gap-6">
                  <div className="space-y-3">
                    <h3 className="text-xl font-bold flex items-center gap-2">🏛️ Theater Layouts & Accessibility</h3>
                    <p className="text-xs text-gray-400">Define VIP zones, accessibility access points, and maintenance seat blocks.</p>
                    
                    {/* Dynamic Theater Control */}
                    <div className="flex gap-2 items-center flex-wrap pt-1">
                      <div className="flex items-center gap-1.5 bg-white/5 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white">
                        <span className="text-gray-400">Theater:</span>
                        <select value={selectedTheater} onChange={e=>setSelectedTheater(e.target.value)} className="bg-transparent border-none text-white outline-none cursor-pointer text-xs font-bold font-sans">
                          {theatersList.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                      </div>
                      <div className="flex gap-1.5">
                        <input 
                          type="text" 
                          value={newTheaterName} 
                          onChange={e=>setNewTheaterName(e.target.value)} 
                          placeholder="New Theater..." 
                          className="bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white outline-none w-28 focus:border-red-500"
                        />
                        <button type="button" onClick={addTheater} className="bg-red-600 hover:bg-red-500 text-white text-xs px-3 py-1.5 rounded-xl font-bold transition-colors">Add</button>
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex flex-col gap-3 items-end w-full lg:w-auto">
                    <div className="flex gap-2 flex-wrap justify-end">
                      {screensList.map(scr => (
                        <button 
                          key={scr} 
                          type="button"
                          onClick={() => setSelectedConfigScreen(scr)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${selectedConfigScreen === scr ? 'bg-white/10 border-white/20 text-white shadow-lg' : 'bg-black/40 border-white/5 text-gray-400 hover:text-white'}`}
                        >
                          {scr}
                        </button>
                      ))}
                    </div>
                    
                    {/* Add Screen & Optimize */}
                    <div className="flex gap-2 items-center flex-wrap justify-end w-full">
                      <input 
                        type="text" 
                        value={newScreenName} 
                        onChange={e=>setNewScreenName(e.target.value)} 
                        placeholder="New Screen..." 
                        className="bg-black/40 border border-white/10 rounded-xl px-3 py-1.5 text-xs text-white outline-none w-32 focus:border-red-500"
                      />
                      <button type="button" onClick={addScreen} className="bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 text-white text-xs px-3 py-1.5 rounded-xl font-bold transition-all">Add Screen</button>
                      <button type="button" onClick={optimizeSeatingLayout} className="bg-purple-600/20 border border-purple-500/30 hover:bg-purple-600/30 text-purple-300 text-xs px-3 py-1.5 rounded-xl font-bold transition-all">✨ AI Seat Optimize</button>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center mb-6">
                  <div className="w-1/2 h-1 bg-gradient-to-b from-white/80 to-transparent rounded-[50%] opacity-20 shadow-[0_0_20px_rgba(255,255,255,0.4)]" />
                </div>

                {/* Small config seat preview grid */}
                <div className="flex flex-col gap-1 items-center overflow-x-auto pb-4 max-h-56 select-none bg-black/30 p-4 rounded-2xl border border-white/5">
                  {['A','C','E','G','H'].map(row => (
                    <div key={row} className="flex gap-1 items-center">
                      <div className="w-4 text-[10px] text-gray-500 font-bold">{row}</div>
                      <div className="flex gap-1.5">
                        {Array.from({ length: 12 }, (_, colIndex) => {
                          const col = colIndex + 1;
                          const key = `${row}${col}`;
                          const type = seatConfigMatrix[key] || 'Silver';
                          
                          let color = 'bg-white/10 border-white/20 text-white';
                          if (type === 'Recliner') color = 'bg-purple-500/20 border-purple-500/40 text-purple-400';
                          else if (type === 'Gold') color = 'bg-orange-500/20 border-orange-500/40 text-orange-400';
                          else if (type === 'Accessibility') color = 'bg-blue-500/30 border-blue-500/50 text-blue-400';
                          else if (type === 'Maintenance Lock') color = 'bg-red-500/30 border-red-500/50 text-red-500 line-through';

                          return (
                            <button 
                              key={key} 
                              type="button"
                              onClick={() => toggleSeatConfigType(key)}
                              className={`w-6 h-6 rounded flex items-center justify-center text-[8px] font-bold border transition-colors ${color}`}
                              title={`Seat ${key} - Type: ${type}`}
                            >
                              {col}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>

                <div className="flex flex-wrap gap-4 justify-center text-[10px] text-gray-400 mt-4 border-t border-white/5 pt-4">
                  <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-white/10 border border-white/20"/> Silver</div>
                  <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-orange-500/20 border border-orange-500/40"/> Gold (Premium Zone)</div>
                  <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-purple-500/20 border border-purple-500/40"/> Recliner (VIP Seat)</div>
                  <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-blue-500/30 border border-blue-500/50"/> Wheelchair (Accessibility)</div>
                  <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded bg-red-500/30 border border-red-500/50"/> Maintenance Lock</div>
                </div>

                {/* Crowd Flow & Maintenance Predictions Panel */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 pt-6 border-t border-white/5">
                  <div className="bg-purple-950/20 border border-purple-500/20 p-5 rounded-2xl">
                    <h4 className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">👥 AI Crowd Flow Prediction</h4>
                    <div className="space-y-2 text-xs">
                      <p className="text-gray-300">Target Screen: <span className="text-white font-bold">{selectedConfigScreen}</span></p>
                      <div className="p-3 bg-white/5 rounded-xl border border-white/5 space-y-2">
                        <div className="flex justify-between items-center">
                          <span>Peak Exit Congestion</span>
                          <span className="text-red-400 font-bold">78% (High Risk)</span>
                        </div>
                        <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                          <div className="bg-red-500 h-full rounded-full" style={{ width: '78%' }}></div>
                        </div>
                        <p className="text-[10px] text-gray-400 mt-1">🤖 AI Action: Recommend opening secondary side-exits automatically. Stagger screen exits by 5 minutes to reduce main lobby footprint congestion.</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-orange-950/20 border border-orange-500/20 p-5 rounded-2xl">
                    <h4 className="text-xs font-bold text-orange-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">🔧 Predictive Maintenance Schedule</h4>
                    <div className="space-y-2 text-xs">
                      <div className="flex justify-between items-center py-1 border-b border-white/5">
                        <span className="font-bold text-white">Seat H12 (Recliner Motor)</span>
                        <span className="text-red-400 font-mono">92% Lifecycle Expired</span>
                      </div>
                      <div className="flex justify-between items-center py-1 border-b border-white/5">
                        <span className="font-bold text-white">Seat D5 (Cushion fabric)</span>
                        <span className="text-yellow-400 font-mono">81% Wear Level</span>
                      </div>
                      <div className="flex justify-between items-center py-1">
                        <span className="font-bold text-white">Main Projector Lens (Screen 1)</span>
                        <span className="text-green-400 font-mono">142h runtime remaining</span>
                      </div>
                      <p className="text-[10px] text-gray-400 pt-1 mt-1">🤖 AI Action: Created maintenance work-orders automatically for off-peak periods (next Monday 9 AM).</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Show Scheduling Dashboard */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="glass p-6 rounded-3xl border border-white/10 lg:col-span-2">
                  <h3 className="text-lg font-bold mb-4">🗓️ Active Screen Showtimes</h3>
                  <div className="space-y-3">
                    {showsList.map(show => (
                      <div key={show.id} className="flex justify-between items-center p-4 bg-white/5 border border-white/5 rounded-2xl hover:bg-white/10 transition-colors">
                        <div>
                          <h4 className="font-bold text-white">{show.movie}</h4>
                          <p className="text-xs text-gray-400 mt-0.5">{show.screen} • {show.time} • ₹{show.price}</p>
                          {show.isAiScheduled && <span className="text-[9px] bg-blue-500/20 border border-blue-500/30 text-blue-400 px-1.5 py-0.5 rounded font-bold mt-1 inline-block">✨ Demand-Optimised Scheduling</span>}
                          {show.aiNotes && <p className="text-[10px] text-yellow-400 mt-1">💡 {show.aiNotes}</p>}
                        </div>
                        <button onClick={() => cancelShowItem(show.id)} className="text-red-500 hover:text-red-400 text-xs font-bold">Cancel Show</button>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="glass p-6 rounded-3xl border border-white/10">
                  <h3 className="text-lg font-bold mb-4">Create Timing Slot</h3>
                  <form onSubmit={addNewShow} className="space-y-4">
                    <div>
                      <label className="text-[10px] text-gray-400 font-bold block mb-1">Select Movie</label>
                      <select value={showMovieSelect} onChange={e=>setShowMovieSelect(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-500 text-white cursor-pointer">
                        {KC.MOVIES.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                      </select>
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 font-bold block mb-1">Screen Location</label>
                      <select value={showScreenSelect} onChange={e=>setShowScreenSelect(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-500 text-white cursor-pointer">
                        {screensList.map(s => <option key={s} value={s}>{s}</option>)}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] text-gray-400 font-bold block mb-1">Show Time</label>
                        <input className="input-field" placeholder="8:00 PM" value={showTimeSelect} onChange={e=>setShowTimeSelect(e.target.value)} required />
                      </div>
                      <div>
                        <label className="text-[10px] text-gray-400 font-bold block mb-1">Base Price (₹)</label>
                        <input className="input-field" type="number" value={showPriceInput} onChange={e=>setShowPriceInput(Number(e.target.value))} required />
                      </div>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer py-1">
                      <input type="checkbox" checked={aiSchedulerEnabled} onChange={e=>setAiSchedulerEnabled(e.target.checked)} className="w-4 h-4 accent-red-500" />
                      <span className="text-xs text-gray-300">Revenue-maximizing scheduling</span>
                    </label>
                    <button className="btn-primary w-full py-3 text-xs font-bold mt-2">Publish Showtime</button>
                  </form>
                </div>
              </div>

              {/* Occupancy Heatmap & Late Night Optimization section */}
              <div className="glass p-6 rounded-3xl border border-white/10 mt-6">
                <h3 className="text-lg font-bold mb-4">🔥 AI Heatmap of Theater Occupancy</h3>
                <p className="text-xs text-gray-400 mb-4">Predicted occupancy by screen and showtime slots. Red indicates high occupancy (dynamic pricing recommended).</p>
                
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border-collapse border-spacing-0">
                    <thead>
                      <tr className="border-b border-white/10 text-gray-400">
                        <th className="p-3">Screen</th>
                        {['9:30 AM', '12:00 PM', '2:45 PM', '5:30 PM', '8:00 PM', '10:30 PM'].map(t => (
                          <th key={t} className="p-3 text-center">{t}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5 text-gray-300">
                      {screensList.slice(0, 3).map((scr, idx) => {
                        const baseOccs = [
                          [25, 60, 42, 85, 98, 92],
                          [18, 55, 30, 72, 90, 88],
                          [10, 32, 20, 48, 70, 64]
                        ];
                        const occs = baseOccs[idx] || [15, 30, 45, 60, 75, 80];
                        return (
                          <tr key={scr} className="hover:bg-white/5 transition-colors">
                            <td className="p-3 font-bold text-white">{scr}</td>
                            {occs.map((occ, idx2) => {
                              let badgeColor = 'bg-green-500/20 text-green-400 border-green-500/20';
                              if (occ >= 80) badgeColor = 'bg-red-500/20 text-red-400 border-red-500/20 font-bold';
                              else if (occ >= 50) badgeColor = 'bg-yellow-500/20 text-yellow-400 border-yellow-500/20';
                              
                              return (
                                <td key={idx2} className="p-3 text-center">
                                  <span className={`inline-block px-2 py-1 rounded-lg border ${badgeColor} text-[10px]`}>
                                    {occ}%
                                  </span>
                                </td>
                              );
                            })}
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
                
                {/* Late-Night Show Optimization Tips */}
                <div className="p-4 bg-purple-500/10 border border-purple-500/20 rounded-2xl mt-5">
                  <h4 className="text-xs font-bold text-purple-400 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
                    🌙 Late-Night Show Scheduling Optimization
                  </h4>
                  <p className="text-xs text-gray-300">
                    🤖 AI analysis detects strong pre-booking interest for action blockbusters in late shows. Recommending shifting {screensList[2] || 'Screen Gamma'} 10:30 PM slot from 'Gladiator II' to 'Pushpa 2: The Rule'. Projected occupancy increase: <span className="text-green-400 font-bold">34% → 92% (+₹11,800 revenue impact)</span>.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SMART PRICING & OPERATIONS */}
          {tab === 'pricing' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black">💰 Smart Dynamic Pricing & Billing Center</h2>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Pricing modifiers configuration */}
                <div className="glass p-6 rounded-3xl border border-white/10 lg:col-span-1 space-y-5">
                  <h3 className="font-bold text-sm border-b border-white/5 pb-2">⚙️ Dynamic Pricing Engine Rules</h3>
                  
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold block mb-1">Global Base Ticket Price (₹)</label>
                    <input 
                      type="number" 
                      value={basePrice} 
                      onChange={e=>setBasePrice(Number(e.target.value))} 
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-500 text-white" 
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-gray-400 font-bold block mb-1">Weekend Pricing Factor</label>
                    <input 
                      type="number" 
                      step="0.05" 
                      value={weekendPriceMulti} 
                      onChange={e=>setWeekendPriceMulti(Number(e.target.value))} 
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-500 text-white" 
                    />
                  </div>

                  <div>
                    <label className="text-[10px] text-gray-400 font-bold block mb-1">Holiday / Festival Surge Factor</label>
                    <input 
                      type="number" 
                      step="0.05" 
                      value={holidayPriceMulti} 
                      onChange={e=>setHolidayPriceMulti(Number(e.target.value))} 
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-sm outline-none focus:border-red-500 text-white" 
                    />
                  </div>

                  <div className="space-y-3 pt-2">
                    <label className="flex items-center gap-2.5 cursor-pointer">
                      <input type="checkbox" checked={enableAutoOccupancy} onChange={e=>setEnableAutoOccupancy(e.target.checked)} className="w-4 h-4 accent-red-500" />
                      <div>
                        <span className="text-xs text-gray-300 font-bold">Occupancy Auto-pricing</span>
                        <p className="text-[9px] text-gray-500 leading-tight">Increase if occupancy &gt; 80%, discount if &lt; 30%</p>
                      </div>
                    </label>
                    
                    <label className="flex items-center gap-2.5 cursor-pointer">
                      <input type="checkbox" checked={enableTrendPricing} onChange={e=>setEnableTrendPricing(e.target.checked)} className="w-4 h-4 accent-red-500" />
                      <div>
                        <span className="text-xs text-gray-300 font-bold">AI Trend / Weather Surging</span>
                        <p className="text-[9px] text-gray-500 leading-tight">Optimises rates based on movie social media trends</p>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Active Bookings History & Reissue */}
                <div className="glass p-6 rounded-3xl border border-white/10 lg:col-span-2 space-y-4">
                  <h3 className="font-bold text-sm">🎟️ Sales Audit & Refund Logs</h3>
                  <div className="overflow-x-auto max-h-96">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-black/50 text-gray-400 border-b border-white/10">
                        <tr>
                          <th className="p-3">ID</th>
                          <th className="p-3">Movie</th>
                          <th className="p-3">Seats</th>
                          <th className="p-3">Total</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {activeBookingsList.map(bk => (
                          <tr key={bk.id} className="hover:bg-white/5 transition-colors">
                            <td className="p-3 font-mono text-gray-300">{bk.id}</td>
                            <td className="p-3 font-bold text-white">{bk.movieTitle}</td>
                            <td className="p-3 font-mono">{bk.seats.join(', ')}</td>
                            <td className="p-3 font-bold text-green-400">₹{bk.grandTotal}</td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${bk.status === 'cancelled' ? 'bg-red-500/20 text-red-400 border border-red-500/20' : 'bg-green-500/20 text-green-400 border border-green-500/20'}`}>{bk.status}</span>
                            </td>
                            <td className="p-3 text-right space-x-2">
                              <button onClick={() => alert(`Ticket ${bk.id} reissued. Check user profile for QR code update.`)} className="text-blue-400 hover:text-blue-300 text-[10px] font-bold">Reissue</button>
                              {bk.status === 'confirmed' && (
                                <button onClick={() => deleteBookingItem(bk.id)} className="text-red-500 hover:text-red-400 text-[10px] font-bold">Refund</button>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              {/* Snack Inventory auto restock triggers */}
              <div className="glass p-6 rounded-3xl border border-white/10">
                <h3 className="text-lg font-bold mb-4">🍿 Snack Sales & Inventory Alert</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {snackInventory.map(sn => (
                    <div key={sn.id} className="bg-black/30 border border-white/10 rounded-2xl p-4 flex flex-col justify-between hover:bg-white/5 transition-colors relative">
                      {sn.alert && (
                        <div className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full shadow-[0_0_8px_#ef4444] animate-ping" title="Low Inventory Alert"></div>
                      )}
                      <div>
                        <div className="text-sm font-bold text-white truncate">{sn.name}</div>
                        <span className="text-[10px] text-gray-500 block mt-0.5">Price: ₹{sn.price}</span>
                      </div>
                      <div className="mt-4">
                        <div className="text-xs text-gray-400">Stock: <span className={sn.stock <= sn.threshold ? 'text-red-400 font-bold' : 'text-green-400 font-bold'}>{sn.stock}</span></div>
                        {sn.stock <= sn.threshold ? (
                          <button onClick={() => alert(`Auto-restocking order sent to vendor for ${sn.name}. 50 units scheduled for dispatch.`)} className="w-full bg-red-500/20 border border-red-500/30 text-red-400 text-[10px] font-bold py-1 rounded mt-2 hover:bg-red-500/30 transition-colors">Auto-Restock</button>
                        ) : (
                          <div className="text-[9px] text-gray-500 mt-2 font-mono text-center">Stock Optimal</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: AI COPILOT LAB */}
          {tab === 'copilot' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black">🤖 AI Control Center</h2>

              {/* AI Module Toggles */}
              <div className="glass p-6 rounded-3xl border border-white/10">
                <h3 className="font-bold text-sm mb-1">⚙️ AI System Control — Enable / Disable Modules</h3>
                <p className="text-xs text-gray-400 mb-5">Turn individual AI systems on or off. Changes take effect immediately across the platform.</p>
                <div className="space-y-3">
                  {Object.entries(aiModules).map(([key, mod]) => (
                    <div key={key} className={`flex items-center justify-between p-4 rounded-2xl border transition-all ${mod.enabled ? 'bg-green-500/5 border-green-500/20' : 'bg-white/5 border-white/10 opacity-60'}`}>
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{mod.icon}</span>
                        <div>
                          <div className="font-bold text-sm">{mod.name}</div>
                          <div className="text-[10px] text-gray-400 mt-0.5">{mod.desc}</div>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className={`text-[10px] font-bold ${mod.enabled ? 'text-green-400' : 'text-gray-500'}`}>{mod.enabled ? 'ACTIVE' : 'OFF'}</span>
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" checked={mod.enabled} onChange={() => toggleAiModule(key)} className="sr-only peer" />
                          <div className="w-9 h-5 bg-black/50 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-green-500"></div>
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Copilot Assistant */}
              <div className="glass p-6 rounded-3xl border border-white/10 bg-gradient-to-br from-blue-950/20 to-indigo-950/20">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-600 rounded-xl flex items-center justify-center text-xl shadow-[0_0_15px_rgba(79,70,229,0.4)]">🤖</div>
                  <div>
                    <h3 className="text-xl font-bold text-white">CineAI Executive Copilot</h3>
                    <p className="text-xs text-gray-400">Ask the intelligence system about bookings, demand, or churn risk.</p>
                  </div>
                </div>

                <div className="bg-black/60 border border-white/10 p-5 rounded-2xl min-h-[140px] mb-6 flex flex-col justify-between font-mono text-xs leading-relaxed text-gray-300">
                  {isCopilotTyping ? (
                    <div className="flex items-center gap-2 text-blue-400">
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                      <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '0.4s' }}></div>
                      <span>Analyzing ticketing registers and model metrics...</span>
                    </div>
                  ) : copilotAnswer ? (
                    <div className="whitespace-pre-line text-blue-300">{copilotAnswer}</div>
                  ) : (
                    <div className="text-gray-500 font-normal">System Ready. Click a quick query or type your own command below.</div>
                  )}
                </div>

                <div className="flex flex-wrap gap-2 mb-4">
                  <button onClick={() => askCopilot('revenue')} className="bg-white/5 border border-white/10 hover:bg-white/10 px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white transition-all">📈 Maximum Revenue Movie?</button>
                  <button onClick={() => askCopilot('dropping')} className="bg-white/5 border border-white/10 hover:bg-white/10 px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white transition-all">📉 Why are bookings dropping?</button>
                  <button onClick={() => askCopilot('marketing')} className="bg-white/5 border border-white/10 hover:bg-white/10 px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white transition-all">💡 Suggest marketing strategies</button>
                  <button onClick={() => askCopilot('churn')} className="bg-white/5 border border-white/10 hover:bg-white/10 px-3 py-2 rounded-xl text-xs text-gray-300 hover:text-white transition-all">⚠️ Customers likely to churn?</button>
                </div>
              </div>

              {/* Training and accuracy monitoring */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="glass p-6 rounded-3xl border border-white/10 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-sm mb-1">⚙️ Recommendation Model Training Center</h3>
                    <p className="text-xs text-gray-400 mb-4">Fine-tune the neural networks for movie suggestion classification clusters.</p>
                  </div>
                  <div className="py-4 flex justify-between items-center border-y border-white/5 mb-4">
                    <div>
                      <div className="text-[10px] text-gray-500 uppercase tracking-widest">Model accuracy</div>
                      <div className="text-2xl font-black text-white">{modelAccuracy}%</div>
                    </div>
                    <div>
                      <div className="text-[10px] text-gray-500 uppercase tracking-widest">User clusters</div>
                      <div className="text-2xl font-black text-white">4 Clusters</div>
                    </div>
                  </div>
                  <button 
                    onClick={triggerModelRetrain} 
                    disabled={isTraining}
                    className={`w-full py-3.5 rounded-xl font-bold text-xs transition-all ${isTraining ? 'bg-blue-600/30 text-blue-400 border border-blue-500/20 cursor-wait' : 'bg-blue-600 hover:bg-blue-500 text-white shadow-[0_0_15px_rgba(59,130,246,0.3)]'}`}
                  >
                    {isTraining ? 'Retraining Model...' : '⚡ Retrain Recommendation AI'}
                  </button>
                </div>

                {/* Chatbot control rules database */}
                <div className="glass p-6 rounded-3xl border border-white/10 space-y-4">
                  <h3 className="font-bold text-sm">💬 AI Chatbot Configuration Rules</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto pr-2 divide-y divide-white/5">
                    {chatbotRules.map((rule, idx) => (
                      <div key={idx} className="pt-2 text-xs">
                        <span className="text-[10px] text-red-400 font-bold font-mono">IF keyword: "{rule.phrase}"</span>
                        <p className="text-gray-400 mt-0.5">"{rule.reply}"</p>
                      </div>
                    ))}
                  </div>

                  <form onSubmit={addChatbotRule} className="grid grid-cols-2 gap-2 border-t border-white/5 pt-4">
                    <input className="w-full bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-red-500" placeholder="Keyword: e.g. refund" value={newRulePhrase} onChange={e=>setNewRulePhrase(e.target.value)} required />
                    <input className="w-full bg-black/40 border border-white/10 rounded-lg px-2.5 py-1.5 text-xs text-white outline-none focus:border-red-500" placeholder="Chatbot reply..." value={newRuleReply} onChange={e=>setNewRuleReply(e.target.value)} required />
                    <button className="col-span-2 bg-white/5 hover:bg-white/10 border border-white/10 font-bold text-xs py-2 rounded-lg text-gray-300">Add Keyword Trigger</button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: SECURITY & EOC */}
          {tab === 'security' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black">🚨 Security, EOC & Access Controls</h2>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Fake ticket scanner verification */}
                <div className="glass p-6 rounded-3xl border border-white/10 space-y-4">
                  <div>
                    <h3 className="font-bold text-sm">🕵️ Deepfake & Fake Ticket Detector</h3>
                    <p className="text-[10px] text-gray-400 mt-0.5">Simulate ticket scanning entry validation to detect screenshot replication or altered QR signatures.</p>
                  </div>

                  <div className="space-y-3">
                    <input 
                      type="text" 
                      value={scannerInput} 
                      onChange={e=>setScannerInput(e.target.value)} 
                      placeholder="Enter Booking ID (e.g. BK123456) or 'fake'"
                      className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2.5 text-xs text-white outline-none focus:border-red-500 font-mono" 
                    />
                    <button onClick={handleTestQR} className="w-full bg-white/5 border border-white/10 hover:bg-white/10 py-2.5 rounded-xl text-xs font-bold text-white transition-colors">Verify QR Signature</button>
                  </div>

                  {scannerResult && (
                    <div className={`p-4 rounded-xl border text-xs font-mono leading-normal ${scannerResult.color}`}>
                      {scannerResult.message}
                    </div>
                  )}
                </div>

                {/* Facial Recognition check entry logs */}
                <div className="glass p-6 rounded-3xl border border-white/10 lg:col-span-2 space-y-3">
                  <h3 className="font-bold text-sm">👁️ Facial Ticket verification Checkpoint logs</h3>
                  <div className="overflow-x-auto max-h-60">
                    <table className="w-full text-xs text-left">
                      <thead className="bg-black/50 text-gray-400 border-b border-white/10">
                        <tr>
                          <th className="p-3">Checkpoint Time</th>
                          <th className="p-3">Matching user</th>
                          <th className="p-3">Score</th>
                          <th className="p-3">Entry status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5 font-mono text-gray-300">
                        <tr className="hover:bg-white/5">
                          <td className="p-3">01:34:50</td>
                          <td className="p-3">Aarav Sharma</td>
                          <td className="p-3 text-green-400">98.4% Match</td>
                          <td className="p-3 text-green-400">Verified & Checked-in</td>
                        </tr>
                        <tr className="hover:bg-white/5">
                          <td className="p-3">01:35:12</td>
                          <td className="p-3">Neha Kapoor</td>
                          <td className="p-3 text-green-400">94.2% Match</td>
                          <td className="p-3 text-green-400">Verified & Checked-in</td>
                        </tr>
                        <tr className="hover:bg-white/5">
                          <td className="p-3">01:38:05</td>
                          <td className="p-3">Unknown Face Scan</td>
                          <td className="p-3 text-red-400">12.1% Match</td>
                          <td className="p-3 text-red-500 font-bold animate-pulse">Alert Raised: Match Fail</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Emergency Operations Override (EOC) */}
                <div className="glass p-6 rounded-3xl border border-white/10 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-sm mb-1">🚨 Emergency Center System overrides (EOC)</h3>
                    <p className="text-[10px] text-gray-400 mb-4">Toggle override fail safes during emergency payment gateway outages or server crashes.</p>
                  </div>
                  <div className="space-y-3">
                    <label className="flex items-center justify-between p-3 bg-black/40 border border-white/5 rounded-xl cursor-pointer hover:bg-white/5">
                      <div>
                        <span className="text-xs text-white font-bold">Fallback Payment Gateway</span>
                        <p className="text-[9px] text-gray-500">Route transactions to secondary backup server during UPI outage</p>
                      </div>
                      <input type="checkbox" checked={eocPaymentGatewayBypass} onChange={e=>setEocPaymentGatewayBypass(e.target.checked)} className="w-5 h-5 accent-red-500" />
                    </label>

                    <label className="flex items-center justify-between p-3 bg-black/40 border border-white/5 rounded-xl cursor-pointer hover:bg-white/5">
                      <div>
                        <span className="text-xs text-white font-bold">Evacuation Alerts System</span>
                        <p className="text-[9px] text-gray-500">Dispatch alerts to all screens regarding overcrowding alarms</p>
                      </div>
                      <input type="checkbox" checked={eocOvercrowdingWarning} onChange={e=>setEocOvercrowdingWarning(e.target.checked)} className="w-5 h-5 accent-red-500" />
                    </label>

                    <label className="flex items-center justify-between p-3 bg-black/40 border border-white/5 rounded-xl cursor-pointer hover:bg-white/5">
                      <div>
                        <span className="text-xs text-white font-bold">Load Balancer Cache Bypass</span>
                        <p className="text-[9px] text-gray-500">Serve tickets from local edge node server to prevent API delays</p>
                      </div>
                      <input type="checkbox" checked={eocServerBypass} onChange={e=>setEocServerBypass(e.target.checked)} className="w-5 h-5 accent-red-500" />
                    </label>
                  </div>
                </div>

                {/* Audit & Role-Based Permissions Grid */}
                <div className="glass p-6 rounded-3xl border border-white/10 space-y-4">
                  <h3 className="font-bold text-sm">🛡️ Role-Based Access Control Permissions (RBAC)</h3>
                  <div className="p-4 bg-black/40 border border-white/5 rounded-2xl">
                    <div className="text-xs text-gray-400 font-bold mb-3">Permissions Matrix for: <span className="text-red-400">{adminRole}</span></div>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="flex items-center gap-2 text-xs text-gray-300">
                        <input type="checkbox" checked={!!currentPerms.read} disabled className="w-4 h-4 accent-red-500" />
                        <span>View registers</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs text-gray-300">
                        <input type="checkbox" checked={!!currentPerms.write} disabled className="w-4 h-4 accent-red-500" />
                        <span>Edit schedules</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs text-gray-300">
                        <input type="checkbox" checked={!!currentPerms.price} disabled className="w-4 h-4 accent-red-500" />
                        <span>Change pricing</span>
                      </label>
                      <label className="flex items-center gap-2 text-xs text-gray-300">
                        <input type="checkbox" checked={!!currentPerms.security} disabled className="w-4 h-4 accent-red-500" />
                        <span>Security Overrides</span>
                      </label>
                      <label className="col-span-2 flex items-center gap-2 text-xs text-gray-300 border-t border-white/5 pt-2 mt-1">
                        <input type="checkbox" checked={!!currentPerms.delete} disabled className="w-4 h-4 accent-red-500" />
                        <span>Cancel database transactions</span>
                      </label>
                    </div>
                  </div>
                  <p className="text-[10px] text-gray-500">Note: Permissions are determined automatically based on the role swapper configuration in the sidebar navigation.</p>
                </div>
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════ */}
          {/* TAB: COMPLAINTS CENTER */}
          {/* ═══════════════════════════════════════════════ */}
          {tab === 'complaints' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                <div>
                  <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">📩 Complaints Resolution Center</h2>
                  <p className="text-xs text-gray-400 mt-1">AI-triaged customer issues. Respond, resolve, and process refunds in one place.</p>
                </div>
                <div className="flex gap-2 flex-wrap">
                  {['All','Open','In Progress','Resolved'].map(s => (
                    <button key={s} onClick={() => setComplaintFilterStatus(s)} className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all border ${ complaintFilterStatus === s ? 'bg-purple-600 border-purple-500 text-white' : 'border-white/10 text-gray-400 hover:text-white hover:bg-white/5' }`}>{s}</button>
                  ))}
                  <button onClick={() => {
                    setComplaints(complaints.filter(c => c.status !== 'Resolved'));
                    setSelectedComplaint(null);
                    alert('All resolved complaints have been cleared from the queue.');
                  }} className="px-3 py-1.5 rounded-lg text-xs font-bold border border-green-500/30 text-green-400 hover:bg-green-500/10 transition-all">♻️ Clear Resolved</button>
                </div>
              </div>

              {/* Stats Row */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label:'Total Complaints', val: complaints.length, color:'text-white', bg:'bg-white/5' },
                  { label:'Open / Critical', val: complaints.filter(c=>c.status==='Open').length, color:'text-red-400', bg:'bg-red-500/10' },
                  { label:'In Progress', val: complaints.filter(c=>c.status==='In Progress').length, color:'text-yellow-400', bg:'bg-yellow-500/10' },
                  { label:'Resolved Today', val: complaints.filter(c=>c.status==='Resolved').length, color:'text-green-400', bg:'bg-green-500/10' },
                ].map((s,i) => (
                  <div key={i} className={`${s.bg} border border-white/10 p-4 rounded-2xl`}>
                    <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">{s.label}</p>
                    <p className={`text-3xl font-black mt-1 ${s.color}`}>{s.val}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Complaint List */}
                <div className="space-y-3">
                  <h3 className="text-sm font-bold text-gray-300">Active Tickets</h3>
                  {complaints.filter(c => complaintFilterStatus === 'All' || c.status === complaintFilterStatus).map(c => (
                    <div key={c.id} onClick={() => { setSelectedComplaint(c); setComplaintReply(''); }} className={`p-4 rounded-2xl border cursor-pointer transition-all hover:border-purple-500/50 ${ selectedComplaint?.id === c.id ? 'border-purple-500 bg-purple-500/10' : 'border-white/10 bg-white/5 hover:bg-white/8' }`}>
                      <div className="flex justify-between items-start gap-2">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <span className="font-bold text-sm text-white">{c.user}</span>
                            <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold border ${ c.priority === 'High' ? 'bg-red-500/20 text-red-400 border-red-500/30' : c.priority === 'Medium' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' : 'bg-gray-500/20 text-gray-400 border-gray-500/30' }`}>{c.priority}</span>
                            <span className={`text-[9px] px-1.5 py-0.5 rounded font-bold border ${ c.status === 'Open' ? 'bg-red-500/20 text-red-400 border-red-500/30' : c.status === 'In Progress' ? 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' : 'bg-green-500/20 text-green-400 border-green-500/30' }`}>{c.status}</span>
                          </div>
                          <p className="text-xs text-gray-300 line-clamp-2">{c.msg}</p>
                          <div className="flex items-center gap-3 mt-2">
                            <span className="text-[10px] text-gray-500">🏷️ {c.type}</span>
                            <span className="text-[10px] text-gray-500">🕐 {c.time}</span>
                            {c.bookingId && <span className="text-[10px] text-blue-400">📎 {c.bookingId}</span>}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                  {complaints.filter(c => complaintFilterStatus === 'All' || c.status === complaintFilterStatus).length === 0 && (
                    <div className="text-center py-12 text-gray-600">
                      <div className="text-4xl mb-2">✅</div>
                      <p className="font-bold text-sm">All clear! No complaints in this filter.</p>
                    </div>
                  )}
                </div>

                {/* Resolution Panel */}
                <div className="space-y-4">
                  <div className="glass border border-white/10 rounded-2xl p-5 space-y-4">
                    {selectedComplaint ? (
                      <>
                        <div>
                          <h3 className="font-bold text-sm text-purple-300">📋 Complaint #{selectedComplaint.id}</h3>
                          <p className="text-xs text-gray-300 mt-2 bg-white/5 p-3 rounded-xl border border-white/5">{selectedComplaint.msg}</p>
                          <div className="grid grid-cols-2 gap-3 mt-3">
                            <div className="p-2 bg-white/5 rounded-lg border border-white/5">
                              <p className="text-[9px] text-gray-500 uppercase">Customer</p>
                              <p className="text-xs font-bold text-white">{selectedComplaint.user}</p>
                              <p className="text-[10px] text-gray-400">{selectedComplaint.email}</p>
                            </div>
                            <div className="p-2 bg-white/5 rounded-lg border border-white/5">
                              <p className="text-[9px] text-gray-500 uppercase">Category</p>
                              <p className="text-xs font-bold text-white">{selectedComplaint.type}</p>
                              <p className="text-[10px] text-gray-400">Priority: {selectedComplaint.priority}</p>
                            </div>
                          </div>
                        </div>
                        {/* AI Suggested Reply */}
                        <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl">
                          <p className="text-[10px] text-purple-400 font-bold mb-2">🤖 AI Suggested Response:</p>
                          <p className="text-xs text-gray-300">
                            {selectedComplaint.type === 'Refund' ? `Dear ${selectedComplaint.user}, we sincerely apologize for the delay. Your refund for booking ${selectedComplaint.bookingId} has been processed and will reflect in 3-5 business days.` :
                             selectedComplaint.type === 'Seat' ? `Dear ${selectedComplaint.user}, we deeply regret the seat allocation issue. We are initiating a full investigation and will provide complimentary tickets as compensation.` :
                             selectedComplaint.type === 'Technical' ? `Dear ${selectedComplaint.user}, thank you for reporting this issue. Our tech team has been alerted and we will credit your account with ₹50 as an apology.` :
                             selectedComplaint.type === 'Payment' ? `Dear ${selectedComplaint.user}, we confirm receipt of your double payment complaint. The extra charge will be reversed within 24 hours.` :
                             `Dear ${selectedComplaint.user}, we apologize for the inconvenience. Our team is reviewing your complaint and will resolve it within 24 hours.`}
                          </p>
                          <button onClick={() => setComplaintReply(selectedComplaint.type === 'Refund' ? `Dear ${selectedComplaint.user}, we sincerely apologize for the delay. Your refund for booking ${selectedComplaint.bookingId} has been processed and will reflect in 3-5 business days.` : `Dear ${selectedComplaint.user}, we apologize for the inconvenience. Our team is reviewing your complaint and will resolve it within 24 hours.`)} className="mt-2 text-[10px] text-purple-400 hover:text-purple-300 underline">Use this reply →</button>
                        </div>
                        <textarea
                          value={complaintReply}
                          onChange={e => setComplaintReply(e.target.value)}
                          placeholder="Type custom reply or use AI suggestion above..."
                          className="input-field h-20 resize-none text-sm"
                        />
                        <div className="flex gap-2 flex-wrap">
                          <button onClick={() => {
                            if (!complaintReply.trim()) return alert('Please type a reply.');
                            setComplaints(complaints.map(c => c.id === selectedComplaint.id ? {...c, status:'In Progress'} : c));
                            setSelectedComplaint({...selectedComplaint, status:'In Progress'});
                            addComplaintHistory(selectedComplaint, complaintReply, 'Reply Sent');
                            setComplaintReply('');
                            alert(`✅ Reply sent to ${selectedComplaint.user}!`);
                          }} className="flex-1 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold px-3 py-2.5 rounded-xl transition-colors">📤 Send Reply</button>
                          <button onClick={() => {
                            setComplaints(complaints.map(c => c.id === selectedComplaint.id ? {...c, status:'Resolved'} : c));
                            setSelectedComplaint({...selectedComplaint, status:'Resolved'});
                            addComplaintHistory(selectedComplaint, complaintReply || 'Marked resolved by admin', 'Resolved');
                            alert('✅ Complaint marked as Resolved!');
                          }} className="flex-1 bg-green-600 hover:bg-green-500 text-white text-xs font-bold px-3 py-2.5 rounded-xl transition-colors">✅ Resolve</button>
                          <button onClick={() => {
                            addComplaintHistory(selectedComplaint, 'Refund issued by admin', 'Refund Issued');
                            setComplaints(complaints.map(c => c.id === selectedComplaint.id ? {...c, status:'Resolved'} : c));
                            setSelectedComplaint({...selectedComplaint, status:'Resolved'});
                            alert(`💰 Refund initiated for ${selectedComplaint.user}! Amount will be credited within 3-5 business days.`);
                          }} className="bg-blue-600 hover:bg-blue-500 text-white text-xs font-bold px-3 py-2.5 rounded-xl transition-colors">💰 Refund</button>
                          <button onClick={() => {
                            setComplaints(complaints.map(c => c.id === selectedComplaint.id ? {...c, status:'Open', priority:'High'} : c));
                            setSelectedComplaint({...selectedComplaint, status:'Open', priority:'High'});
                            addComplaintHistory(selectedComplaint, '', 'Escalated to High Priority');
                            alert('🔺 Complaint escalated!');
                          }} className="bg-red-600 hover:bg-red-500 text-white text-xs font-bold px-3 py-2.5 rounded-xl transition-colors">🔺 Escalate</button>
                        </div>
                      </>
                    ) : (
                      <div className="flex flex-col items-center justify-center h-48 text-gray-500">
                        <span className="text-5xl mb-4">📩</span>
                        <p className="text-sm font-bold">Select a complaint to respond</p>
                        <p className="text-xs mt-1 text-gray-600">AI auto-suggests the best response</p>
                      </div>
                    )}
                  </div>

                  {/* Reply History Log */}
                  {complaintHistory.length > 0 && (
                    <div className="glass border border-white/10 rounded-2xl p-4">
                      <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">📜 Action History</h4>
                      <div className="space-y-2">
                        {complaintHistory.map(h => (
                          <div key={h.id} className="flex justify-between items-start text-xs py-2 border-b border-white/5">
                            <div>
                              <span className={`font-bold ${h.action === 'Resolved' ? 'text-green-400' : h.action === 'Refund Issued' ? 'text-blue-400' : h.action === 'Escalated to High Priority' ? 'text-red-400' : 'text-purple-400'}`}>{h.action}</span>
                              <span className="text-gray-500 ml-2">→ {h.user}</span>
                            </div>
                            <span className="text-gray-600 font-mono text-[10px]">{h.time}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════ */}
          {/* TAB: AI COPILOT PRO + DEEPFAKE + EMOTION RECS */}
          {/* ═══════════════════════════════════════════════ */}
          {tab === 'aiintel' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">🧠 AI Intelligence Suite</h2>

              {/* Deepfake Ticket Detection */}
              <div className="glass border border-purple-500/20 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm flex items-center gap-2">🔍 Deepfake Ticket Detection Engine <span className="text-[9px] bg-purple-500/20 text-purple-400 border border-purple-500/30 px-2 py-0.5 rounded font-bold">AI ACTIVE</span></h3>
                  <p className="text-xs text-gray-400 mt-1">Scans QR codes for pixel entropy anomalies, hash mismatches, and screenshot cloning signatures.</p>
                </div>
                <div className="flex gap-3">
                  <input value={deepfakeInput} onChange={e=>setDeepfakeInput(e.target.value)} placeholder="Enter Ticket / Booking ID to scan..." className="input-field flex-1 text-sm" />
                  <button onClick={() => {
                    if (!deepfakeInput.trim()) return;
                    const isReal = KC.BOOKINGS.find(b => b.id === deepfakeInput.trim() && b.status !== 'cancelled');
                    const isFake = deepfakeInput.toLowerCase().includes('fake') || deepfakeInput.toLowerCase().includes('screenshot') || deepfakeInput.toLowerCase().includes('copy');
                    const result = isFake ? { verdict:'DEEPFAKE DETECTED', color:'text-red-400 bg-red-500/10 border-red-500/20', confidence:97.3+Math.random()*2, icon:'🚨' } :
                                   isReal ? { verdict:'GENUINE — VERIFIED', color:'text-green-400 bg-green-500/10 border-green-500/20', confidence:98.5+Math.random()*1.5, icon:'✅' } :
                                   { verdict:'SUSPICIOUS — MANUAL CHECK', color:'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', confidence:61.2+Math.random()*20, icon:'⚠️' };
                    setDeepfakeResult(result);
                    setDeepfakeLog([{ id:'DT'+Date.now(), ticketId:deepfakeInput, time:new Date().toLocaleTimeString(), verdict:isFake?'DEEPFAKE':isReal?'GENUINE':'SUSPICIOUS', confidence:result.confidence.toFixed(1), method:'Neural Hash + Pixel Entropy' }, ...deepfakeLog.slice(0,4)]);
                    setDeepfakeInput('');
                  }} className="bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition-colors whitespace-nowrap">🔍 Scan Ticket</button>
                </div>
                {deepfakeResult && (
                  <div className={`p-4 rounded-xl border font-bold text-sm ${deepfakeResult.color}`}>
                    {deepfakeResult.icon} {deepfakeResult.verdict} — AI Confidence: {deepfakeResult.confidence.toFixed(1)}%
                  </div>
                )}
                <div className="space-y-2">
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider">Recent Scan Log</p>
                  {deepfakeLog.map(l => (
                    <div key={l.id} className="flex justify-between items-center py-2 border-b border-white/5 text-xs">
                      <span className="text-gray-400">{l.time}</span>
                      <span className="text-gray-300 font-mono">{l.ticketId}</span>
                      <span className={l.verdict === 'GENUINE' ? 'text-green-400' : l.verdict === 'DEEPFAKE' ? 'text-red-400 font-bold' : 'text-yellow-400'}>{l.verdict}</span>
                      <span className="text-gray-500">{l.confidence}%</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Emotion-Based Movie Recommendation */}
              <div className="glass border border-pink-500/20 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm flex items-center gap-2">🎭 Emotion-Based Movie Recommendation Engine</h3>
                  <p className="text-xs text-gray-400 mt-1">Select an audience mood and AI will surface the best matching movies to recommend or promote.</p>
                </div>
                <div className="grid grid-cols-4 gap-2">
                  {Object.keys(emotionMap).map(em => (
                    <button key={em} onClick={() => getEmotionRecs(em)} className={`p-3 rounded-xl text-center text-xs font-bold border transition-all ${ emotionSelected === em ? 'bg-pink-500/20 border-pink-500/50 text-pink-300' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-white/10' }`}>{em}</button>
                  ))}
                </div>
                {emotionLoading && <div className="text-center text-purple-400 text-sm py-4 animate-pulse">🤖 AI analyzing mood-movie compatibility...</div>}
                {emotionRecs.length > 0 && (
                  <div>
                    <p className="text-xs text-gray-400 mb-3">Top picks for <span className="text-pink-400 font-bold">{emotionSelected}</span> audience:</p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {emotionRecs.map(m => (
                        <div key={m.id} className="bg-white/5 border border-white/10 rounded-xl overflow-hidden hover:border-pink-500/30 transition-colors">
                          <img src={m.poster} className="w-full h-28 object-cover" alt={m.title} onError={e=>{e.target.src='https://images.unsplash.com/photo-1574126154517-d1e0d89ef734?w=200&h=200&fit=crop';}} />
                          <div className="p-2">
                            <p className="text-xs font-bold text-white line-clamp-1">{m.title}</p>
                            <p className="text-[9px] text-gray-400 mt-0.5">{m.genre?.join(', ')}</p>
                            <p className="text-[9px] text-yellow-400 mt-0.5">⭐ {m.rating}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-3 p-3 bg-pink-500/10 border border-pink-500/20 rounded-xl text-xs text-pink-300">
                      🤖 AI recommends promoting these titles to {emotionSelected} users via push notifications with 20% mood-match discount.
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════ */}
          {/* TAB: SMART ANALYTICS (CROWD + DEMAND + SENTIMENT + THEATER OPT) */}
          {/* ═══════════════════════════════════════════════ */}
          {tab === 'smartanalytics' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">📡 Smart Analytics Command Center</h2>

              {/* Crowd Prediction */}
              <div className="glass border border-cyan-500/20 rounded-2xl p-5 space-y-4">
                <div className="flex justify-between items-center flex-wrap gap-3">
                  <div>
                    <h3 className="font-bold text-sm flex items-center gap-2">👥 Crowd Prediction Analytics <span className="text-[9px] bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded font-bold">LIVE MODEL</span></h3>
                    <p className="text-xs text-gray-400 mt-0.5">AI-predicted crowd density by hour based on historical patterns and real-time pre-bookings.</p>
                  </div>
                  <select value={crowdDate} onChange={e=>setCrowdDate(e.target.value)} className="bg-black/40 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white outline-none">
                    {Object.keys(crowdData).map(d => <option key={d}>{d}</option>)}
                  </select>
                </div>
                <div className="h-40 flex items-end justify-between gap-1 border-b border-white/10 pb-1">
                  {['10AM','12PM','2PM','4PM','6PM','8PM','10PM','12AM'].map((hr,i) => {
                    const pct = (crowdData[crowdDate] || [])[i] || 0;
                    return (
                      <div key={hr} className="flex-1 flex flex-col items-center gap-1 group">
                        <span className="text-[9px] text-cyan-400 font-bold opacity-0 group-hover:opacity-100 transition-opacity">{pct}%</span>
                        <div className={`w-full rounded-t-md transition-all ${ pct >= 80 ? 'bg-gradient-to-t from-red-600 to-red-400' : pct >= 50 ? 'bg-gradient-to-t from-yellow-600 to-yellow-400' : 'bg-gradient-to-t from-cyan-700 to-cyan-500' }`} style={{height:`${pct*1.3}px`}}></div>
                        <span className="text-[9px] text-gray-500">{hr}</span>
                      </div>
                    );
                  })}
                </div>
                <div className="flex gap-4 text-[10px] justify-center">
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-red-500 inline-block"></span> Peak (80%+)</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-yellow-500 inline-block"></span> High (50-79%)</span>
                  <span className="flex items-center gap-1"><span className="w-3 h-3 rounded bg-cyan-600 inline-block"></span> Normal (&lt;50%)</span>
                </div>
              </div>

              {/* AI Demand Forecasting */}
              <div className="glass border border-blue-500/20 rounded-2xl p-5 space-y-4">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="font-bold text-sm">🔮 AI Demand Forecasting Engine</h3>
                    <p className="text-xs text-gray-400 mt-0.5">Predicts next 7 days box office performance using ML regression on booking trends.</p>
                  </div>
                  <button onClick={runForecast} disabled={forecastRunning} className="bg-blue-600 hover:bg-blue-500 disabled:opacity-50 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition-colors">
                    {forecastRunning ? '⚙️ Running...' : '▶ Run Forecast'}
                  </button>
                </div>
                {forecastRunning && <div className="text-center text-blue-400 text-sm py-4 animate-pulse">🤖 Training temporal prediction model on 90-day dataset...</div>}
                {forecastResult && (
                  <div className="space-y-3">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                      {[
                        { label:'Top Movie', val:forecastResult.topMovie, color:'text-yellow-400' },
                        { label:'Peak Slot', val:forecastResult.peakDay, color:'text-red-400' },
                        { label:'Projected Revenue', val:forecastResult.expectedRevenue, color:'text-green-400' },
                        { label:'Peak Occupancy', val:forecastResult.occupancy, color:'text-cyan-400' },
                      ].map((f,i) => (
                        <div key={i} className="bg-white/5 border border-white/10 p-3 rounded-xl">
                          <p className="text-[9px] text-gray-500 uppercase font-bold tracking-wider">{f.label}</p>
                          <p className={`text-sm font-black mt-1 ${f.color}`}>{f.val}</p>
                        </div>
                      ))}
                    </div>
                    <div className="p-3 bg-blue-500/10 border border-blue-500/20 rounded-xl">
                      <p className="text-[10px] text-blue-400 font-bold mb-1">⚠️ AI Low Performer Alert:</p>
                      <p className="text-xs text-gray-300">{forecastResult.lowPerformer}</p>
                    </div>
                    <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-xl">
                      <p className="text-[10px] text-green-400 font-bold mb-1">⚡ Surge Slots Detected:</p>
                      <div className="flex flex-wrap gap-2">{forecastResult.surgeSlots.map(s => <span key={s} className="text-[10px] bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded font-bold">{s}</span>)}</div>
                    </div>
                    <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-xl">
                      <p className="text-[10px] text-purple-400 font-bold mb-1">🤖 AI Strategic Recommendation:</p>
                      <p className="text-xs text-gray-300">{forecastResult.aiTip}</p>
                    </div>
                  </div>
                )}
              </div>

              {/* Sentiment Analysis */}
              <div className="glass border border-pink-500/20 rounded-2xl p-5 space-y-4">
                <h3 className="font-bold text-sm">💬 Deep Sentiment Analysis Dashboard</h3>
                <div className="flex gap-3">
                  <select value={sentimentMovie} onChange={e=>setSentimentMovie(e.target.value)} className="flex-1 bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-white outline-none">
                    {KC.MOVIES.map(m => <option key={m.id} value={m.title}>{m.title}</option>)}
                  </select>
                  <button onClick={runSentiment} disabled={sentimentRunning} className="bg-pink-600 hover:bg-pink-500 disabled:opacity-50 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition-colors whitespace-nowrap">
                    {sentimentRunning ? '⚙️ Scanning...' : '📊 Analyze'}
                  </button>
                </div>
                {sentimentRunning && <div className="text-center text-pink-400 text-sm py-4 animate-pulse">🤖 Scanning Twitter, IMDb, Reddit, Google Reviews...</div>}
                {sentimentData && (
                  <div className="space-y-4">
                    <div className="flex items-center gap-4">
                      <div className="flex-1 space-y-3">
                        {[
                          { label:'Positive', pct:sentimentData.positive, color:'bg-green-500', textColor:'text-green-400' },
                          { label:'Neutral', pct:sentimentData.neutral, color:'bg-yellow-500', textColor:'text-yellow-400' },
                          { label:'Negative', pct:sentimentData.negative, color:'bg-red-500', textColor:'text-red-400' },
                        ].map(s => (
                          <div key={s.label}>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-gray-400">{s.label}</span>
                              <span className={`font-bold ${s.textColor}`}>{s.pct}%</span>
                            </div>
                            <div className="w-full bg-white/5 h-2 rounded-full overflow-hidden">
                              <div className={`${s.color} h-full rounded-full transition-all`} style={{width:`${s.pct}%`}}></div>
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="text-center p-4 bg-white/5 border border-white/10 rounded-2xl min-w-[90px]">
                        <p className="text-[9px] text-gray-400 uppercase">Overall</p>
                        <p className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-b from-yellow-400 to-orange-500">{sentimentData.overall}</p>
                        <p className="text-[10px] text-gray-500 mt-1">IMDb: {sentimentData.imdbScore}</p>
                        <p className="text-[10px] text-gray-500">X: {sentimentData.twitterScore}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-xl">
                        <p className="text-[10px] text-green-400 font-bold mb-2">👍 Top Positive Keywords</p>
                        <div className="flex flex-wrap gap-1">{sentimentData.topPositive.map(k=><span key={k} className="text-[9px] bg-green-500/20 text-green-300 px-1.5 py-0.5 rounded">{k}</span>)}</div>
                      </div>
                      <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl">
                        <p className="text-[10px] text-red-400 font-bold mb-2">👎 Top Negative Keywords</p>
                        <div className="flex flex-wrap gap-1">{sentimentData.topNegative.map(k=><span key={k} className="text-[9px] bg-red-500/20 text-red-300 px-1.5 py-0.5 rounded">{k}</span>)}</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Smart Theater Optimization */}
              <div className="glass border border-green-500/20 rounded-2xl p-5 space-y-4">
                <h3 className="font-bold text-sm">🏛️ Smart Theater Optimization Engine</h3>
                <div className="flex gap-3">
                  <select value={theaterOptScreen} onChange={e=>setTheaterOptScreen(e.target.value)} className="flex-1 bg-black/40 border border-white/10 rounded-lg px-3 py-2 text-xs text-white outline-none cursor-pointer">
                    {screensList.map(s => <option key={s} value={s}>{s}</option>)}
                  </select>
                  <button onClick={runTheaterOpt} disabled={theaterOptRunning} className="bg-green-600 hover:bg-green-500 disabled:opacity-50 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition-colors whitespace-nowrap">
                    {theaterOptRunning ? '⚙️ Optimizing...' : '🏛️ Optimize'}
                  </button>
                </div>
                {theaterOptRunning && <div className="text-center text-green-400 text-sm py-4 animate-pulse">🤖 Running multi-variable theater optimization model...</div>}
                {theaterOptResult && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <p className="text-sm font-bold text-white">Optimization Report: <span className="text-green-400">{theaterOptResult.screen}</span></p>
                      <div className="text-center">
                        <p className="text-[9px] text-gray-400 uppercase">AI Score</p>
                        <p className="text-2xl font-black text-green-400">{theaterOptResult.aiScore}<span className="text-xs">/100</span></p>
                      </div>
                    </div>
                    <div className="space-y-2">
                      {theaterOptResult.recommendations.map((r,i) => (
                        <div key={i} className="flex items-start gap-3 p-3 bg-white/5 border border-white/5 rounded-xl hover:border-green-500/20 transition-colors">
                          <span className="text-green-400 mt-0.5 shrink-0">▸</span>
                          <div className="flex-1">
                            <p className="text-[10px] text-green-400 font-bold uppercase tracking-wider">{r.area}</p>
                            <p className="text-xs text-gray-300 mt-0.5">{r.action}</p>
                          </div>
                          <span className="text-[9px] bg-green-500/20 text-green-400 border border-green-500/30 px-2 py-0.5 rounded font-bold whitespace-nowrap shrink-0">{r.impact}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* ═══════════════════════════════════════════════ */}
          {/* TAB: MARKETING CAMPAIGN GENERATOR + FRAUD DETECTION */}
          {/* ═══════════════════════════════════════════════ */}
          {tab === 'marketing' && (
            <div className="space-y-6 animate-fade-in">
              <h2 className="text-2xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-yellow-500">📣 Marketing & Fraud Intelligence</h2>

              {/* Auto Marketing Campaign Generator */}
              <div className="glass border border-orange-500/20 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm flex items-center gap-2">🚀 Auto Marketing Campaign Generator <span className="text-[9px] bg-orange-500/20 text-orange-400 border border-orange-500/30 px-2 py-0.5 rounded font-bold">AI POWERED</span></h3>
                  <p className="text-xs text-gray-400 mt-1">Configure your campaign parameters and let AI generate a full ready-to-send marketing campaign.</p>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Target Audience</label>
                    <select value={campTarget} onChange={e=>setCampTarget(e.target.value)} className="input-field text-sm">
                      <option>All Users</option>
                      <option>Premium Members</option>
                      <option>Lapsed Users (45+ days)</option>
                      <option>Weekend Bookers</option>
                      <option>Family Segment</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Featured Movie</label>
                    <select value={campMovie} onChange={e=>setCampMovie(e.target.value)} className="input-field text-sm">
                      {KC.MOVIES.map(m=><option key={m.id} value={m.title}>{m.title}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Campaign Channel</label>
                    <select value={campType} onChange={e=>setCampType(e.target.value)} className="input-field text-sm">
                      <option>Email + Push</option>
                      <option>SMS Only</option>
                      <option>Push Notification</option>
                      <option>Email Only</option>
                      <option>Full Omnichannel</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] text-gray-400 font-bold uppercase tracking-wider block mb-1">Offer / Promo Code</label>
                    <select value={campOffer} onChange={e=>setCampOffer(e.target.value)} className="input-field text-sm">
                      <option>SAVE20</option>
                      <option>FLAT150</option>
                      <option>WEEKENDFUN</option>
                      <option>WELCOMEBACK15</option>
                      <option>FAMILY30</option>
                      <option>EARLYBIRD20</option>
                    </select>
                  </div>
                </div>
                <button onClick={generateCampaign} disabled={campGenerating} className="w-full bg-gradient-to-r from-orange-600 to-yellow-500 hover:from-orange-500 hover:to-yellow-400 disabled:opacity-50 text-white font-bold py-3 rounded-xl transition-all shadow-[0_0_20px_rgba(234,88,12,0.3)]">
                  {campGenerating ? '⚙️ AI is crafting your campaign...' : '✨ Generate Campaign with AI'}
                </button>
                {campGenerating && <div className="text-center text-orange-400 text-sm animate-pulse">🤖 Analyzing user behavior, writing copy, and optimizing send time...</div>}
                {generatedCampaign && (
                  <div className="space-y-3 border-t border-white/10 pt-4">
                    <p className="text-xs font-bold text-orange-400 uppercase tracking-wider">✅ Campaign Ready to Deploy</p>
                    <div className="p-4 bg-white/5 border border-orange-500/20 rounded-xl space-y-2">
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] text-gray-500 uppercase font-bold w-20 shrink-0 mt-0.5">Subject:</span>
                        <p className="text-sm font-bold text-white">{generatedCampaign.subject}</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] text-gray-500 uppercase font-bold w-20 shrink-0 mt-0.5">Headline:</span>
                        <p className="text-sm text-orange-300 font-bold">{generatedCampaign.headline}</p>
                      </div>
                      <div className="flex items-start gap-2">
                        <span className="text-[10px] text-gray-500 uppercase font-bold w-20 shrink-0 mt-0.5">Body:</span>
                        <p className="text-xs text-gray-300 leading-relaxed">{generatedCampaign.body}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {[
                        { label:'Estimated Reach', val:generatedCampaign.estimatedReach, color:'text-blue-400' },
                        { label:'Predicted CTR', val:generatedCampaign.predictedCTR, color:'text-green-400' },
                        { label:'Best Send Time', val:generatedCampaign.scheduledTime, color:'text-orange-400' },
                      ].map((s,i) => (
                        <div key={i} className="p-3 bg-white/5 border border-white/10 rounded-xl">
                          <p className="text-[9px] text-gray-500 uppercase font-bold">{s.label}</p>
                          <p className={`text-xs font-bold mt-1 ${s.color}`}>{s.val}</p>
                        </div>
                      ))}
                    </div>
                    <button onClick={() => alert(`Campaign scheduled! Will be sent via ${generatedCampaign.channel} to ${generatedCampaign.estimatedReach} at ${generatedCampaign.scheduledTime}.`)} className="w-full bg-orange-600 hover:bg-orange-500 text-white font-bold py-2.5 rounded-xl transition-colors text-sm">📤 Launch Campaign Now</button>
                  </div>
                )}
              </div>

              {/* Fraud Detection System */}
              <div className="glass border border-red-500/20 rounded-2xl p-5 space-y-4">
                <div>
                  <h3 className="font-bold text-sm flex items-center gap-2">🛡️ AI Fraud Detection System <span className="text-[9px] bg-red-500/20 text-red-400 border border-red-500/30 px-2 py-0.5 rounded font-bold">LIVE SHIELD</span></h3>
                  <p className="text-xs text-gray-400 mt-1">Real-time fraud signal monitoring across payments, QR codes, device fingerprints, and promo abuse patterns.</p>
                </div>

                {/* Live Stats */}
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-red-500/10 border border-red-500/20 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-400 uppercase">Blocked Today</p>
                    <p className="text-2xl font-black text-red-400">7</p>
                  </div>
                  <div className="bg-yellow-500/10 border border-yellow-500/20 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-400 uppercase">Flagged</p>
                    <p className="text-2xl font-black text-yellow-400">12</p>
                  </div>
                  <div className="bg-green-500/10 border border-green-500/20 p-3 rounded-xl text-center">
                    <p className="text-[9px] text-gray-400 uppercase">Clean Txns</p>
                    <p className="text-2xl font-black text-green-400">1,284</p>
                  </div>
                </div>

                {/* Manual Scan */}
                <div className="flex gap-3">
                  <input value={fraudScanInput} onChange={e=>setFraudScanInput(e.target.value)} placeholder="Enter User ID, Booking ID, or IP to scan..." className="input-field flex-1 text-sm" />
                  <button onClick={runFraudScan} className="bg-red-600 hover:bg-red-500 text-white text-xs font-bold px-5 py-2.5 rounded-xl transition-colors whitespace-nowrap">🔎 Scan</button>
                </div>
                {fraudScanResult && (
                  <div className={`p-3 rounded-xl border text-sm font-bold ${ fraudScanResult.safe ? 'bg-green-500/10 border-green-500/20 text-green-400' : 'bg-red-500/10 border-red-500/20 text-red-400' }`}>
                    {fraudScanResult.msg}
                  </div>
                )}

                {/* Fraud Log */}
                <div>
                  <p className="text-[10px] text-gray-500 font-bold uppercase tracking-wider mb-2">Live Fraud Signal Log</p>
                  <div className="space-y-2">
                    {fraudLog.map(f => (
                      <div key={f.id} className="flex items-center justify-between p-3 bg-white/5 border border-white/5 rounded-xl text-xs hover:border-red-500/20 transition-colors">
                        <div>
                          <p className="font-bold text-white">{f.type}</p>
                          <p className="text-gray-400">User: {f.user} • IP: {f.ip} • {f.time}</p>
                        </div>
                        <div className="text-right">
                          <span className={`inline-block text-[9px] px-1.5 py-0.5 rounded font-bold border mb-1 ${ f.risk === 'Critical' ? 'bg-red-500/20 text-red-400 border-red-500/30' : f.risk === 'High' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30' }`}>{f.risk}</span>
                          <p className={`text-[9px] font-bold ${ f.status === 'Blocked' || f.status === 'Denied Entry' ? 'text-red-400' : 'text-yellow-400' }`}>{f.status}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: STAFF MANAGEMENT */}
          {tab === 'staff' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-black">👥 Staff & Role Management</h2>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-1 bg-black/40 p-6 rounded-3xl border border-white/10 space-y-4 h-fit">
                  <h3 className="font-bold text-sm">Add New Admin User</h3>
                  <form onSubmit={handleAddAdmin} className="space-y-3">
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wider mb-1 block">Full Name</label>
                      <input value={newAdminName} onChange={e=>setNewAdminName(e.target.value)} required className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-red-500" placeholder="e.g. Rahul Verma" />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wider mb-1 block">Email</label>
                      <input type="email" value={newAdminEmail} onChange={e=>setNewAdminEmail(e.target.value)} required className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-red-500" placeholder="staff@karaicini.com" />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wider mb-1 block">Password</label>
                      <input type="password" value={newAdminPassword} onChange={e=>setNewAdminPassword(e.target.value)} required className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-red-500" placeholder="Secure Password" />
                    </div>
                    <div>
                      <label className="text-[10px] text-gray-400 uppercase tracking-wider mb-1 block">Assign Role</label>
                      <select value={newAdminRole} onChange={e=>setNewAdminRole(e.target.value)} className="w-full bg-black/40 border border-white/10 rounded-xl px-3 py-2 text-xs text-white outline-none focus:border-red-500 cursor-pointer">
                        <option value="Super Admin">🛡️ Super Admin (Full Control)</option>
                        <option value="Theater Manager">🎬 Theater Manager (Shows & Screens)</option>
                        <option value="Finance Admin">💰 Finance Admin (Payments & Refunds)</option>
                        <option value="Customer Support Admin">👤 Customer Support Admin (Complaints)</option>
                        <option value="Marketing Admin">📈 Marketing Admin (Promotions & Ads)</option>
                      </select>
                    </div>
                    <button type="submit" className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-2.5 rounded-xl text-xs transition-colors mt-2">Create Admin Account</button>
                  </form>
                </div>
                
                <div className="lg:col-span-2 bg-black/40 p-6 rounded-3xl border border-white/10">
                  <h3 className="font-bold text-sm mb-4">Active System Administrators</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead className="text-gray-400 border-b border-white/10">
                        <tr>
                          <th className="p-3">Name</th>
                          <th className="p-3">Email</th>
                          <th className="p-3">Assigned Role</th>
                          <th className="p-3">Action</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/10">
                        {adminUsers.map(a => (
                          <tr key={a.id} className="hover:bg-white/5 transition-colors">
                            <td className="p-3 font-bold text-white">{a.name}</td>
                            <td className="p-3 text-gray-400">{a.email}</td>
                            <td className="p-3">
                              <span className={`px-2 py-1 rounded text-[10px] font-bold border ${a.adminType === 'Super Admin' || a.id === 'admin' ? 'bg-red-500/20 text-red-400 border-red-500/30' : a.adminType === 'Finance Admin' ? 'bg-green-500/20 text-green-400 border-green-500/30' : 'bg-blue-500/20 text-blue-400 border-blue-500/30'}`}>
                                {a.adminType || 'Super Admin'}
                              </span>
                            </td>
                            <td className="p-3">
                              <button onClick={() => {
                                if(a.id === 'admin') return alert('Cannot delete the root administrator account.');
                                if(confirm(`Revoke admin access for ${a.name}?`)) {
                                  KC.USERS = KC.USERS.filter(u => u.id !== a.id);
                                  if (typeof localStorage !== 'undefined') localStorage.setItem('kc_users', JSON.stringify(KC.USERS));
                                  setAdminUsers(KC.USERS.filter(u => u.role === 'admin'));
                                }
                              }} className="text-red-500 hover:text-red-400 font-bold text-[10px]">Revoke Access</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: LIVE AI SURVEILLANCE */}
          {tab === 'surveillance' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-black">📷 Live AI Surveillance Center</h2>
                <div className="flex items-center gap-2 text-xs text-green-400 bg-green-500/10 border border-green-500/30 px-3 py-1.5 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                  LIVE — 6 Cameras Active
                </div>
              </div>

              {/* Active Alerts */}
              {surveillanceAlerts.length > 0 && (
                <div className="space-y-2">
                  {surveillanceAlerts.map(al => (
                    <div key={al.id} className={`flex items-start justify-between gap-4 p-4 rounded-xl border ${al.severity === 'High' ? 'bg-red-500/10 border-red-500/30' : 'bg-yellow-500/10 border-yellow-500/30'}`}>
                      <div className="flex items-start gap-3">
                        <span className="text-xl">{al.severity === 'High' ? '🚨' : '⚠️'}</span>
                        <div>
                          <div className="font-bold text-sm">{al.zone}</div>
                          <div className="text-xs text-gray-300 mt-0.5">{al.msg}</div>
                          <div className="text-[10px] text-gray-500 mt-1">{al.time}</div>
                        </div>
                      </div>
                      <button onClick={() => dismissAlert(al.id)} className="text-xs text-gray-400 hover:text-white shrink-0 bg-white/10 px-2 py-1 rounded-lg">Dismiss</button>
                    </div>
                  ))}
                </div>
              )}

              {/* CCTV Grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {cctv_zones.map(zone => (
                  <div key={zone.id} className={`relative bg-black rounded-2xl overflow-hidden border ${zone.status === 'Alert' ? 'border-red-500/60' : zone.status === 'Full' ? 'border-orange-500/60' : 'border-white/10'}`}>
                    {/* Simulated camera feed */}
                    <div className="h-28 bg-gradient-to-br from-gray-900 to-black relative flex items-center justify-center">
                      <div className="absolute inset-0 opacity-20" style={{backgroundImage:'repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(255,255,255,0.03) 2px,rgba(255,255,255,0.03) 4px)'}}></div>
                      <span className="text-4xl opacity-40">{zone.name.includes('Screen') ? '🎬' : zone.name.includes('Snack') ? '🍿' : zone.name.includes('Parking') ? '🚗' : zone.name.includes('Exit') ? '🚪' : '🏛️'}</span>
                      {/* Live indicator */}
                      <div className="absolute top-2 left-2 flex items-center gap-1">
                        <span className={`w-1.5 h-1.5 rounded-full ${zone.status === 'Alert' ? 'bg-red-500 animate-pulse' : 'bg-green-500'}`}></span>
                        <span className="text-[8px] text-white/70 font-mono">LIVE</span>
                      </div>
                      {/* Status badge */}
                      <div className={`absolute top-2 right-2 text-[9px] font-bold px-2 py-0.5 rounded ${zone.status === 'Alert' ? 'bg-red-500 text-white' : zone.status === 'Full' ? 'bg-orange-500 text-white' : zone.status === 'Busy' ? 'bg-yellow-500 text-black' : 'bg-green-500/80 text-white'}`}>
                        {zone.status}
                      </div>
                    </div>
                    <div className="p-3">
                      <div className="font-bold text-xs mb-2">{zone.name}</div>
                      <div className="space-y-1.5">
                        <div className="flex justify-between text-[10px]">
                          <span className="text-gray-400">Crowd</span>
                          <span className={`font-bold ${zone.crowd > 85 ? 'text-red-400' : zone.crowd > 60 ? 'text-yellow-400' : 'text-green-400'}`}>{zone.crowd}%</span>
                        </div>
                        <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
                          <div className={`h-full rounded-full ${zone.crowd > 85 ? 'bg-red-500' : zone.crowd > 60 ? 'bg-yellow-500' : 'bg-green-500'}`} style={{width: zone.crowd + '%'}}></div>
                        </div>
                        <div className="flex justify-between text-[10px]">
                          <span className="text-gray-400">Temp</span>
                          <span className="font-mono">{zone.temp}°C</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* AI Behavior Analysis */}
              <div className="glass p-5 rounded-2xl border border-white/10">
                <h3 className="font-bold mb-4">🧠 AI Crowd Behavior Analysis — Today</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                  <div className="bg-white/5 p-4 rounded-xl">
                    <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">Peak Congestion Predicted</div>
                    <div className="text-xl font-black">8:00 PM</div>
                    <div className="text-xs text-yellow-400 mt-1">⚠️ Open Gate 3 by 7:30 PM</div>
                  </div>
                  <div className="bg-white/5 p-4 rounded-xl">
                    <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">Avg Queue Wait Time</div>
                    <div className="text-xl font-black">9.4 min</div>
                    <div className="text-xs text-green-400 mt-1">✅ Within acceptable limits</div>
                  </div>
                  <div className="bg-white/5 p-4 rounded-xl">
                    <div className="text-[10px] text-gray-400 uppercase font-bold mb-1">Security Incidents Today</div>
                    <div className="text-xl font-black text-red-400">2</div>
                    <div className="text-xs text-red-400 mt-1">🚨 Requires investigation</div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB: HARDWARE HEALTH */}
          {tab === 'hardware' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h2 className="text-2xl font-black">🛠️ Predictive Hardware Maintenance</h2>
                <div className="text-xs text-blue-400 bg-blue-500/10 border border-blue-500/30 px-3 py-1.5 rounded-full">
                  IoT Monitoring Active — 5 Devices
                </div>
              </div>

              {/* Critical Alerts Summary */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-green-500/10 border border-green-500/30 p-4 rounded-xl text-center">
                  <div className="text-2xl font-black text-green-400">{hardwareList.filter(h => h.status === 'Good').length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Systems Healthy</div>
                </div>
                <div className="bg-yellow-500/10 border border-yellow-500/30 p-4 rounded-xl text-center">
                  <div className="text-2xl font-black text-yellow-400">{hardwareList.filter(h => h.status === 'Warning').length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Needs Attention</div>
                </div>
                <div className="bg-red-500/10 border border-red-500/30 p-4 rounded-xl text-center">
                  <div className="text-2xl font-black text-red-400">{hardwareList.filter(h => h.status === 'Critical').length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Critical Failures</div>
                </div>
              </div>

              {/* Device List */}
              <div className="space-y-4">
                {hardwareList.map(hw => (
                  <div key={hw.id} className={`p-5 rounded-2xl border ${hw.status === 'Critical' ? 'bg-red-500/5 border-red-500/30' : hw.status === 'Warning' ? 'bg-yellow-500/5 border-yellow-500/30' : 'bg-white/5 border-white/10'}`}>
                    <div className="flex flex-wrap gap-4 items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`w-2.5 h-2.5 rounded-full ${hw.status === 'Critical' ? 'bg-red-500 animate-pulse' : hw.status === 'Warning' ? 'bg-yellow-500' : 'bg-green-500'}`}></span>
                          <h3 className="font-bold">{hw.device}</h3>
                          <span className="text-[10px] text-gray-500 bg-white/5 px-2 py-0.5 rounded">{hw.screen}</span>
                        </div>
                        {hw.issue && <p className="text-xs text-red-300 bg-red-500/10 px-3 py-1.5 rounded-lg mt-2">⚠️ {hw.issue}</p>}
                      </div>
                      <button
                        onClick={() => runHwDiag(hw.id)}
                        disabled={hwRunningDiag === hw.id}
                        className={`text-xs font-bold px-4 py-1.5 rounded-lg border transition-all ${hwRunningDiag === hw.id ? 'opacity-50 bg-white/5 border-white/10' : 'bg-blue-500/20 border-blue-500/30 text-blue-400 hover:bg-blue-500/30'}`}
                      >
                        {hwRunningDiag === hw.id ? '⟳ Scanning...' : '🔍 Run Diagnostics'}
                      </button>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-4 text-xs">
                      <div>
                        <div className="text-[10px] text-gray-500 mb-1">Health Score</div>
                        <div className="flex items-center gap-2">
                          <div className="flex-1 h-2 bg-white/10 rounded-full overflow-hidden">
                            <div className={`h-full rounded-full ${hw.health > 80 ? 'bg-green-500' : hw.health > 60 ? 'bg-yellow-500' : 'bg-red-500'}`} style={{width: hw.health + '%'}}></div>
                          </div>
                          <span className="font-bold">{hw.health}%</span>
                        </div>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500 mb-1">Temperature</div>
                        <span className={`font-bold ${hw.temp > 70 ? 'text-red-400' : hw.temp > 55 ? 'text-yellow-400' : 'text-green-400'}`}>{hw.temp}°C</span>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500 mb-1">Operating Hours</div>
                        <span className="font-bold font-mono">{hw.hours.toLocaleString()} hrs</span>
                      </div>
                      <div>
                        <div className="text-[10px] text-gray-500 mb-1">Next Service</div>
                        <span className={`font-bold ${new Date(hw.nextService) < new Date() ? 'text-red-400' : 'text-white'}`}>{hw.nextService}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB: VIP CUSTOMER CRM */}
          {tab === 'vipcrm' && (
            <div className="space-y-6 animate-fade-in">
              <div className="flex items-center justify-between flex-wrap gap-3">
                <h2 className="text-2xl font-black">💎 VIP Customer CRM</h2>
                <div className="flex gap-2">
                  {['All','Platinum','Gold','Silver'].map(t => (
                    <button key={t} onClick={() => setVipFilter(t)} className={`text-xs font-bold px-3 py-1.5 rounded-full border transition-all ${vipFilter === t ? 'bg-gradient-to-r from-yellow-500 to-orange-500 text-black border-transparent' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white'}`}>{t}</button>
                  ))}
                </div>
              </div>

              {/* Summary Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-cyan-500/10 border border-cyan-500/30 p-4 rounded-xl">
                  <div className="text-xl font-black text-cyan-400">₹{(vipCustomers.reduce((s,c) => s+c.totalSpent, 0)/1000).toFixed(0)}K</div>
                  <div className="text-[10px] text-gray-400 mt-1">Total VIP Revenue</div>
                </div>
                <div className="bg-yellow-500/10 border border-yellow-500/30 p-4 rounded-xl">
                  <div className="text-xl font-black text-yellow-400">{vipCustomers.filter(c => c.tier === 'Platinum').length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">Platinum Members</div>
                </div>
                <div className="bg-red-500/10 border border-red-500/30 p-4 rounded-xl">
                  <div className="text-xl font-black text-red-400">{vipCustomers.filter(c => c.tags.includes('Lapsing')).length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">At-Risk of Churn</div>
                </div>
                <div className="bg-green-500/10 border border-green-500/30 p-4 rounded-xl">
                  <div className="text-xl font-black text-green-400">{Object.keys(vipOfferSent).length}</div>
                  <div className="text-[10px] text-gray-400 mt-1">VIP Offers Sent Today</div>
                </div>
              </div>

              {/* Customer List */}
              <div className="space-y-4">
                {vipCustomers.filter(c => vipFilter === 'All' || c.tier === vipFilter).map(customer => (
                  <div key={customer.id} className="glass p-5 rounded-2xl border border-white/10 hover:border-white/20 transition-all">
                    <div className="flex flex-wrap gap-4 items-start justify-between">
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl shrink-0 ${customer.tier === 'Platinum' ? 'bg-gradient-to-br from-cyan-500 to-blue-500' : customer.tier === 'Gold' ? 'bg-gradient-to-br from-yellow-500 to-orange-500' : 'bg-gradient-to-br from-gray-500 to-gray-600'}`}>
                          {customer.name.charAt(0)}
                        </div>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="font-bold">{customer.name}</h3>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${customer.tier === 'Platinum' ? 'bg-cyan-500/20 text-cyan-400' : customer.tier === 'Gold' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-gray-500/20 text-gray-400'}`}>{customer.tier}</span>
                            <span className={`text-sm ${customer.trend === '↑' ? 'text-green-400' : customer.trend === '↓' ? 'text-red-400' : 'text-gray-400'}`}>{customer.trend}</span>
                          </div>
                          <div className="text-xs text-gray-400 mt-0.5">{customer.email} • Last visit: {customer.lastVisit}</div>
                          <div className="flex gap-1 mt-2 flex-wrap">
                            {customer.tags.map(tag => (
                              <span key={tag} className={`text-[9px] font-bold px-2 py-0.5 rounded border ${tag === 'Whale' ? 'bg-red-500/20 text-red-400 border-red-500/30' : tag === 'Lapsing' ? 'bg-orange-500/20 text-orange-400 border-orange-500/30' : 'bg-white/5 text-gray-400 border-white/10'}`}>{tag}</span>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-black text-white">₹{customer.totalSpent.toLocaleString()}</div>
                        <div className="text-[10px] text-gray-400">{customer.visits} visits • {customer.points} pts</div>
                      </div>
                    </div>

                    {/* Preferences */}
                    <div className="grid grid-cols-3 gap-3 mt-4 text-xs border-t border-white/5 pt-4">
                      <div className="bg-white/5 p-3 rounded-xl">
                        <div className="text-[9px] text-gray-500 uppercase mb-1">Fav Genre</div>
                        <div className="font-bold text-xs">{customer.favGenre}</div>
                      </div>
                      <div className="bg-white/5 p-3 rounded-xl">
                        <div className="text-[9px] text-gray-500 uppercase mb-1">Fav Seat</div>
                        <div className="font-bold text-xs">{customer.favSeat}</div>
                      </div>
                      <div className="bg-white/5 p-3 rounded-xl">
                        <div className="text-[9px] text-gray-500 uppercase mb-1">Fav Snack</div>
                        <div className="font-bold text-xs">{customer.favSnack}</div>
                      </div>
                    </div>

                    {/* Quick Action */}
                    <div className="flex gap-2 mt-4 flex-wrap">
                      {!vipOfferSent[customer.id] ? (
                        <>
                          <button onClick={() => sendVipOffer(customer.id, 'VIP20')} className="text-xs bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-bold px-4 py-1.5 rounded-lg hover:opacity-90 transition-opacity">
                            🎁 Send VIP20 Offer
                          </button>
                          <button onClick={() => sendVipOffer(customer.id, 'EXCLUSIVE50')} className="text-xs bg-white/10 border border-white/10 hover:bg-white/20 font-bold px-4 py-1.5 rounded-lg transition-colors">
                            💌 Send EXCLUSIVE50
                          </button>
                        </>
                      ) : (
                        <div className="text-xs text-green-400 bg-green-500/10 border border-green-500/30 px-4 py-1.5 rounded-lg font-bold">
                          ✅ Offer Sent: {vipOfferSent[customer.id]}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

      </div>
      </div>
    </div>
  );
};

// Export to window for global access between separate Babel scripts
window.BookingFlow = BookingFlow;
window.Dashboard = Dashboard;
window.AdminDashboard = AdminDashboard;

