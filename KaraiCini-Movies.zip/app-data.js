// KaraiCini Movies — Data Layer
const APP_NAME = "KaraiCini Movies";
const API_BASE = "http://localhost:4000";

const DEFAULT_MOVIES = [
  { id:'m1', title:'Pushpa 2: The Rule', rating:7.9, year:2024, duration:179, lang:'Telugu', langs:['Telugu','Hindi','Tamil'], genre:['Action','Drama'], director:'Sukumar', cast:['Allu Arjun','Rashmika Mandanna','Fahadh Faasil'], poster:'./pushpa2_poster.png', backdrop:'./pushpa2_poster.png', status:'Now Showing', price:260, tags:['Blockbuster','4DX'], demand:'high', desc:'Pushpa Raj expands his red sandalwood empire against all odds.', cert:'UA' },
  { id:'m2', title:'Kalki 2898-AD', rating:6.8, year:2024, duration:181, lang:'Telugu', langs:['Telugu','Hindi','Tamil','English'], genre:['Sci-Fi','Action'], director:'Nag Ashwin', cast:['Prabhas','Deepika Padukone','Amitabh Bachchan'], poster:'./kalki_poster.png', backdrop:'./kalki_poster.png', status:'Now Showing', price:280, tags:['IMAX','3D'], demand:'high', desc:'A mythological sci-fi epic set in dystopian future India.', cert:'UA' },
  { id:'m3', title:'Stree 2', rating:8.0, year:2024, duration:135, lang:'Hindi', langs:['Hindi'], genre:['Horror','Comedy'], director:'Amar Kaushik', cast:['Rajkummar Rao','Shraddha Kapoor'], poster:'./stree2_poster.png', backdrop:'./stree2_poster.png', status:'Now Showing', price:220, tags:['Superhit'], demand:'high', desc:'Stree returns to haunt Chanderi once more.', cert:'UA' },
  { id:'m4', title:'Deadpool & Wolverine', rating:7.8, year:2024, duration:128, lang:'English', langs:['English','Hindi'], genre:['Action','Comedy'], director:'Shawn Levy', cast:['Ryan Reynolds','Hugh Jackman'], poster:'./deadpool_poster.png', backdrop:'./deadpool_poster.png', status:'Now Showing', price:300, tags:['Marvel','IMAX'], demand:'medium', desc:'Two unlikely heroes team up to save the multiverse.', cert:'A' },
  { id:'m5', title:'The Wild Robot', rating:8.3, year:2024, duration:102, lang:'English', langs:['English','Hindi','Tamil','Telugu'], genre:['Animation','Family'], director:'Chris Sanders', cast:['Lupita Nyong\'o','Pedro Pascal'], poster:'./wild_robot_poster.png', backdrop:'./wild_robot_poster.png', status:'Now Showing', price:200, tags:['Family','Oscar'], demand:'medium', desc:'A robot stranded on a wild island must learn to survive.', cert:'U' },
  { id:'m6', title:'Lucky Bhaskar', rating:8.1, year:2024, duration:152, lang:'Telugu', langs:['Telugu','Tamil','Hindi'], genre:['Thriller','Drama'], director:'Venky Atluri', cast:['Dulquer Salmaan','Meenakshi Chaudhary'], poster:'./lucky_bhaskar_poster.png', backdrop:'./lucky_bhaskar_poster.png', status:'Now Showing', price:240, tags:['Hit'], demand:'medium', desc:'A mild-mannered bank employee accidentally becomes a financial genius.', cert:'UA' },
  { id:'m7', title:'Inside Out 2', rating:7.8, year:2024, duration:100, lang:'English', langs:['English','Hindi','Tamil','Telugu'], genre:['Animation','Comedy'], director:'Kelsey Mann', cast:['Amy Poehler','Maya Hawke'], poster:'./inside_out_2_poster.png', backdrop:'./inside_out_2_poster.png', status:'Now Showing', price:220, tags:['Pixar','3D'], demand:'low', desc:'Riley navigates new emotions as she enters high school.', cert:'U' },
  { id:'m8', title:'Vettaiyan', rating:7.2, year:2024, duration:179, lang:'Tamil', langs:['Tamil','Telugu','Hindi'], genre:['Action','Drama'], director:'T.J. Gnanavel', cast:['Rajinikanth','Amitabh Bachchan','Fahadh Faasil'], poster:'./vettaiyan_poster.png', backdrop:'./vettaiyan_poster.png', status:'Now Showing', price:240, tags:['Superstar'], demand:'medium', desc:'A cop confronts a system that protects criminals.', cert:'UA' },
  { id:'m9', title:'Alien: Romulus', rating:7.3, year:2024, duration:119, lang:'English', langs:['English','Hindi'], genre:['Horror','Sci-Fi'], director:'Fede Álvarez', cast:['Cailee Spaeny','David Jonsson'], poster:'./alien_romulus_poster.png', backdrop:'./alien_romulus_poster.png', status:'Now Showing', price:260, tags:['Horror','Dolby'], demand:'low', desc:'Young colonists face a terrifying encounter with the Alien.', cert:'A' },
  { id:'m10', title:'Gladiator II', rating:6.5, year:2024, duration:148, lang:'English', langs:['English','Hindi','Tamil'], genre:['Action','Drama'], director:'Ridley Scott', cast:['Paul Mescal','Denzel Washington','Pedro Pascal'], poster:'./gladiator_2_poster.png', backdrop:'./gladiator_2_poster.png', status:'Now Showing', price:280, tags:['Epic','IMAX'], demand:'low', desc:'A Roman general fights for freedom in the gladiatorial arena.', cert:'UA' },
  { id:'m11', title:'Moana 2', rating:7.0, year:2024, duration:100, lang:'English', langs:['English','Hindi','Tamil'], genre:['Animation','Adventure'], director:'Dave Derrick Jr.', cast:['Auli\'i Cravalho','Dwayne Johnson'], poster:'./moana_2_poster.png', backdrop:'./moana_2_poster.png', status:'Now Showing', price:220, tags:['Disney','Family'], demand:'high', desc:'Moana takes on a dangerous new mission across the far seas.', cert:'U' },
  { id:'m12', title:'Wicked', rating:8.0, year:2024, duration:160, lang:'English', langs:['English'], genre:['Fantasy','Musical'], director:'Jon M. Chu', cast:['Cynthia Erivo','Ariana Grande'], poster:'./wicked_poster.png', backdrop:'./wicked_poster.png', status:'Now Showing', price:250, tags:['Musical'], demand:'medium', desc:'The untold story of the witches of Oz.', cert:'U' },
  { id:'m13', title:'Dune: Part Two', rating:8.6, year:2024, duration:166, lang:'English', langs:['English','Hindi'], genre:['Sci-Fi','Adventure'], director:'Denis Villeneuve', cast:['Timothée Chalamet','Zendaya'], poster:'./dune_part_two_poster.png', backdrop:'./dune_part_two_poster.png', status:'Now Showing', price:300, tags:['Epic','IMAX'], demand:'high', desc:'Paul Atreides unites with Chani to seek revenge.', cert:'UA' },
  { id:'m14', title:'Godzilla x Kong', rating:6.7, year:2024, duration:115, lang:'English', langs:['English','Hindi','Tamil','Telugu'], genre:['Action','Sci-Fi'], director:'Adam Wingard', cast:['Rebecca Hall','Brian Tyree Henry'], poster:'./godzilla_poster.png', backdrop:'./godzilla_poster.png', status:'Now Showing', price:260, tags:['Monster','3D'], demand:'high', desc:'Godzilla and Kong face a colossal undiscovered threat.', cert:'UA' },
  { id:'m15', title:'Munjya', rating:7.2, year:2024, duration:123, lang:'Hindi', langs:['Hindi'], genre:['Comedy','Horror'], director:'Aditya Sarpotdar', cast:['Abhay Verma','Sharvari'], poster:'https://images.unsplash.com/photo-1508873696983-2df519f0397e?w=400&h=600&fit=crop', backdrop:'https://images.unsplash.com/photo-1508873696983-2df519f0397e?w=1400&h=500&fit=crop', status:'Now Showing', price:200, tags:['Horror Comedy'], demand:'medium', desc:'A young man visits his native village to uncover family secrets.', cert:'UA' },
  { id:'m16', title:'Furiosa: A Mad Max Saga', rating:7.7, year:2024, duration:148, lang:'English', langs:['English','Hindi'], genre:['Action','Sci-Fi'], director:'George Miller', cast:['Anya Taylor-Joy','Chris Hemsworth'], poster:'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=400&h=600&fit=crop', backdrop:'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=1400&h=500&fit=crop', status:'Now Showing', price:280, tags:['Action','IMAX'], demand:'medium', desc:'The origin story of renegade warrior Furiosa.', cert:'A' },
  { id:'m17', title:'Devara: Part 1', rating:6.9, year:2024, duration:170, lang:'Telugu', langs:['Telugu','Hindi','Tamil'], genre:['Action','Drama'], director:'Koratala Siva', cast:['N.T. Rama Rao Jr.','Janhvi Kapoor','Saif Ali Khan'], poster:'https://images.unsplash.com/photo-1439405326854-014607f694d7?w=400&h=600&fit=crop', backdrop:'https://images.unsplash.com/photo-1439405326854-014607f694d7?w=1400&h=500&fit=crop', status:'Now Showing', price:260, tags:['Action','Epic'], demand:'high', desc:'A heroic tale of fear, power, and courage.', cert:'UA' },
  { id:'m18', title:'The Fall Guy', rating:7.0, year:2024, duration:126, lang:'English', langs:['English','Hindi'], genre:['Action','Comedy'], director:'David Leitch', cast:['Ryan Gosling','Emily Blunt'], poster:'https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=400&h=600&fit=crop', backdrop:'https://images.unsplash.com/photo-1518173946687-a4c8a383392e?w=1400&h=500&fit=crop', status:'Now Showing', price:240, tags:['Action'], demand:'medium', desc:'A stuntman investigates the disappearance of a movie star.', cert:'UA' },
  { id:'m19', title:'Amaran', rating:8.4, year:2024, duration:169, lang:'Tamil', langs:['Tamil','Telugu','Hindi'], genre:['Action','Biography'], director:'Rajkumar Periasamy', cast:['Sivakarthikeyan','Sai Pallavi'], poster:'https://images.unsplash.com/photo-1508138221679-760a37769047?w=400&h=600&fit=crop', backdrop:'https://images.unsplash.com/photo-1508138221679-760a37769047?w=1400&h=500&fit=crop', status:'Now Showing', price:250, tags:['Patriotic','Action'], demand:'high', desc:'The inspiring real-life story of Major Mukund Varadarajan.', cert:'UA' },
  { id:'m20', title:'Bad Boys: Ride or Die', rating:7.1, year:2024, duration:115, lang:'English', langs:['English','Hindi'], genre:['Action','Comedy'], director:'Adil El Arbi, Bilall Fallah', cast:['Will Smith','Martin Lawrence'], poster:'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=400&h=600&fit=crop', backdrop:'https://images.unsplash.com/photo-1543466835-00a7907e9de1?w=1400&h=500&fit=crop', status:'Now Showing', price:250, tags:['Comedy','Action'], demand:'medium', desc:'The Bad Boys are back, but this time they are on the run.', cert:'A' }
];

let MOVIES = JSON.parse(localStorage.getItem('kc_movies') || 'null');
if (!MOVIES) {
  MOVIES = DEFAULT_MOVIES;
  localStorage.setItem('kc_movies', JSON.stringify(MOVIES));
}

function saveMovies() {
  localStorage.setItem('kc_movies', JSON.stringify(window.KC.MOVIES));
}


const SNACKS = [
  { id:'sn1', name:'Large Popcorn', price:220, orig:280, cat:'Popcorn', popular:true, veg:true, img:'https://images.unsplash.com/photo-1574126154517-d1e0d89ef734?w=400&h=400&fit=crop', emoji:'🍿', desc:'Buttery salted perfection' },
  { id:'sn2', name:'Cheese Nachos', price:180, orig:220, cat:'Snacks', popular:true, veg:true, img:'https://images.unsplash.com/photo-1513456852971-30c0b8199d4d?w=400&h=400&fit=crop', emoji:'🧀', desc:'Crispy nachos with cheese dip' },
  { id:'sn3', name:'Cold Drink Combo', price:160, orig:200, cat:'Drinks', popular:false, veg:true, img:'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&h=400&fit=crop', emoji:'🥤', desc:'2 chilled beverages' },
  { id:'sn4', name:'Crispy Burger', price:199, orig:249, cat:'Snacks', popular:false, veg:false, img:'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=400&fit=crop', emoji:'🍔', desc:'Juicy crispy burger' },
  { id:'sn5', name:'Chocolate Brownie', price:149, orig:180, cat:'Desserts', popular:true, veg:true, img:'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&h=400&fit=crop', emoji:'🍫', desc:'Warm fudge brownie' },
  { id:'sn6', name:'Popcorn Combo', price:380, orig:480, cat:'Combo', popular:true, veg:true, img:'https://images.unsplash.com/photo-1621250268579-2470877a5611?w=400&h=400&fit=crop', emoji:'🎉', desc:'Popcorn + 2 drinks' },
  { id:'sn7', name:'Hot Dog', price:149, orig:180, cat:'Snacks', popular:false, veg:false, img:'https://images.unsplash.com/photo-1612392166886-ee8475b03af2?w=400&h=400&fit=crop', emoji:'🌭', desc:'Grilled hot dog' },
  { id:'sn8', name:'Mineral Water', price:60, orig:60, cat:'Drinks', popular:false, veg:true, img:'https://images.unsplash.com/photo-1548839140-29a749e1cf4d?w=400&h=400&fit=crop', emoji:'💧', desc:'500ml chilled water' },
];

// Voucher engine — fewer vouchers for high-demand, AI reasoning added
function getVouchers(movie, showHour) {
  const v = [];
  const d = movie.demand || 'medium';
  const isMorning = showHour < 12;
  const isLateNight = showHour >= 22;
  const isAfternoon = showHour >= 12 && showHour < 17;

  if (d === 'low') {
    v.push({ code:'SAVE30', label:'30% OFF', type:'percent', value:0.30, reason:'Low demand special' });
    v.push({ code:'FLAT200', label:'₹200 OFF', type:'flat', value:200, reason:'Fill the seats discount' });
    v.push({ code:'EXTRA20', label:'20% OFF', type:'percent', value:0.20, reason:'Extra savings for you' });
    if (isAfternoon) v.push({ code:'MATINEE25', label:'25% Matinee', type:'percent', value:0.25, reason:'Afternoon show deal' });
  }
  if (d === 'medium') {
    v.push({ code:'SAVE15', label:'15% OFF', type:'percent', value:0.15, reason:'Mid-demand offer' });
    v.push({ code:'FLAT100', label:'₹100 OFF', type:'flat', value:100, reason:'Weekend saver' });
    if (isAfternoon) v.push({ code:'MIDDAY10', label:'10% OFF', type:'percent', value:0.10, reason:'Afternoon special' });
  }
  if (d === 'high') {
    // For full demanding movies, fewer vouchers
    v.push({ code:'HIGH5', label:'5% OFF', type:'percent', value:0.05, reason:'Limited reward for highly anticipated movie' });
    if (isMorning) v.push({ code:'EARLY50', label:'₹50 OFF', type:'flat', value:50, reason:'Early morning discount' });
  } else {
    if (isMorning) v.push({ code:'EARLYBIRD20', label:'20% Early Bird', type:'percent', value:0.20, reason:'Morning show reward' });
    if (isLateNight) v.push({ code:'NIGHTOWL15', label:'15% Night Owl', type:'percent', value:0.15, reason:'Late night special' });
  }
  return v;
}

function applyVoucher(voucher, total) {
  if (voucher.type === 'percent') return Math.round(total * voucher.value);
  if (voucher.type === 'flat') return Math.min(voucher.value, total);
  return 0;
}

const LANGUAGES = ['English','Hindi','Tamil','Telugu','Malayalam','Kannada'];

let USERS = JSON.parse(localStorage.getItem('kc_users') || '[{"id":"u1","name":"Aarav Sharma","email":"aarav@example.com","password":"Demo@123","phone":"9876543210","role":"user","prefLangs":["English","Hindi"]},{"id":"admin","name":"Admin","email":"admin@karaicini.com","password":"Admin@123","phone":"9999999999","role":"admin","prefLangs":["English"]}]');
function saveUsers() { localStorage.setItem('kc_users', JSON.stringify(USERS)); }

let BOOKINGS = JSON.parse(localStorage.getItem('kc_bookings') || '[]');

function saveBookings() { localStorage.setItem('kc_bookings', JSON.stringify(BOOKINGS)); }

function canCancelBooking(showDate, showTime) {
  try {
    const [h, m] = showTime.replace(' AM','').replace(' PM','').split(':').map(Number);
    const isPM = showTime.includes('PM');
    const hour = isPM && h !== 12 ? h + 12 : (!isPM && h === 12 ? 0 : h);
    
    // Parse date components locally to avoid UTC shifting
    const [year, month, day] = showDate.split('-').map(Number);
    const showDt = new Date(year, month - 1, day, hour, m || 0, 0, 0);
    
    const diff = showDt.getTime() - new Date().getTime();
    return diff > (30 * 60 * 1000); // Only allow cancellation if more than 30 mins left
  } catch { return false; }
}

function generateShows(movieId) {
  const movie = MOVIES.find(m => m.id === movieId);
  if (!movie) return [];
  const slots = [
    {t:'9:30 AM',h:9},{t:'12:00 PM',h:12},{t:'2:45 PM',h:14},
    {t:'5:30 PM',h:17},{t:'8:00 PM',h:20},{t:'10:30 PM',h:22}
  ];
  const screens = ['Screen Alpha','Screen Beta','Screen Gamma','Screen Delta','Screen Epsilon'];
  const now = new Date();
  const shows = [];
  for (let day = 0; day < 7; day++) {
    const d = new Date(now);
    d.setDate(d.getDate() + day);
    const iso = d.toISOString().split('T')[0];
    slots.forEach((slot, i) => {
      if (day === 0 && slot.h <= now.getHours()) return;
      const booked = Math.floor(Math.random() * 60);
      const avail = 96 - booked;
      const isWeekend = d.getDay() === 0 || d.getDay() === 6;
      const isBlockbuster = movie.demand === 'high';
      
      let surgeMulti = 1.0;
      let surgeReason = null;
      
      if (isBlockbuster && isWeekend) {
        surgeMulti = 1.3;
        surgeReason = 'AI Predicts: Weekend Blockbuster Crowd';
      } else if (isWeekend) {
        surgeMulti = 1.15;
        surgeReason = 'AI Predicts: High Weekend Demand';
      } else if (isBlockbuster) {
        surgeMulti = 1.1;
        surgeReason = 'AI Predicts: Blockbuster Trend';
      } else if (avail < 15) {
        surgeMulti = 1.2;
        surgeReason = 'AI Predicts: Seats Filling Fast';
      }

      const price = Math.round(movie.price * surgeMulti);
      shows.push({
        id:`${movieId}-${iso}-${slot.h}`,
        movieId, screen:screens[i%3], showDate:iso, showTime:slot.t,
        showHour:slot.h, price, avail, booked, total:96,
        surge: !!surgeReason, surgeReason, surgeMulti, occPct:Math.round((booked/96)*100),
        lang:movie.lang, langs:movie.langs || [movie.lang]
      });
    });
  }
  return shows;
}

function generateSeats(showId) {
  // Extract movie ID and Date to vary pricing based on dynamic AI predictor
  const parts = showId.split('-');
  const movieId = parts[0];
  const year = parseInt(parts[1]), month = parseInt(parts[2]), day = parseInt(parts[3]);
  const showDate = new Date(year, month - 1, day);
  
  const movie = MOVIES.find(m => m.id === movieId);
  
  const isWeekend = showDate.getDay() === 0 || showDate.getDay() === 6;
  const isBlockbuster = movie && movie.demand === 'high';
  
  let demandMulti = 1.0;
  if (isBlockbuster && isWeekend) demandMulti = 1.3;
  else if (isWeekend) demandMulti = 1.15;
  else if (isBlockbuster) demandMulti = 1.1;
  else if (movie && movie.demand === 'low') demandMulti = 0.8;

  const rows = 'ABCDEFGH'.split('');
  return rows.flatMap(row =>
    Array.from({length:12},(_,i) => {
      let type, basePrice;
      if (row === 'H' || row === 'G') { type = 'Recliner'; basePrice = 600; }
      else if (row === 'F' || row === 'E' || row === 'D') { type = 'Gold'; basePrice = 300; }
      else { type = 'Silver'; basePrice = 200; }
      
      return {
        id:`${showId}-${row}${i+1}`, showId, row, number:i+1,
        seatType:type, price: Math.round(basePrice * demandMulti),
        status:Math.random()<0.28?'booked':'available'
      };
    })
  );
}

window.KC = { APP_NAME, API_BASE, MOVIES, SNACKS, USERS, BOOKINGS, LANGUAGES, getVouchers, applyVoucher, saveBookings, saveUsers, saveMovies, canCancelBooking, generateShows, generateSeats };
