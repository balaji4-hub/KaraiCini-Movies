-- =====================================================
--  KaraiCini Movies — MySQL Database Setup
--  Run this file once to create all tables + seed data
--  Usage: mysql -u root -p < database.sql
-- =====================================================

CREATE DATABASE IF NOT EXISTS cineai CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cineai;

-- ─────────────────────────────────────────────────────
--  MOVIES
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS movies (
  id          VARCHAR(10)  PRIMARY KEY,
  title       VARCHAR(200) NOT NULL,
  rating      DECIMAL(3,1) DEFAULT 0,
  year        SMALLINT,
  duration    SMALLINT,
  lang        VARCHAR(50),
  langs       JSON,
  genre       JSON,
  director    VARCHAR(150),
  cast_members JSON,
  poster      VARCHAR(500),
  backdrop    VARCHAR(500),
  status      VARCHAR(50)  DEFAULT 'Now Showing',
  base_price  INT          DEFAULT 200,
  tags        JSON,
  demand      ENUM('low','medium','high') DEFAULT 'medium',
  description TEXT,
  cert        VARCHAR(10),
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────────────
--  SNACKS
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS snacks (
  id          VARCHAR(10)  PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  price       INT          NOT NULL,
  orig_price  INT,
  category    VARCHAR(50),
  is_popular  TINYINT(1)   DEFAULT 0,
  is_veg      TINYINT(1)   DEFAULT 1,
  emoji       VARCHAR(10),
  description VARCHAR(255)
);

-- ─────────────────────────────────────────────────────
--  USERS
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
  id          VARCHAR(20)  PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  phone       VARCHAR(20),
  role        ENUM('user','admin') DEFAULT 'user',
  pref_langs  JSON,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- ─────────────────────────────────────────────────────
--  SHOWS
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS shows (
  id          VARCHAR(100) PRIMARY KEY,
  movie_id    VARCHAR(10)  NOT NULL,
  screen      VARCHAR(50),
  show_date   DATE         NOT NULL,
  show_time   VARCHAR(15),
  show_hour   TINYINT,
  lang        VARCHAR(50),
  price       INT          DEFAULT 200,
  total_seats INT          DEFAULT 96,
  booked_seats INT         DEFAULT 0,
  surge       TINYINT(1)   DEFAULT 0,
  surge_reason VARCHAR(200),
  surge_multi  DECIMAL(4,2) DEFAULT 1.00,
  created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────────────────
--  SEATS
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS seats (
  id          VARCHAR(150) PRIMARY KEY,
  show_id     VARCHAR(100) NOT NULL,
  row_label   CHAR(1)      NOT NULL,
  seat_number TINYINT      NOT NULL,
  seat_type   ENUM('Silver','Gold','Recliner') DEFAULT 'Silver',
  price       INT          NOT NULL,
  status      ENUM('available','booked') DEFAULT 'available',
  FOREIGN KEY (show_id) REFERENCES shows(id) ON DELETE CASCADE
);

-- ─────────────────────────────────────────────────────
--  BOOKINGS
-- ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bookings (
  id              VARCHAR(20)  PRIMARY KEY,
  user_id         VARCHAR(20)  NOT NULL,
  show_id         VARCHAR(100) NOT NULL,
  seats           JSON,
  snacks          JSON,
  seat_total      INT          DEFAULT 0,
  snack_total     INT          DEFAULT 0,
  discount        INT          DEFAULT 0,
  parking_fee     INT          DEFAULT 0,
  grand_total     INT          DEFAULT 0,
  voucher_code    VARCHAR(30),
  parking         TINYINT(1)   DEFAULT 0,
  payment_method  VARCHAR(50),
  status          ENUM('confirmed','cancelled') DEFAULT 'confirmed',
  qr_code         VARCHAR(100),
  created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (show_id) REFERENCES shows(id)
);

-- ─────────────────────────────────────────────────────
--  SEED: MOVIES
-- ─────────────────────────────────────────────────────
INSERT IGNORE INTO movies VALUES
('m1','Pushpa 2: The Rule',7.9,2024,179,'Telugu','["Telugu","Hindi","Tamil"]','["Action","Drama"]','Sukumar','["Allu Arjun","Rashmika Mandanna","Fahadh Faasil"]','./pushpa2_poster.png','./pushpa2_poster.png','Now Showing',260,'["Blockbuster","4DX"]','high','Pushpa Raj expands his red sandalwood empire against all odds.','UA',NOW()),
('m2','Kalki 2898-AD',6.8,2024,181,'Telugu','["Telugu","Hindi","Tamil","English"]','["Sci-Fi","Action"]','Nag Ashwin','["Prabhas","Deepika Padukone","Amitabh Bachchan"]','./kalki_poster.png','./kalki_poster.png','Now Showing',280,'["IMAX","3D"]','high','A mythological sci-fi epic set in dystopian future India.','UA',NOW()),
('m3','Stree 2',8.0,2024,135,'Hindi','["Hindi"]','["Horror","Comedy"]','Amar Kaushik','["Rajkummar Rao","Shraddha Kapoor"]','./stree2_poster.png','./stree2_poster.png','Now Showing',220,'["Superhit"]','high','Stree returns to haunt Chanderi once more.','UA',NOW()),
('m4','Deadpool & Wolverine',7.8,2024,128,'English','["English","Hindi"]','["Action","Comedy"]','Shawn Levy','["Ryan Reynolds","Hugh Jackman"]','./deadpool_poster.png','./deadpool_poster.png','Now Showing',300,'["Marvel","IMAX"]','medium','Two unlikely heroes team up to save the multiverse.','A',NOW()),
('m5','The Wild Robot',8.3,2024,102,'English','["English","Hindi","Tamil","Telugu"]','["Animation","Family"]','Chris Sanders','["Lupita Nyongo","Pedro Pascal"]','./wild_robot_poster.png','./wild_robot_poster.png','Now Showing',200,'["Family","Oscar"]','medium','A robot stranded on a wild island must learn to survive.','U',NOW()),
('m6','Lucky Bhaskar',8.1,2024,152,'Telugu','["Telugu","Tamil","Hindi"]','["Thriller","Drama"]','Venky Atluri','["Dulquer Salmaan","Meenakshi Chaudhary"]','./lucky_bhaskar_poster.png','./lucky_bhaskar_poster.png','Now Showing',240,'["Hit"]','medium','A mild-mannered bank employee accidentally becomes a financial genius.','UA',NOW()),
('m7','Inside Out 2',7.8,2024,100,'English','["English","Hindi","Tamil","Telugu"]','["Animation","Comedy"]','Kelsey Mann','["Amy Poehler","Maya Hawke"]','./inside_out_2_poster.png','./inside_out_2_poster.png','Now Showing',220,'["Pixar","3D"]','low','Riley navigates new emotions as she enters high school.','U',NOW()),
('m8','Vettaiyan',7.2,2024,179,'Tamil','["Tamil","Telugu","Hindi"]','["Action","Drama"]','T.J. Gnanavel','["Rajinikanth","Amitabh Bachchan","Fahadh Faasil"]','./vettaiyan_poster.png','./vettaiyan_poster.png','Now Showing',240,'["Superstar"]','medium','A cop confronts a system that protects criminals.','UA',NOW()),
('m9','Alien: Romulus',7.3,2024,119,'English','["English","Hindi"]','["Horror","Sci-Fi"]','Fede Alvarez','["Cailee Spaeny","David Jonsson"]','./alien_romulus_poster.png','./alien_romulus_poster.png','Now Showing',260,'["Horror","Dolby"]','low','Young colonists face a terrifying encounter with the Alien.','A',NOW()),
('m10','Gladiator II',6.5,2024,148,'English','["English","Hindi","Tamil"]','["Action","Drama"]','Ridley Scott','["Paul Mescal","Denzel Washington","Pedro Pascal"]','./gladiator_2_poster.png','./gladiator_2_poster.png','Now Showing',280,'["Epic","IMAX"]','low','A Roman general fights for freedom in the gladiatorial arena.','UA',NOW()),
('m11','Moana 2',7.0,2024,100,'English','["English","Hindi","Tamil"]','["Animation","Adventure"]','Dave Derrick Jr.','["Auli Cravalho","Dwayne Johnson"]','./moana_2_poster.png','./moana_2_poster.png','Now Showing',220,'["Disney","Family"]','high','Moana takes on a dangerous new mission across the far seas.','U',NOW()),
('m12','Wicked',8.0,2024,160,'English','["English"]','["Fantasy","Musical"]','Jon M. Chu','["Cynthia Erivo","Ariana Grande"]','./wicked_poster.png','./wicked_poster.png','Now Showing',250,'["Musical"]','medium','The untold story of the witches of Oz.','U',NOW()),
('m13','Dune: Part Two',8.6,2024,166,'English','["English","Hindi"]','["Sci-Fi","Adventure"]','Denis Villeneuve','["Timothee Chalamet","Zendaya"]','./dune_part_two_poster.png','./dune_part_two_poster.png','Now Showing',300,'["Epic","IMAX"]','high','Paul Atreides unites with Chani to seek revenge.','UA',NOW()),
('m14','Godzilla x Kong',6.7,2024,115,'English','["English","Hindi","Tamil","Telugu"]','["Action","Sci-Fi"]','Adam Wingard','["Rebecca Hall","Brian Tyree Henry"]','./godzilla_poster.png','./godzilla_poster.png','Now Showing',260,'["Monster","3D"]','high','Godzilla and Kong face a colossal undiscovered threat.','UA',NOW());

-- ─────────────────────────────────────────────────────
--  SEED: SNACKS
-- ─────────────────────────────────────────────────────
INSERT IGNORE INTO snacks VALUES
('sn1','Large Popcorn',220,280,'Popcorn',1,1,'🍿','Buttery salted perfection'),
('sn2','Cheese Nachos',180,220,'Snacks',1,1,'🧀','Crispy nachos with cheese dip'),
('sn3','Cold Drink Combo',160,200,'Drinks',0,1,'🥤','2 chilled beverages'),
('sn4','Crispy Burger',199,249,'Snacks',0,0,'🍔','Juicy crispy burger'),
('sn5','Chocolate Brownie',149,180,'Desserts',1,1,'🍫','Warm fudge brownie'),
('sn6','Popcorn Combo',380,480,'Combo',1,1,'🎉','Popcorn + 2 drinks'),
('sn7','Hot Dog',149,180,'Snacks',0,0,'🌭','Grilled hot dog'),
('sn8','Mineral Water',60,60,'Drinks',0,1,'💧','500ml chilled water');

-- ─────────────────────────────────────────────────────
--  SEED: USERS (passwords are bcrypt hashed)
--  Demo@123  → hash below
--  Admin@123 → hash below
-- ─────────────────────────────────────────────────────
INSERT IGNORE INTO users VALUES
('u1','Aarav Sharma','aarav@example.com','$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','9876543210','user','["English","Hindi"]',NOW()),
('admin','Admin','admin@karaicini.com','$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','9999999999','admin','["English"]',NOW());

-- NOTE: Both users above use bcrypt hash for "password" as placeholder.
-- The server-mysql.js will use bcrypt.hash() for new registrations.
-- For the demo seeds, run this after starting the server, which will 
-- auto-hash and insert proper passwords via the /api/setup endpoint.
