require('dotenv').config();
const express = require('express');
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const cors    = require('cors');
const crypto  = require('crypto');

const app  = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'cineai_dev_secret';

app.use(cors());
app.use(express.json());

// ── IN-MEMORY STORE ──────────────────────────────────────────
let users    = [];
let bookings = [];
let seats    = [];

const movies = [
  { id:1, title:'Kalki 2898-AD', genre:['Action','Sci-Fi'], duration:181, lang:'Telugu', langs:['Telugu','Hindi','Tamil','English'], rating:8.3, year:2024, director:'Nag Ashwin', cast_members:['Prabhas','Deepika Padukone','Amitabh Bachchan'], poster_url:'https://image.tmdb.org/t/p/w500/1hdkbkFCHlB34K8GnAe01vZpBG0.jpg', base_price:260, tags:['Blockbuster','Sci-Fi','Epic'], demand:'high', description:'A mythological sci-fi epic set in a dystopian future.', google_rating:8.3, is_new:1, specs:{hdr:true,dolby:true,imax:true}, certification:'UA' },
  { id:2, title:'Pushpa 2: The Rule', genre:['Action','Drama'], duration:179, lang:'Telugu', langs:['Telugu','Hindi','Tamil'], rating:7.9, year:2024, director:'Sukumar', cast_members:['Allu Arjun','Rashmika Mandanna','Fahadh Faasil'], poster_url:'https://image.tmdb.org/t/p/w500/9FMBuMFJaRMlHMpPq3cTkzxdPiP.jpg', base_price:240, tags:['Blockbuster','Action'], demand:'high', description:'Pushpa Raj expands his red sandalwood empire.', google_rating:7.9, is_new:0, specs:{hdr:true,dolby:false,imax:false}, certification:'UA' },
  { id:3, title:'Mufasa: The Lion King', genre:['Animation','Family'], duration:118, lang:'English', langs:['English','Hindi','Tamil','Telugu'], rating:6.9, year:2024, director:'Barry Jenkins', cast_members:['Aaron Pierre','Kelvin Harrison Jr.'], poster_url:'https://image.tmdb.org/t/p/w500/lurEK87kukWNaHd0zYnsi3yzJrs.jpg', base_price:220, tags:['Family','Animation'], demand:'medium', description:'The origin story of Mufasa, the legendary lion king.', google_rating:6.9, is_new:0, specs:{hdr:true,dolby:false,imax:false}, certification:'U' },
  { id:4, title:'Oppenheimer', genre:['Biography','Drama'], duration:180, lang:'English', langs:['English','Hindi'], rating:8.3, year:2023, director:'Christopher Nolan', cast_members:['Cillian Murphy','Emily Blunt','Robert Downey Jr.'], poster_url:'https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg', base_price:300, tags:['Oscar','Epic','IMAX'], demand:'medium', description:'The story of J. Robert Oppenheimer and the atomic bomb.', google_rating:8.3, is_new:0, specs:{hdr:true,dolby:true,imax:true}, certification:'UA' },
  { id:5, title:'Stree 2', genre:['Horror','Comedy'], duration:135, lang:'Hindi', langs:['Hindi'], rating:8.0, year:2024, director:'Amar Kaushik', cast_members:['Rajkummar Rao','Shraddha Kapoor','Aparshakti Khurana'], poster_url:'https://image.tmdb.org/t/p/w500/38JMpMwHNHsWwGJIUMxbCq8XNwI.jpg', base_price:200, tags:['Horror-Comedy','Hit'], demand:'high', description:'Stree returns to haunt Chanderi once again.', google_rating:8.0, is_new:0, specs:{hdr:false,dolby:false,imax:false}, certification:'UA' },
];

const snacks = [
  { id:1, name:'Large Popcorn', description:'Buttery, salted perfection', price:220, orig_price:280, emoji:'🍿', color:'#f59e0b', category:'Popcorn', is_popular:1, is_veg:1 },
  { id:2, name:'Nachos & Salsa', description:'Crispy nachos with spicy dip', price:180, orig_price:220, emoji:'🌮', color:'#ef4444', category:'Snacks', is_popular:1, is_veg:1 },
  { id:3, name:'Cold Drink Combo', description:'2 medium drinks of your choice', price:160, orig_price:200, emoji:'🥤', color:'#3b82f6', category:'Beverages', is_popular:1, is_veg:1 },
  { id:4, name:'Burger', description:'Crispy chicken/veg burger', price:199, orig_price:249, emoji:'🍔', color:'#10b981', category:'Snacks', is_popular:0, is_veg:0 },
  { id:5, name:'Chocolate Brownie', description:'Warm fudge brownie with ice cream', price:149, orig_price:180, emoji:'🍫', color:'#8b5cf6', category:'Desserts', is_popular:1, is_veg:1 },
];

// ── HELPERS ──────────────────────────────────────────────────
const genId  = () => 'BK' + Math.random().toString(36).substr(2,9).toUpperCase();
const auth   = (req, res, next) => {
  const hdr = req.headers.authorization;
  if (!hdr) return res.status(401).json({ error:'Unauthorised', code:'AUTH_MISSING' });
  try { req.user = jwt.verify(hdr.split(' ')[1], JWT_SECRET); next(); }
  catch(e) { res.status(401).json({ error:'Invalid token', code:'AUTH_INVALID' }); }
};

// ── SHOW GENERATOR (in-memory) ──────────────────────────────
function generateShows(movieId) {
  const movie = movies.find(m => m.id === Number(movieId));
  if (!movie) return [];
  const slots   = [{h:9,m:30},{h:12,m:0},{h:15,m:30},{h:18,m:0},{h:20,m:30},{h:23,m:0}];
  const screens = ['Alpha','Beta','Gamma','Delta'];
  const now     = new Date();
  const result  = [];
  for (let day = 0; day < 7; day++) {
    const date = new Date(now);
    date.setDate(date.getDate() + day);
    const isoDate = date.toISOString().split('T')[0];
    slots.forEach((slot, i) => {
      if (day === 0 && (slot.h*60+slot.m) <= now.getHours()*60+now.getMinutes()+20) return;
      const booked = Math.floor(Math.random()*60);
      const avail  = 96 - booked;
      const isSurge = avail < 15;
      const price   = isSurge ? Math.round(movie.base_price*1.25) : movie.base_price;
      result.push({
        id: `${movieId}-${isoDate}-${slot.h}`,
        movie_id: movie.id,
        screen_id: `scr-${screens[i%4].toLowerCase()}`,
        screen_name: `Screen ${screens[i%4]}`,
        show_date: isoDate,
        show_time: `${String(slot.h).padStart(2,'0')}:${String(slot.m).padStart(2,'0')}:00`,
        show_hour: slot.h,
        language: 'English',
        price,
        is_sold_out: avail === 0,
        is_price_surge: isSurge,
        occupancy_pct: Math.round((booked/96)*100),
        title: movie.title,
        demand: movie.demand,
        genre: movie.genre,
        occupancyStatus: booked/96 >= 0.75 ? 'high' : booked/96 >= 0.5 ? 'medium' : 'low',
      });
    });
  }
  return result;
}

function generateSeats(showId) {
  const rows = 'ABCDEFGH'.split('');
  return rows.flatMap(row =>
    Array.from({length:12},(_,i) => {
      const type  = row <= 'B' ? 'VIP' : row <= 'D' ? 'Premium' : 'Standard';
      const price = type==='VIP' ? 520 : type==='Premium' ? 390 : 260;
      return {
        id: `${showId}-${row}${i+1}`,
        show_id: showId, row_label: row, seat_number: i+1,
        seat_type: type, price,
        status: Math.random() < 0.28 ? 'booked' : 'available',
      };
    })
  );
}

// ── ROOT STATUS PAGE ────────────────────────────────────────
app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html><html lang="en"><head>
  <meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/>
  <title>CineAI API — Status</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700;800&display=swap" rel="stylesheet"/>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:'Inter',sans-serif;background:#0a0a0f;color:#e2e8f0;min-height:100vh}
    .bg{position:fixed;inset:0;background:radial-gradient(ellipse 80% 60% at 50% -10%,rgba(120,60,255,.25),transparent),radial-gradient(ellipse 60% 50% at 80% 80%,rgba(255,60,120,.15),transparent);z-index:0}
    .wrap{position:relative;z-index:1;max-width:900px;margin:0 auto;padding:48px 24px}
    h1{font-size:2.5rem;font-weight:800;background:linear-gradient(90deg,#a78bfa,#f472b6);-webkit-background-clip:text;-webkit-text-fill-color:transparent;text-align:center;margin-bottom:8px}
    .sub{text-align:center;color:#64748b;margin-bottom:8px}
    .badge{display:inline-flex;align-items:center;gap:8px;background:rgba(34,197,94,.1);border:1px solid rgba(34,197,94,.3);color:#4ade80;padding:6px 16px;border-radius:999px;font-size:.85rem;font-weight:600;margin:12px auto 40px;display:flex;justify-content:center;width:fit-content;margin-left:auto;margin-right:auto}
    .dot{width:8px;height:8px;border-radius:50%;background:#4ade80;animation:pulse 1.5s ease-in-out infinite}
    @keyframes pulse{50%{opacity:.4;transform:scale(1.4)}}
    .grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:36px}
    .card{background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);border-radius:14px;padding:18px;text-align:center}
    .cv{font-size:1.8rem;font-weight:700;background:linear-gradient(135deg,#a78bfa,#f472b6);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .cl{font-size:.75rem;color:#64748b;text-transform:uppercase;letter-spacing:.06em;margin-top:4px}
    .sec{font-size:.85rem;font-weight:700;color:#a78bfa;text-transform:uppercase;letter-spacing:.08em;margin:28px 0 12px;display:flex;align-items:center;gap:8px}
    .sec::after{content:'';flex:1;height:1px;background:rgba(167,139,250,.2)}
    .eps{display:flex;flex-direction:column;gap:8px;margin-bottom:8px}
    .ep{display:flex;align-items:center;gap:12px;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.06);border-radius:10px;padding:12px 16px;text-decoration:none;color:inherit;transition:all .2s}
    .ep:hover{background:rgba(124,58,237,.1);border-color:rgba(124,58,237,.4);transform:translateX(4px)}
    .m{font-size:.7rem;font-weight:700;padding:3px 9px;border-radius:6px;min-width:50px;text-align:center}
    .GET{background:rgba(34,197,94,.15);color:#4ade80;border:1px solid rgba(34,197,94,.3)}
    .POST{background:rgba(59,130,246,.15);color:#60a5fa;border:1px solid rgba(59,130,246,.3)}
    .PATCH{background:rgba(251,191,36,.15);color:#fbbf24;border:1px solid rgba(251,191,36,.3)}
    .path{font-family:monospace;font-size:.82rem;flex:1}
    .desc{font-size:.75rem;color:#64748b}
    .tag{font-size:.7rem;background:rgba(244,114,182,.1);color:#f472b6;border:1px solid rgba(244,114,182,.2);border-radius:4px;padding:2px 7px}
    .warn{background:rgba(251,191,36,.08);border:1px solid rgba(251,191,36,.2);border-radius:12px;padding:16px 20px;margin:24px 0;font-size:.85rem;color:#fbbf24}
    footer{text-align:center;color:#334155;font-size:.78rem;margin-top:40px;padding-top:20px;border-top:1px solid rgba(255,255,255,.05)}
  </style></head><body>
  <div class="bg"></div>
  <div class="wrap">
    <h1>🎬 CineAI API</h1>
    <p class="sub">Express Backend · Port ${PORT} · In-Memory Demo Mode</p>
    <div class="badge"><span class="dot"></span>Server Running — No DB Required</div>
    <div class="grid">
      <div class="card"><div class="cv">${movies.length}</div><div class="cl">Movies</div></div>
      <div class="card"><div class="cv">${snacks.length}</div><div class="cl">Snacks</div></div>
      <div class="card"><div class="cv">JWT</div><div class="cl">Auth</div></div>
      <div class="card"><div class="cv">7d</div><div class="cl">Token TTL</div></div>
    </div>
    <div class="warn">⚠️ Running in <strong>demo mode</strong> with in-memory data. Connect MySQL to enable full persistence.</div>
    <div class="sec">🔐 Auth</div>
    <div class="eps">
      <div class="ep"><span class="m POST">POST</span><span class="path">/api/auth/register</span><span class="desc">Register user</span></div>
      <div class="ep"><span class="m POST">POST</span><span class="path">/api/auth/login</span><span class="desc">Login → JWT token</span></div>
      <a class="ep" href="/api/auth/verify" target="_blank"><span class="m GET">GET</span><span class="path">/api/auth/verify</span><span class="desc">Verify token</span><span class="tag">🔒 Auth</span></a>
    </div>
    <div class="sec">🎥 Movies</div>
    <div class="eps">
      <a class="ep" href="/api/movies" target="_blank"><span class="m GET">GET</span><span class="path">/api/movies</span><span class="desc">All movies</span></a>
      <a class="ep" href="/api/movies/1" target="_blank"><span class="m GET">GET</span><span class="path">/api/movies/:id</span><span class="desc">Movie by ID</span></a>
    </div>
    <div class="sec">🎞️ Shows & Snacks</div>
    <div class="eps">
      <a class="ep" href="/api/shows?movieId=1" target="_blank"><span class="m GET">GET</span><span class="path">/api/shows?movieId=1</span><span class="desc">Shows for movie (auto-generated)</span></a>
      <a class="ep" href="/api/snacks" target="_blank"><span class="m GET">GET</span><span class="path">/api/snacks</span><span class="desc">All snacks</span></a>
      <a class="ep" href="/api/seats?showId=1-${new Date().toISOString().split('T')[0]}-20" target="_blank"><span class="m GET">GET</span><span class="path">/api/seats?showId=...</span><span class="desc">Seat layout for show</span></a>
    </div>
    <div class="sec">🎟️ Bookings</div>
    <div class="eps">
      <div class="ep"><span class="m POST">POST</span><span class="path">/api/bookings</span><span class="desc">Create booking</span><span class="tag">🔒 Auth</span></div>
      <div class="ep"><span class="m GET">GET</span><span class="path">/api/bookings</span><span class="desc">My bookings</span><span class="tag">🔒 Auth</span></div>
      <div class="ep"><span class="m PATCH">PATCH</span><span class="path">/api/bookings/:id/cancel</span><span class="desc">Cancel booking</span><span class="tag">🔒 Auth</span></div>
    </div>
    <div class="sec">⚙️ Admin</div>
    <div class="eps">
      <a class="ep" href="/api/admin/dashboard" target="_blank"><span class="m GET">GET</span><span class="path">/api/admin/dashboard</span><span class="desc">Dashboard stats</span><span class="tag">🔒 Admin</span></a>
    </div>
    <footer>CineAI Demo Backend v1.0 · Node ${process.version} · Started ${new Date().toLocaleString('en-IN',{timeZone:'Asia/Kolkata'})}</footer>
  </div></body></html>`);
});

// ── AUTH ─────────────────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password) return res.status(400).json({ error:'Missing fields', code:'MISSING_FIELDS' });
  if (password.length < 8) return res.status(400).json({ error:'Password min 8 chars', code:'WEAK_PASSWORD' });
  if (users.find(u => u.email === email)) return res.status(409).json({ error:'Email exists', code:'EMAIL_EXISTS' });
  const hash = await bcrypt.hash(password, 10);
  const user = { id: users.length+1, name, email, password:hash, phone:phone||null, role:'user', pref_langs:['English'] };
  users.push(user);
  const token = jwt.sign({ id:user.id, role:user.role, email:user.email }, JWT_SECRET, { expiresIn:'7d' });
  const { password:_, ...safe } = user;
  res.status(201).json({ success:true, token, user:safe });
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error:'Email and password required' });
  const user = users.find(u => u.email === email);
  if (!user || !(await bcrypt.compare(password, user.password)))
    return res.status(401).json({ error:'Invalid credentials', code:'INVALID_CREDENTIALS' });
  const token = jwt.sign({ id:user.id, role:user.role, email:user.email }, JWT_SECRET, { expiresIn:'7d' });
  const { password:_, ...safe } = user;
  res.json({ success:true, token, user:safe });
});

app.get('/api/auth/verify', auth, (req, res) => res.json({ valid:true, user:req.user }));

// ── MOVIES ───────────────────────────────────────────────────
app.get('/api/movies', (req, res) => res.json(movies));
app.get('/api/movies/:id', (req, res) => {
  const m = movies.find(m => m.id === Number(req.params.id));
  if (!m) return res.status(404).json({ error:'Not found' });
  res.json(m);
});

// ── SHOWS ────────────────────────────────────────────────────
app.get('/api/shows', (req, res) => {
  const { movieId, date } = req.query;
  if (!movieId) return res.status(400).json({ error:'movieId required' });
  let shows = generateShows(movieId);
  if (date) shows = shows.filter(s => s.show_date === date);
  res.json(shows);
});

// ── SEATS ────────────────────────────────────────────────────
app.get('/api/seats', (req, res) => {
  const { showId } = req.query;
  if (!showId) return res.status(400).json({ error:'showId required' });
  const cached = seats.filter(s => s.show_id === showId);
  if (cached.length) return res.json(cached);
  const fresh = generateSeats(showId);
  seats.push(...fresh);
  res.json(fresh);
});

// ── SNACKS ───────────────────────────────────────────────────
app.get('/api/snacks', (req, res) => res.json(snacks));

// ── BOOKINGS ─────────────────────────────────────────────────
app.post('/api/bookings', auth, async (req, res) => {
  const { showId, seatIds, snackItems, phone, paymentMethod, voucherCode } = req.body;
  if (!showId || !seatIds?.length) return res.status(400).json({ error:'Show and seats required' });
  const showSeats = seats.filter(s => s.show_id === showId);
  const chosenSeats = showSeats.filter(s => seatIds.includes(s.id) && s.status === 'available');
  if (chosenSeats.length !== seatIds.length) return res.status(400).json({ error:'Some seats unavailable' });
  chosenSeats.forEach(s => { s.status = 'booked'; });
  const seatTotal = chosenSeats.reduce((t,s) => t+s.price, 0);
  let snackTotal  = 0;
  const snackLines = [];
  if (snackItems?.length) {
    for (const item of snackItems) {
      const sn = snacks.find(s => s.id === item.snackId);
      if (sn) { snackTotal += sn.price*item.qty; snackLines.push({...sn, qty:item.qty}); }
    }
  }
  const grandTotal = seatTotal + snackTotal;
  const bk = {
    id: genId(), user_id: req.user.id, show_id: showId, phone, payment_method: paymentMethod,
    seat_total: seatTotal, snack_total: snackTotal, voucher_discount: 0, grand_total: grandTotal,
    qr_code: 'QR-'+Math.random().toString(36).substr(2,9).toUpperCase(),
    status:'confirmed', created_at: new Date().toISOString(),
    seats: chosenSeats.map(s=>`${s.row_label}${s.seat_number}`),
    snacks: snackLines,
  };
  bookings.push(bk);
  res.status(201).json({ success:true, ...bk });
});

app.get('/api/bookings', auth, (req, res) => {
  const myBookings = bookings.filter(b => b.user_id === req.user.id);
  res.json(myBookings);
});

app.patch('/api/bookings/:id/cancel', auth, (req, res) => {
  const bk = bookings.find(b => b.id === req.params.id && b.user_id === req.user.id);
  if (!bk) return res.status(404).json({ error:'Not found' });
  if (bk.status !== 'confirmed') return res.status(400).json({ error:'Already cancelled' });
  bk.status = 'cancelled';
  res.json({ success:true, message:'Cancelled. Refund in 3-5 days.' });
});

// ── PAYMENTS ─────────────────────────────────────────────────
app.post('/api/payments/initiate', auth, (req, res) => {
  const { bookingId, amount, method } = req.body;
  if (!bookingId || !amount || !method) return res.status(400).json({ error:'Missing fields' });
  res.json({ success:true, transactionId:'TXN'+Date.now(), amount, method, timestamp:new Date().toISOString() });
});

app.post('/api/payments/verify', auth, (req, res) => {
  const { transactionId } = req.body;
  if (!transactionId) return res.status(400).json({ error:'Missing transactionId' });
  res.json({ success:true, transactionId, status:'verified' });
});

// ── ADMIN ────────────────────────────────────────────────────
app.get('/api/admin/dashboard', auth, (req, res) => {
  const confirmed = bookings.filter(b => b.status==='confirmed');
  res.json({
    totalBookings: confirmed.length,
    revenue: confirmed.reduce((t,b) => t+b.grand_total, 0),
    activeMovies: movies.length,
    totalUsers: users.length,
    todayRevenue: confirmed.filter(b => b.created_at?.startsWith(new Date().toISOString().split('T')[0])).reduce((t,b)=>t+b.grand_total,0),
    lastUpdated: new Date().toISOString()
  });
});

app.get('/api/admin/bookings', auth, (req, res) => res.json(bookings));

// ── START ────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`🎬 CineAI Demo API → http://localhost:${PORT}`);
  console.log(`📋 Mode: In-Memory Demo (no MySQL needed)`);
  console.log(`🎥 Movies: ${movies.length} | 🍿 Snacks: ${snacks.length}`);
});
