require('dotenv').config();
const express  = require('express');
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const cors     = require('cors');
const mysql    = require('mysql2/promise');

const app  = express();
const PORT = process.env.PORT || 4000;
const JWT_SECRET = process.env.JWT_SECRET || 'cineai_dev_secret';

app.use(cors());
app.use(express.json());

// ── MySQL Connection Pool ─────────────────────────────────────
const pool = mysql.createPool({
  host:     process.env.DB_HOST     || 'localhost',
  port:     parseInt(process.env.DB_PORT || '3306'),
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASS     || '',
  database: process.env.DB_NAME     || 'cineai',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
});

// Helper: run a query
const db = async (sql, params = []) => {
  const [rows] = await pool.execute(sql, params);
  return rows;
};

// ── AUTH MIDDLEWARE ───────────────────────────────────────────
const auth = (req, res, next) => {
  const hdr = req.headers.authorization;
  if (!hdr) return res.status(401).json({ error: 'Unauthorised' });
  try {
    req.user = jwt.verify(hdr.split(' ')[1], JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

const adminOnly = (req, res, next) => {
  if (req.user?.role !== 'admin')
    return res.status(403).json({ error: 'Admin only' });
  next();
};

// ── HELPERS ───────────────────────────────────────────────────
const genBookingId = () =>
  'BK' + Date.now().toString().slice(-7) + Math.random().toString(36).slice(2, 5).toUpperCase();

// Generate shows for the next 7 days for a given movie (not stored in DB)
function generateShows(movie) {
  const slots = [
    { t: '9:30 AM',  h: 9  },
    { t: '12:00 PM', h: 12 },
    { t: '2:45 PM',  h: 14 },
    { t: '5:30 PM',  h: 17 },
    { t: '8:00 PM',  h: 20 },
    { t: '10:30 PM', h: 22 },
  ];
  const screens = ['Screen Alpha', 'Screen Beta', 'Screen Gamma', 'Screen Delta', 'Screen Epsilon'];
  const now = new Date();
  const shows = [];

  for (let day = 0; day < 7; day++) {
    const d = new Date(now);
    d.setDate(d.getDate() + day);
    const iso = d.toISOString().split('T')[0];

    slots.forEach((slot, i) => {
      if (day === 0 && slot.h <= now.getHours()) return;
      const booked = Math.floor(Math.random() * 60);
      const avail  = 96 - booked;
      const isWeekend    = d.getDay() === 0 || d.getDay() === 6;
      const isBlockbuster = movie.demand === 'high';

      let surgeMulti = 1.0;
      let surgeReason = null;

      if (isBlockbuster && isWeekend) { surgeMulti = 1.3; surgeReason = 'AI Predicts: Weekend Blockbuster Crowd'; }
      else if (isWeekend)             { surgeMulti = 1.15; surgeReason = 'AI Predicts: High Weekend Demand'; }
      else if (isBlockbuster)         { surgeMulti = 1.1;  surgeReason = 'AI Predicts: Blockbuster Trend'; }
      else if (avail < 15)            { surgeMulti = 1.2;  surgeReason = 'AI Predicts: Seats Filling Fast'; }

      const price = Math.round(movie.base_price * surgeMulti);

      shows.push({
        id:          `${movie.id}-${iso}-${slot.h}`,
        movieId:     movie.id,
        screen:      screens[i % 3],
        showDate:    iso,
        showTime:    slot.t,
        showHour:    slot.h,
        price,
        avail,
        booked,
        total:       96,
        surge:       !!surgeReason,
        surgeReason,
        surgeMulti,
        occPct:      Math.round((booked / 96) * 100),
        lang:        movie.lang,
      });
    });
  }
  return shows;
}

// Generate seats for a show (stored in DB on first call)
function buildSeats(showId, movie, showDate) {
  const d = new Date(showDate);
  const isWeekend    = d.getDay() === 0 || d.getDay() === 6;
  const isBlockbuster = movie.demand === 'high';

  let demandMulti = 1.0;
  if (isBlockbuster && isWeekend)   demandMulti = 1.3;
  else if (isWeekend)               demandMulti = 1.15;
  else if (isBlockbuster)           demandMulti = 1.1;
  else if (movie.demand === 'low')  demandMulti = 0.8;

  const rows = 'ABCDEFGH'.split('');
  return rows.flatMap(row =>
    Array.from({ length: 12 }, (_, i) => {
      let type, basePrice;
      if (row === 'H' || row === 'G')         { type = 'Recliner'; basePrice = 600; }
      else if (row === 'F' || row === 'E' || row === 'D') { type = 'Gold'; basePrice = 300; }
      else                                    { type = 'Silver';   basePrice = 200; }

      return {
        id:         `${showId}-${row}${i + 1}`,
        show_id:    showId,
        row_label:  row,
        seat_number: i + 1,
        seat_type:  type,
        price:      Math.round(basePrice * demandMulti),
        status:     Math.random() < 0.28 ? 'booked' : 'available',
      };
    })
  );
}

// ── DB HEALTH CHECK ──────────────────────────────────────────
app.get('/api/health', async (req, res) => {
  try {
    await db('SELECT 1');
    res.json({ status: 'ok', db: 'MySQL connected', time: new Date().toISOString() });
  } catch (e) {
    res.status(503).json({ status: 'error', db: e.message });
  }
});

// ── SETUP: seed default users ─────────────────────────────────
// POST /api/setup  →  creates default admin + demo user if not exist
app.post('/api/setup', async (req, res) => {
  try {
    const demoHash  = await bcrypt.hash('Demo@123',  10);
    const adminHash = await bcrypt.hash('Admin@123', 10);

    await db(`INSERT IGNORE INTO users (id, name, email, password, phone, role, pref_langs)
              VALUES (?, ?, ?, ?, ?, ?, ?)`,
      ['u1', 'Aarav Sharma', 'aarav@example.com', demoHash, '9876543210', 'user', JSON.stringify(['English','Hindi'])]);

    await db(`INSERT IGNORE INTO users (id, name, email, password, phone, role, pref_langs)
              VALUES (?, ?, ?, ?, ?, ?, ?)`,
      ['admin', 'Admin', 'admin@karaicini.com', adminHash, '9999999999', 'admin', JSON.stringify(['English'])]);

    res.json({ success: true, message: 'Default users seeded (aarav@example.com / Demo@123 and admin@karaicini.com / Admin@123)' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── AUTH ─────────────────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password, phone } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'Name, email and password are required' });
  if (password.length < 6)
    return res.status(400).json({ error: 'Password must be at least 6 characters' });

  try {
    const existing = await db('SELECT id FROM users WHERE email = ?', [email]);
    if (existing.length) return res.status(409).json({ error: 'Email already registered' });

    const hash = await bcrypt.hash(password, 10);
    const id   = 'u' + Date.now();
    await db(
      'INSERT INTO users (id, name, email, password, phone, role, pref_langs) VALUES (?,?,?,?,?,?,?)',
      [id, name, email, hash, phone || null, 'user', JSON.stringify(['English'])]
    );

    const user  = { id, name, email, phone, role: 'user', pref_langs: ['English'] };
    const token = jwt.sign({ id, role: 'user', email }, JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ success: true, token, user });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: 'Email and password required' });

  try {
    const rows = await db('SELECT * FROM users WHERE email = ?', [email]);
    const user = rows[0];
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ error: 'Invalid email or password' });

    const token = jwt.sign({ id: user.id, role: user.role, email: user.email }, JWT_SECRET, { expiresIn: '7d' });
    const { password: _, ...safe } = user;
    // Parse JSON fields
    if (typeof safe.pref_langs === 'string') safe.pref_langs = JSON.parse(safe.pref_langs);
    res.json({ success: true, token, user: safe });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/auth/verify', auth, (req, res) =>
  res.json({ valid: true, user: req.user })
);

// ── MOVIES ───────────────────────────────────────────────────
app.get('/api/movies', async (req, res) => {
  try {
    const rows = await db('SELECT * FROM movies ORDER BY demand DESC, rating DESC');
    const movies = rows.map(m => ({
      ...m,
      genre:       typeof m.genre       === 'string' ? JSON.parse(m.genre)       : m.genre,
      langs:       typeof m.langs       === 'string' ? JSON.parse(m.langs)       : m.langs,
      tags:        typeof m.tags        === 'string' ? JSON.parse(m.tags)        : m.tags,
      cast_members: typeof m.cast_members === 'string' ? JSON.parse(m.cast_members) : m.cast_members,
    }));
    res.json(movies);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/movies/:id', async (req, res) => {
  try {
    const rows = await db('SELECT * FROM movies WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Movie not found' });
    const m = rows[0];
    m.genre        = typeof m.genre        === 'string' ? JSON.parse(m.genre)        : m.genre;
    m.langs        = typeof m.langs        === 'string' ? JSON.parse(m.langs)        : m.langs;
    m.tags         = typeof m.tags         === 'string' ? JSON.parse(m.tags)         : m.tags;
    m.cast_members = typeof m.cast_members === 'string' ? JSON.parse(m.cast_members) : m.cast_members;
    res.json(m);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── SHOWS ────────────────────────────────────────────────────
app.get('/api/shows', async (req, res) => {
  const { movieId, date } = req.query;
  if (!movieId) return res.status(400).json({ error: 'movieId required' });

  try {
    const rows = await db('SELECT * FROM movies WHERE id = ?', [movieId]);
    if (!rows.length) return res.status(404).json({ error: 'Movie not found' });
    const movie = rows[0];
    movie.demand = movie.demand || 'medium';

    let shows = generateShows(movie);
    if (date) shows = shows.filter(s => s.showDate === date);
    res.json(shows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── SEATS ─────────────────────────────────────────────────────
app.get('/api/seats', async (req, res) => {
  const { showId } = req.query;
  if (!showId) return res.status(400).json({ error: 'showId required' });

  try {
    // Return from DB if already generated
    const cached = await db('SELECT * FROM seats WHERE show_id = ?', [showId]);
    if (cached.length) return res.json(cached);

    // Parse showId to find the movie
    const parts   = showId.split('-');
    const movieId = parts[0];
    const showDate = `${parts[1]}-${parts[2]}-${parts[3]}`;

    const movieRows = await db('SELECT * FROM movies WHERE id = ?', [movieId]);
    if (!movieRows.length) return res.status(404).json({ error: 'Movie not found for showId' });
    const movie = movieRows[0];

    // Check or create the show in DB
    const showRows = await db('SELECT id FROM shows WHERE id = ?', [showId]);
    if (!showRows.length) {
      await db(
        'INSERT IGNORE INTO shows (id, movie_id, screen, show_date, show_time, show_hour, lang, price) VALUES (?,?,?,?,?,?,?,?)',
        [showId, movieId, 'Screen Alpha', showDate, '8:00 PM', 20, movie.lang, movie.base_price]
      );
    }

    // Generate + save seats
    const seats = buildSeats(showId, movie, showDate);
    for (const s of seats) {
      await db(
        'INSERT IGNORE INTO seats (id, show_id, row_label, seat_number, seat_type, price, status) VALUES (?,?,?,?,?,?,?)',
        [s.id, s.show_id, s.row_label, s.seat_number, s.seat_type, s.price, s.status]
      );
    }

    const fresh = await db('SELECT * FROM seats WHERE show_id = ?', [showId]);
    res.json(fresh);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── SNACKS ────────────────────────────────────────────────────
app.get('/api/snacks', async (req, res) => {
  try {
    res.json(await db('SELECT * FROM snacks'));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── BOOKINGS ─────────────────────────────────────────────────
app.post('/api/bookings', auth, async (req, res) => {
  const { showId, seatIds, snackItems, paymentMethod, voucherCode, parking } = req.body;
  if (!showId || !seatIds?.length)
    return res.status(400).json({ error: 'showId and seatIds are required' });

  try {
    // Validate seats are available
    const placeholders = seatIds.map(() => '?').join(',');
    const seatRows = await db(
      `SELECT * FROM seats WHERE id IN (${placeholders}) AND show_id = ?`,
      [...seatIds, showId]
    );

    const unavailable = seatRows.filter(s => s.status !== 'available');
    if (unavailable.length)
      return res.status(400).json({ error: 'Some seats are already booked', seats: unavailable.map(s => s.id) });
    if (seatRows.length !== seatIds.length)
      return res.status(400).json({ error: 'One or more seat IDs not found' });

    // Mark seats as booked
    await db(
      `UPDATE seats SET status = 'booked' WHERE id IN (${placeholders})`,
      seatIds
    );

    // Calculate totals
    const seatTotal = seatRows.reduce((t, s) => t + s.price, 0);
    let snackTotal  = 0;
    const snackLines = [];

    if (snackItems?.length) {
      for (const item of snackItems) {
        const snack = await db('SELECT * FROM snacks WHERE id = ?', [item.id || item.snackId]);
        if (snack[0]) {
          snackTotal += snack[0].price * item.qty;
          snackLines.push({ ...snack[0], qty: item.qty });
        }
      }
    }

    // Apply ₹50 combo discount if 2+ snack items
    const totalSnackItems = snackLines.reduce((s, i) => s + i.qty, 0);
    const snackDiscount   = totalSnackItems >= 2 ? 50 : 0;
    snackTotal = Math.max(0, snackTotal - snackDiscount);

    const parkingFee = parking ? 100 : 0;
    const grandTotal = seatTotal + snackTotal + parkingFee;

    const bookingId = genBookingId();
    const qrCode    = 'QR-' + bookingId;

    const seatLabels = seatRows.map(s => `${s.row_label}${s.seat_number}`);

    await db(
      `INSERT INTO bookings
       (id, user_id, show_id, seats, snacks, seat_total, snack_total, discount, parking_fee, grand_total, voucher_code, parking, payment_method, status, qr_code)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
      [
        bookingId, req.user.id, showId,
        JSON.stringify(seatLabels),
        JSON.stringify(snackLines),
        seatTotal, snackTotal, snackDiscount, parkingFee, grandTotal,
        voucherCode || null, parking ? 1 : 0,
        paymentMethod || 'UPI',
        'confirmed', qrCode
      ]
    );

    // Update show booked_seats count
    await db('UPDATE shows SET booked_seats = booked_seats + ? WHERE id = ?', [seatIds.length, showId]);

    res.status(201).json({
      success: true,
      bookingId, qrCode, seatTotal, snackTotal,
      discount: snackDiscount, parkingFee, grandTotal,
      seats: seatLabels, snacks: snackLines, status: 'confirmed',
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/bookings', auth, async (req, res) => {
  try {
    const rows = await db(
      `SELECT b.*, m.title AS movie_title, m.poster, sh.show_date, sh.show_time, sh.screen, sh.lang
       FROM bookings b
       LEFT JOIN shows sh ON sh.id = b.show_id
       LEFT JOIN movies m ON m.id = sh.movie_id
       WHERE b.user_id = ?
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    const bookings = rows.map(b => ({
      ...b,
      seats:  typeof b.seats  === 'string' ? JSON.parse(b.seats)  : b.seats,
      snacks: typeof b.snacks === 'string' ? JSON.parse(b.snacks) : b.snacks,
    }));
    res.json(bookings);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.patch('/api/bookings/:id/cancel', auth, async (req, res) => {
  try {
    const rows = await db('SELECT * FROM bookings WHERE id = ? AND user_id = ?', [req.params.id, req.user.id]);
    if (!rows.length) return res.status(404).json({ error: 'Booking not found' });
    const bk = rows[0];
    if (bk.status !== 'confirmed') return res.status(400).json({ error: 'Booking already cancelled' });

    await db("UPDATE bookings SET status = 'cancelled' WHERE id = ?", [req.params.id]);

    // Free up seats
    const seatLabels = typeof bk.seats === 'string' ? JSON.parse(bk.seats) : bk.seats;
    for (const label of seatLabels) {
      const row    = label[0];
      const number = parseInt(label.slice(1));
      await db(
        "UPDATE seats SET status = 'available' WHERE show_id = ? AND row_label = ? AND seat_number = ?",
        [bk.show_id, row, number]
      );
    }

    res.json({ success: true, message: 'Booking cancelled. Refund in 3-5 working days.' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── ADMIN ─────────────────────────────────────────────────────
app.get('/api/admin/dashboard', auth, adminOnly, async (req, res) => {
  try {
    const [stats]    = await db(`SELECT COUNT(*) AS totalBookings, SUM(grand_total) AS totalRevenue FROM bookings WHERE status='confirmed'`);
    const [today]    = await db(`SELECT SUM(grand_total) AS todayRevenue FROM bookings WHERE status='confirmed' AND DATE(created_at) = CURDATE()`);
    const [movCount] = await db('SELECT COUNT(*) AS count FROM movies');
    const [usrCount] = await db('SELECT COUNT(*) AS count FROM users');

    res.json({
      totalBookings: stats.totalBookings || 0,
      totalRevenue:  stats.totalRevenue  || 0,
      todayRevenue:  today.todayRevenue  || 0,
      totalMovies:   movCount.count,
      totalUsers:    usrCount.count,
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/admin/bookings', auth, adminOnly, async (req, res) => {
  try {
    const rows = await db(
      `SELECT b.*, m.title AS movie_title, sh.show_date, sh.show_time,
              u.name AS user_name, u.email AS user_email
       FROM bookings b
       LEFT JOIN shows sh ON sh.id = b.show_id
       LEFT JOIN movies m ON m.id  = sh.movie_id
       LEFT JOIN users  u ON u.id  = b.user_id
       ORDER BY b.created_at DESC`
    );
    res.json(rows.map(b => ({
      ...b,
      seats:  typeof b.seats  === 'string' ? JSON.parse(b.seats)  : b.seats,
      snacks: typeof b.snacks === 'string' ? JSON.parse(b.snacks) : b.snacks,
    })));
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/api/admin/users', auth, adminOnly, async (req, res) => {
  try {
    const rows = await db('SELECT id, name, email, phone, role, created_at FROM users ORDER BY created_at DESC');
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ── STATUS PAGE ───────────────────────────────────────────────
app.get('/', (req, res) => {
  res.send(`<!DOCTYPE html>
<html lang="en"><head><meta charset="UTF-8"/>
<title>KaraiCini API — MySQL Mode</title>
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  body{font-family:system-ui,sans-serif;background:#0a0a0f;color:#e2e8f0;min-height:100vh;display:flex;align-items:center;justify-content:center}
  .box{text-align:center;padding:40px}
  h1{font-size:2rem;font-weight:800;background:linear-gradient(90deg,#f43f5e,#fb923c);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:8px}
  .tag{background:rgba(34,197,94,.15);border:1px solid rgba(34,197,94,.4);color:#4ade80;padding:6px 18px;border-radius:999px;display:inline-block;margin:12px 0 24px;font-size:.85rem}
  a{color:#f43f5e}
</style></head>
<body><div class="box">
  <h1>🎬 KaraiCini Movies API</h1>
  <div class="tag">✅ MySQL Mode · Port ${PORT}</div>
  <p style="color:#64748b;font-size:.9rem">See <a href="/api/health">/api/health</a> to verify DB connection<br/>
  GET <a href="/api/movies">/api/movies</a> · GET <a href="/api/snacks">/api/snacks</a></p>
</div></body></html>`);
});

// ── START ─────────────────────────────────────────────────────
app.listen(PORT, async () => {
  console.log(`\n🎬 KaraiCini Movies API → http://localhost:${PORT}`);
  console.log(`📦 Mode: MySQL (${process.env.DB_HOST}:${process.env.DB_PORT || 3306} / ${process.env.DB_NAME})`);
  try {
    await db('SELECT 1');
    console.log(`✅ MySQL connected successfully!\n`);
  } catch (e) {
    console.error(`❌ MySQL connection failed: ${e.message}`);
    console.error(`   Check your .env file: DB_HOST, DB_USER, DB_PASS, DB_NAME\n`);
  }
});
