const http = require('http');
const fs   = require('fs');
const path = require('path');

const PORT    = 8080;
const BASEDIR = __dirname; // Always serves from THIS file's folder

const MIME = {
  '.html': 'text/html',
  '.js':   'text/javascript',
  '.css':  'text/css',
  '.png':  'image/png',
  '.jpg':  'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif':  'image/gif',
  '.svg':  'image/svg+xml',
  '.ico':  'image/x-icon',
  '.json': 'application/json',
};

const server = http.createServer((req, res) => {
  let urlPath = req.url.split('?')[0]; // strip query strings
  if (urlPath === '/') urlPath = '/index.html';

  const filePath    = path.join(BASEDIR, urlPath);
  const extname     = path.extname(filePath).toLowerCase();
  const contentType = MIME[extname] || 'application/octet-stream';

  fs.readFile(filePath, (err, content) => {
    if (err) {
      if (err.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/plain' });
        res.end(`404 Not Found: ${urlPath}`);
      } else {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end(`Server Error: ${err.code}`);
      }
    } else {
      res.writeHead(200, {
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': '*',
      });
      res.end(content);
    }
  });
});

server.listen(PORT, () => {
  console.log(`✅ KaraiCini Frontend → http://localhost:${PORT}`);
  console.log(`📂 Serving files from: ${BASEDIR}`);
});
