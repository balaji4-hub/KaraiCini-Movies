# 🎬 KaraiCini Movies — AI-Powered Cinema Booking App (MySQL Edition)

A full-featured cinema ticket booking web app with MySQL database, AI seat recommendations, mood-based movie search, voice booking, dynamic pricing, and more.

---

## ⚙️ Prerequisites

| Tool | Download |
|------|----------|
| **Node.js** | https://nodejs.org (v18 or later) |
| **MySQL** | https://dev.mysql.com/downloads/mysql/ OR XAMPP/WAMP |

---

## 🚀 Setup (Step by Step)

### Step 1 — Install Node dependencies
```bash
npm install
```

### Step 2 — Configure your MySQL details in `.env`
Open the `.env` file and set:
```
DB_HOST=localhost
DB_USER=root
DB_PASS=your_mysql_password    ← change this
DB_NAME=cineai
DB_PORT=3306
```

### Step 3 — Create the Database & Tables
Open **MySQL Workbench**, **phpMyAdmin**, or the MySQL CLI and run:
```bash
mysql -u root -p < database.sql
```
This will:
- Create the `cineai` database
- Create all tables (movies, snacks, users, shows, seats, bookings)
- Insert 14 movies and 8 snacks as seed data

### Step 4 — Seed the default users (admin & demo)
After starting the server (Step 5), open your browser and visit:
```
http://localhost:4000/api/setup
```
> Or use curl: `curl -X POST http://localhost:4000/api/setup`

This creates the default login accounts with proper password hashing.

### Step 5 — Start the API server
```bash
node server-mysql.js
```
→ Runs at `http://localhost:4000`

### Step 6 — Start the frontend server (new terminal)
```bash
node static-server.js
```
→ Runs at `http://localhost:8080`

### Step 7 — Open in Chrome
```
http://localhost:8080
```

---

## 🔑 Default Login Credentials

| Role  | Email                 | Password   |
|-------|-----------------------|------------|
| User  | aarav@example.com     | Demo@123   |
| Admin | admin@karaicini.com   | Admin@123  |

---

## 📁 File Structure

```
KaraiCini-Movies/
├── index.html          ← Frontend entry point
├── app-data.js         ← Frontend data layer (movies list, UI helpers)
├── app-part1.js        ← React: Navbar, Home, Movies, AI Widgets
├── app-part2.js        ← React: Booking Flow, Dashboard, Admin Panel
├── static-server.js    ← Serves frontend on port 8080
├── server-mysql.js     ← ✅ MySQL Express API (port 4000)  ← USE THIS
├── server-demo.js      ← In-memory demo (no DB, for testing only)
├── database.sql        ← MySQL schema + seed data  ← RUN FIRST
├── .env                ← MySQL connection settings
├── package.json        ← Node dependencies
├── *.png               ← Movie poster images
└── README.md           ← This file
```

---

## 🗃️ Database Schema

| Table     | Description |
|-----------|-------------|
| `movies`  | 14 movies with genre, cast, pricing, demand |
| `snacks`  | 8 snack/drink items |
| `users`   | Registered users + admin |
| `shows`   | Show schedules (auto-generated per movie) |
| `seats`   | Seat layout with pricing (stored after first visit) |
| `bookings`| All ticket bookings with seat/snack/payment info |

---

## 🌐 API Endpoints

| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET  | `/api/health` | ❌ | Check MySQL connection |
| POST | `/api/setup`  | ❌ | Seed default users |
| POST | `/api/auth/register` | ❌ | Register new user |
| POST | `/api/auth/login`    | ❌ | Login → JWT token |
| GET  | `/api/auth/verify`   | ✅ | Verify JWT |
| GET  | `/api/movies`        | ❌ | All movies |
| GET  | `/api/movies/:id`    | ❌ | Movie by ID |
| GET  | `/api/shows?movieId=m1` | ❌ | Shows for movie |
| GET  | `/api/seats?showId=...` | ❌ | Seat layout |
| GET  | `/api/snacks`        | ❌ | All snacks |
| POST | `/api/bookings`      | ✅ | Create booking |
| GET  | `/api/bookings`      | ✅ | My bookings |
| PATCH| `/api/bookings/:id/cancel` | ✅ | Cancel booking |
| GET  | `/api/admin/dashboard` | ✅ Admin | Revenue stats |
| GET  | `/api/admin/bookings`  | ✅ Admin | All bookings |
| GET  | `/api/admin/users`     | ✅ Admin | All users |

---

## ✨ Features

- 🎥 **14 Movies** with real poster images
- 🤖 **AI Mood Matcher** — describe your mood, get movie suggestions
- 🪑 **AI Seat Recommender** — picks best seats based on screen angle & acoustics
- 👥 **Group Optimizer** — book seats for groups of 2–8 people
- 👁️ **AR Theater Preview** — simulate the view from any seat
- 🎙️ **Voice Booking** — say "Book tickets for Pushpa 2" to book hands-free
- ⚡ **Dynamic Surge Pricing** — prices rise for blockbusters & weekends
- 🎟️ **Smart Vouchers** — discount codes based on demand & show time
- 🚗 **Parking Slot Booking** — reserve parking during checkout
- 📱 **QR Code Tickets** — auto-generated per booking
- 🛡️ **Admin Dashboard** — manage bookings, users, staff, and queries
- 🗄️ **MySQL Backend** — full persistence, all data stored in the database

---

## 🛠 Troubleshooting

**MySQL connection error?**
- Make sure MySQL server is running
- Double-check `.env` credentials
- Ensure the `cineai` database exists (run `database.sql` first)

**Port already in use?**
- Change `PORT=4001` in `.env`

**Demo mode (no MySQL)?**
- Run `node server-demo.js` instead (in-memory, resets on restart)
