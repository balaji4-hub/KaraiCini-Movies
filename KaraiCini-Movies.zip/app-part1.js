const { useState, useEffect, useMemo } = React;

const App = () => {
  const [currentPage, setCurrentPage] = useState('home');
  const [pageParams, setPageParams] = useState({});
  const [user, setUser] = useState(null);
  const [showAuth, setShowAuth] = useState(false);
  const [authMode, setAuthMode] = useState('login');
  const [showAdminLoginHint, setShowAdminLoginHint] = useState(false);
  const [userPoints, setUserPoints] = useState(() => {
    try { return JSON.parse(localStorage.getItem('kc_points') || '{}'); } catch { return {}; }
  });
  const addPoints = (userId, pts) => {
    setUserPoints(prev => {
      const updated = { ...prev, [userId]: (prev[userId] || 0) + pts };
      localStorage.setItem('kc_points', JSON.stringify(updated));
      return updated;
    });
  };
  const getPoints = (userId) => userPoints[userId] || 0;

  const navigate = (page, params = {}) => {
    setCurrentPage(page);
    setPageParams(params);
    window.scrollTo({ top:0, behavior:'smooth' });
  };

  const login = (u) => {
    setUser(u);
    setShowAuth(false);
    if (!userPoints[u.id]) addPoints(u.id, 50); // Welcome bonus
  };

  const logout = () => {
    setUser(null);
    navigate('home');
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Navbar */}
      <nav className="glass fixed top-0 w-full z-50 px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => navigate('home')}>
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center font-bold text-xl">
            K
          </div>
          <span className="text-2xl font-bold gradient-text">{KC.APP_NAME}</span>
          <div className="ml-3 hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 text-xs font-bold shadow-[0_0_10px_rgba(234,179,8,0.2)]">
            ★ 4.9/5 CineAI Prime
          </div>
        </div>
        <div className="flex gap-4 items-center flex-wrap">
          <button onClick={() => navigate('home')} className="hover:text-red-400 text-sm">Home</button>
          <button onClick={() => navigate('movies')} className="hover:text-red-400 text-sm">Movies</button>
          <button onClick={() => navigate('comingsoon')} className="hover:text-red-400 text-sm">Coming Soon</button>
          <button onClick={() => navigate('offers')} className="hover:text-yellow-400 text-sm text-yellow-500 font-bold">🎁 Offers</button>
          {user && <button onClick={() => navigate('dashboard')} className="hover:text-red-400 text-sm">My Bookings</button>}
          {user && user.role === 'admin' && <button onClick={() => navigate('admin')} className="hover:text-red-400 font-bold text-red-500 text-sm">Admin</button>}
          {user ? (
            <div className="flex items-center gap-3 ml-2">
              <button onClick={() => navigate('profile')} className="flex items-center gap-2 bg-white/10 hover:bg-white/15 px-3 py-1.5 rounded-full transition-all border border-white/10">
                <span className="text-lg">👤</span>
                <span className="text-sm font-bold">{user.name.split(' ')[0]}</span>
                <span className="text-xs text-yellow-400 font-bold">⭐ {getPoints(user.id)} pts</span>
              </button>
              <button onClick={logout} className="text-sm text-red-400 hover:text-red-300">Logout</button>
            </div>
          ) : (
            <div className="flex items-center gap-2 ml-2">
              <button onClick={() => setShowAuth(true)} className="btn-primary">Sign In</button>
              <button onClick={() => navigate('adminlogin')} className="text-xs text-gray-500 hover:text-red-400 transition-colors border border-white/10 px-3 py-1.5 rounded-lg">🔐 Admin</button>
            </div>
          )}
        </div>
      </nav>

      {/* Main Content */}
      <main className="pt-24 px-6 max-w-7xl mx-auto">
        {currentPage === 'home' && <HomePage navigate={navigate} user={user} />}
        {currentPage === 'movies' && <MoviesPage navigate={navigate} user={user} />}
        {currentPage === 'movie' && <MovieDetails navigate={navigate} movieId={pageParams.id} user={user} addPoints={addPoints} />}
        {currentPage === 'comingsoon' && <ComingSoonPage navigate={navigate} />}
        {currentPage === 'offers' && <OffersPage navigate={navigate} user={user} getPoints={getPoints} />}
        {currentPage === 'profile' && <UserProfilePage navigate={navigate} user={user} getPoints={getPoints} addPoints={addPoints} setShowAuth={setShowAuth} setAuthMode={setAuthMode} />}
        {currentPage === 'book' && (() => { const BF = window.BookingFlow; return BF ? <BF navigate={navigate} showId={pageParams.showId} user={user} addPoints={addPoints} /> : <div className="text-center p-12 text-yellow-400">Loading booking system...</div>; })()}
        {currentPage === 'dashboard' && (() => { const DB = window.Dashboard; return DB ? <DB navigate={navigate} user={user} /> : <div className="text-center p-12 text-yellow-400">Loading dashboard...</div>; })()}
        {currentPage === 'admin' && (() => { const AD = window.AdminDashboard; return AD ? <AD navigate={navigate} user={user} /> : <div className="text-center p-12 text-red-400 font-bold text-xl mt-20">⚠️ Admin Dashboard failed to load. Check browser console.</div>; })()}
        {currentPage === 'adminlogin' && <AdminLoginPage navigate={navigate} onLogin={(u) => { login(u); navigate('admin'); }} />}
      </main>

      {/* Auth Modal */}
      {showAuth && (
        <AuthModal 
          mode={authMode} 
          setMode={setAuthMode} 
          onClose={() => setShowAuth(false)} 
          onLogin={login} 
        />
      )}
      
      {/* AI Assistant Chat Widget */}
      <AIAssistant />
      
      {/* AI Voice Booking Widget */}
      <AIVoiceBooking navigate={navigate} />
    </div>
  );
};

const AdminLoginPage = ({ navigate, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPass, setShowPass] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [loginSuccess, setLoginSuccess] = useState(false);

  const adminRoles = [
    { icon: '🛡️', title: 'Super Admin', desc: 'Full system control' },
    { icon: '🎬', title: 'Theater Manager', desc: 'Manage shows & screens' },
    { icon: '💰', title: 'Finance Admin', desc: 'Payments & refunds' },
    { icon: '👤', title: 'Customer Support', desc: 'Complaints & support' },
    { icon: '📈', title: 'Marketing Admin', desc: 'Promotions & ads' },
  ];

  const handleLogin = (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    setTimeout(() => {
      const u = KC.USERS.find(u => u.email === email && u.password === password && u.role === 'admin');
      if (u) {
        setIsLoading(false);
        setLoginSuccess(true);
        setTimeout(() => onLogin(u), 1200);
      } else {
        setIsLoading(false);
        setError('Invalid admin credentials. This portal is restricted to authorized personnel only.');
      }
    }, 1500);
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative overflow-hidden -mt-24 -mx-6 px-6 py-24">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-red-950/30 to-black"></div>
      <div className="absolute top-20 left-20 w-96 h-96 bg-red-600/10 rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-20 right-20 w-80 h-80 bg-orange-600/10 rounded-full blur-3xl animate-pulse" style={{animationDelay:'1s'}}></div>
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-red-900/5 rounded-full blur-3xl"></div>

      <div className="relative w-full max-w-4xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">

        {/* Left Side — Branding & Role Cards */}
        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center font-black text-2xl shadow-[0_0_30px_rgba(244,63,94,0.4)]">K</div>
              <div>
                <div className="text-2xl font-black gradient-text">KaraiCini</div>
                <div className="text-xs text-gray-500 font-mono tracking-widest">ADMIN PORTAL v2.0</div>
              </div>
            </div>
            <h1 className="text-4xl font-black text-white mb-2">Secure Admin <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 to-orange-500">Control Center</span></h1>
            <p className="text-gray-400 text-sm">Authorized personnel only. All login attempts are logged and monitored.</p>
          </div>

          <div className="space-y-2">
            <p className="text-[10px] text-gray-600 uppercase tracking-widest font-bold">Access Levels Available</p>
            {adminRoles.map(role => (
              <div key={role.title} className="flex items-center gap-3 p-3 bg-white/3 border border-white/5 rounded-xl hover:border-white/10 transition-colors">
                <span className="text-lg">{role.icon}</span>
                <div>
                  <div className="font-bold text-xs text-white">{role.title}</div>
                  <div className="text-[10px] text-gray-500">{role.desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center gap-2 text-[10px] text-gray-600">
            <span>🔒</span>
            <span>256-bit encrypted connection · Session auto-expires in 4 hours</span>
          </div>
        </div>

        {/* Right Side — Login Form */}
        <div className="glass-dark p-8 rounded-3xl border border-white/10 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-red-500 via-orange-400 to-red-500"></div>

          {loginSuccess ? (
            <div className="flex flex-col items-center justify-center py-12 animate-fade-in">
              <div className="w-20 h-20 rounded-full bg-green-500/20 border-2 border-green-500 flex items-center justify-center mb-4">
                <span className="text-4xl">✅</span>
              </div>
              <h3 className="text-2xl font-black text-green-400">Access Granted!</h3>
              <p className="text-gray-400 text-sm mt-2">Loading Admin Dashboard...</p>
              <div className="w-32 h-1 bg-white/10 rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-gradient-to-r from-green-500 to-emerald-500 animate-[loading_1.2s_ease-out_forwards]" style={{animation:'loadingBar 1.2s ease-out forwards'}}></div>
              </div>
            </div>
          ) : (
            <>
              <div className="flex items-center gap-2 mb-8">
                <div className="w-8 h-8 rounded-lg bg-red-500/20 border border-red-500/30 flex items-center justify-center">
                  <span className="text-sm">🔐</span>
                </div>
                <div>
                  <h2 className="font-black text-lg">Admin Sign In</h2>
                  <p className="text-[10px] text-gray-500">Restricted Access</p>
                </div>
              </div>

              {error && (
                <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs animate-fade-in">
                  🚨 {error}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="text-[10px] text-gray-400 uppercase tracking-wider font-bold block mb-1.5">Admin Email</label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    placeholder="admin@karaicini.com"
                    required
                    className="input-field font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 uppercase tracking-wider font-bold block mb-1.5">Password</label>
                  <div className="relative">
                    <input
                      type={showPass ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      placeholder="Enter secure password"
                      required
                      className="input-field font-mono text-sm pr-12"
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 hover:text-white transition-colors text-xs">
                      {showPass ? '🙈' : '👁️'}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-3.5 rounded-xl font-black text-white bg-gradient-to-r from-red-600 to-orange-500 hover:from-red-500 hover:to-orange-400 transition-all shadow-[0_0_20px_rgba(244,63,94,0.3)] hover:shadow-[0_0_30px_rgba(244,63,94,0.5)] disabled:opacity-60 mt-2"
                >
                  {isLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                      Authenticating...
                    </span>
                  ) : '🔐 Access Admin Portal'}
                </button>
              </form>

              <div className="mt-6 pt-6 border-t border-white/5 flex items-center justify-between">
                <button onClick={() => navigate('home')} className="text-xs text-gray-600 hover:text-gray-400 transition-colors">← Back to Site</button>
                <div className="text-[10px] text-gray-700 font-mono">SESSION MONITORED</div>
              </div>
            </>
          )}
        </div>
      </div>
      <style>{`
        @keyframes loadingBar { from { width: 0%; } to { width: 100%; } }
      `}</style>
    </div>
  );
};

const AuthModal = ({ mode, setMode, onClose, onLogin }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');

  const submit = (e) => {
    e.preventDefault();
    if (mode === 'login') {
      const u = KC.USERS.find(u => u.email === email && u.password === password);
      if (u) {
        alert(`Welcome back, ${u.name}!`);
        onLogin(u);
      } else {
        alert('Invalid credentials. Please check your email and password.');
      }
    } else {
      const u = { id:'u'+Date.now(), name, email, password, role:'user', prefLangs:['English'] };
      KC.USERS.push(u);
      if(KC.saveUsers) KC.saveUsers();
      alert(`Welcome ${u.name}! We're glad to have you.`);
      onLogin(u);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-[100] p-4 backdrop-blur-sm">
      <div className="glass-dark p-8 rounded-2xl w-full max-w-md relative overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-red-500 to-orange-500"></div>
        <button onClick={onClose} className="absolute top-4 right-4 text-xl text-gray-400 hover:text-white transition-colors">✕</button>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-gradient-to-br from-red-500 to-orange-500 rounded-2xl mx-auto flex items-center justify-center text-3xl font-bold shadow-[0_0_20px_rgba(244,63,94,0.4)] mb-4">
            K
          </div>
          <h2 className="text-3xl font-black">{mode === 'login' ? 'Welcome Back' : 'Join KaraiCini'}</h2>
          <p className="text-gray-400 text-sm mt-2">{mode === 'login' ? 'Sign in to access your bookings and personalized offers' : 'Create an account for AI-powered movie recommendations'}</p>
        </div>

        <form onSubmit={submit} className="space-y-5">
          {mode === 'register' && (
            <div>
              <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1 block">Full Name</label>
              <input className="input-field bg-white/5 border-white/10 focus:bg-white/10 transition-all" placeholder="John Doe" value={name} onChange={e=>setName(e.target.value)} required />
            </div>
          )}
          <div>
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1 block">Email Address</label>
            <input className="input-field bg-white/5 border-white/10 focus:bg-white/10 transition-all" type="email" placeholder="you@example.com" value={email} onChange={e=>setEmail(e.target.value)} required />
          </div>
          <div>
            <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1 block">Password</label>
            <input className="input-field bg-white/5 border-white/10 focus:bg-white/10 transition-all" type="password" placeholder="••••••••" value={password} onChange={e=>setPassword(e.target.value)} required />
          </div>
          <button className="btn-primary w-full py-4 text-lg shadow-[0_0_20px_rgba(244,63,94,0.3)] hover:shadow-[0_0_30px_rgba(244,63,94,0.5)] mt-4">{mode === 'login' ? 'Sign In Securely' : 'Create Account'}</button>
        </form>
        
        <div className="mt-6 text-center text-sm border-t border-white/10 pt-6">
          <p className="text-gray-400 mb-2">{mode === 'login' ? "Don't have an account?" : "Already have an account?"}</p>
          <button type="button" onClick={() => setMode(mode==='login'?'register':'login')} className="text-red-400 font-bold hover:text-red-300 underline underline-offset-4">
            {mode === 'login' ? 'Create a new account' : 'Sign in here'}
          </button>
        </div>
      </div>
    </div>
  );
};

const COMING_SOON = [
  { id:'cs1', title:'Avengers: Doomsday', releaseDate:'2026-05-01', genre:['Action','Sci-Fi'], poster:'https://images.unsplash.com/photo-1635805737707-575885ab0820?w=400&h=600&fit=crop', desc:'The Avengers face their greatest threat yet in a multiversal war.', hype:'🔥 Extreme' },
  { id:'cs2', title:'RRR 2', releaseDate:'2026-07-15', genre:['Action','Drama'], poster:'https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop', desc:'The legendary duo returns for an epic sequel.', hype:'⚡ Very High' },
  { id:'cs3', title:'Interstellar 2', releaseDate:'2026-09-20', genre:['Sci-Fi','Drama'], poster:'https://images.unsplash.com/photo-1446776653964-20c1d3a81b06?w=400&h=600&fit=crop', desc:'A new journey through the cosmos begins where the first left off.', hype:'🚀 Massive' },
  { id:'cs4', title:'KGF Chapter 3', releaseDate:'2026-12-25', genre:['Action','Drama'], poster:'https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=400&h=600&fit=crop', desc:'Rocky rises again in the most anticipated Indian blockbuster.', hype:'🔥 Extreme' },
  { id:'cs5', title:'Mission: Impossible 8', releaseDate:'2026-06-10', genre:['Action','Thriller'], poster:'https://images.unsplash.com/photo-1509347528160-9a9e33742cdb?w=400&h=600&fit=crop', desc:'Ethan Hunt faces his deadliest mission in a world without rules.', hype:'⭐ High' },
];

const HomePage = ({ navigate, user }) => {
  const [heroIndex, setHeroIndex] = useState(0);
  const heroMovies = KC.MOVIES.slice(0, 5);

  useEffect(() => {
    const t = setInterval(() => setHeroIndex(i => (i + 1) % heroMovies.length), 4500);
    return () => clearInterval(t);
  }, []);

  const hero = heroMovies[heroIndex];

  return (
    <div className="space-y-16 animate-fade-in">

      {/* ── HERO CAROUSEL ── */}
      <div className="relative h-[520px] rounded-3xl overflow-hidden shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/75 to-transparent z-10" />
        <img key={hero.id} src={hero.backdrop} className="absolute inset-0 w-full h-full object-cover opacity-55 transition-all duration-700" />
        <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-[#0a0a0f] to-transparent z-10" />
        <div className="relative z-20 flex flex-col justify-end h-full p-12 max-w-3xl">
          <div className="flex gap-2 mb-3 flex-wrap">
            {hero.tags.map(t => <span key={t} className="badge badge-yellow text-[10px]">{t}</span>)}
            <span className="badge badge-red text-[10px]">{hero.cert}</span>
            {hero.demand === 'high' && <span className="badge badge-red text-[10px] animate-pulse">🔥 High Demand</span>}
          </div>
          <h1 className="text-5xl font-black mb-3 leading-tight drop-shadow-xl">{hero.title}</h1>
          <p className="text-gray-300 text-base mb-2">{hero.duration} min • {hero.genre.join(', ')} • ⭐ {hero.rating}/10</p>
          <p className="text-gray-400 text-sm max-w-xl mb-6 line-clamp-2">{hero.desc}</p>
          <div className="flex gap-4">
            <button onClick={() => navigate('movie', {id: hero.id})} className="btn-primary text-base px-8 py-3 shadow-[0_0_20px_rgba(244,63,94,0.5)] hover:scale-105 transition-transform">🎟️ Book Now</button>
            <button onClick={() => navigate('movies')} className="btn-secondary text-base px-6 py-3 hover:bg-white/20 transition-colors">Browse All</button>
          </div>
        </div>
        {/* Carousel dots */}
        <div className="absolute bottom-5 right-8 flex gap-2 z-20">
          {heroMovies.map((_, i) => (
            <button key={i} onClick={() => setHeroIndex(i)} className={`w-2 h-2 rounded-full transition-all ${ i === heroIndex ? 'bg-red-500 w-6' : 'bg-white/40 hover:bg-white/60' }`} />
          ))}
        </div>
      </div>

      {/* ── QUICK STATS ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { icon:'🎬', label:'Movies Now Showing', val: KC.MOVIES.length + '+' },
          { icon:'🏆', label:'Screens Available', val:'5 Premium' },
          { icon:'🤖', label:'AI-Powered Features', val:'15+ Active' },
          { icon:'⭐', label:'Customer Rating', val:'4.9 / 5.0' },
        ].map((s,i) => (
          <div key={i} className="glass border border-white/10 p-5 rounded-2xl text-center hover:border-red-500/30 transition-all hover:-translate-y-1">
            <div className="text-3xl mb-2">{s.icon}</div>
            <div className="text-xl font-black text-white">{s.val}</div>
            <div className="text-xs text-gray-400 mt-1">{s.label}</div>
          </div>
        ))}
      </div>

      {/* ── TRENDING NOW ── */}
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold flex items-center gap-2"><span className="text-red-500">🔥</span> Trending Now</h2>
          <button onClick={() => navigate('movies')} className="text-sm text-red-400 hover:text-red-300 font-bold">View All →</button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {KC.MOVIES.slice(0, 5).map(m => (
            <MovieCard key={m.id} movie={m} onClick={() => navigate('movie', {id:m.id})} />
          ))}
        </div>
      </div>

      {/* ── AI PICKS FOR YOU ── */}
      {user && (
        <div>
          <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">🤖 <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-500">AI Picks for You</span></h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {KC.MOVIES.filter(m => (user.prefLangs || []).some(l => (m.langs || [m.lang]).includes(l))).slice(0,4).map(m => (
              <MovieCard key={m.id} movie={m} onClick={() => navigate('movie', {id:m.id})} />
            ))}
          </div>
        </div>
      )}

      {/* ── COMING SOON TEASER ── */}
      <div>
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold flex items-center gap-2">🎭 Coming Soon</h2>
          <button onClick={() => navigate('comingsoon')} className="text-sm text-purple-400 hover:text-purple-300 font-bold">See All →</button>
        </div>
        <div className="flex gap-5 overflow-x-auto pb-3 hide-scrollbar">
          {COMING_SOON.slice(0,4).map(cs => (
            <div key={cs.id} className="min-w-[160px] group cursor-pointer" onClick={() => navigate('comingsoon')}>
              <div className="relative aspect-[2/3] rounded-xl overflow-hidden mb-2">
                <img src={cs.poster} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" alt={cs.title} onError={e=>{e.target.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop';}} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
                <div className="absolute top-2 right-2 bg-purple-600 text-white text-[9px] font-bold px-2 py-0.5 rounded">SOON</div>
                <div className="absolute bottom-2 left-2 right-2">
                  <div className="text-[10px] text-purple-300 font-bold">{cs.hype}</div>
                </div>
              </div>
              <h3 className="font-bold text-sm text-white line-clamp-1">{cs.title}</h3>
              <p className="text-[10px] text-gray-400">{new Date(cs.releaseDate).toLocaleDateString('en-IN', {day:'numeric',month:'short',year:'numeric'})}</p>
            </div>
          ))}
        </div>
      </div>

      {/* ── OFFERS BANNER ── */}
      <div onClick={() => navigate('offers')} className="cursor-pointer bg-gradient-to-r from-yellow-600/20 via-orange-600/20 to-red-600/20 border border-yellow-500/30 rounded-3xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 hover:border-yellow-500/60 transition-all hover:shadow-[0_0_40px_rgba(234,179,8,0.15)]">
        <div>
          <div className="text-yellow-400 font-bold text-sm mb-1">🎁 EXCLUSIVE MEMBER OFFERS</div>
          <h2 className="text-3xl font-black text-white">Save up to 30% on tickets this weekend!</h2>
          <p className="text-gray-300 mt-2 text-sm">Use promo codes SAVE30 · FLAT200 · EARLYBIRD20 · WEEKENDFUN</p>
        </div>
        <button className="bg-gradient-to-r from-yellow-500 to-orange-500 text-black font-black px-8 py-4 rounded-2xl text-lg hover:scale-105 transition-transform shadow-[0_0_20px_rgba(234,179,8,0.4)] whitespace-nowrap">Claim Offer →</button>
      </div>

      {/* ── WHY KARAICINI ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {[
          { icon:'🤖', title:'AI Seat Picker', desc:'Our AI analyzes 50+ factors to recommend the perfect seat — acoustic quality, screen angle, crowd density.' },
          { icon:'💰', title:'Dynamic Pricing', desc:'Real-time surge pricing and exclusive off-peak discounts powered by our demand forecasting engine.' },
          { icon:'🎙️', title:'Voice Booking', desc:'Book tickets hands-free with natural language voice commands. Just say "Book Deadpool for Saturday night".' },
        ].map((f,i) => (
          <div key={i} className="glass border border-white/10 p-6 rounded-2xl hover:border-red-500/30 transition-all">
            <div className="text-4xl mb-4">{f.icon}</div>
            <h3 className="font-bold text-lg mb-2">{f.title}</h3>
            <p className="text-gray-400 text-sm leading-relaxed">{f.desc}</p>
          </div>
        ))}
      </div>

    </div>
  );
};

const MovieCard = ({ movie, onClick }) => (
  <div onClick={onClick} className="cursor-pointer group relative rounded-xl overflow-hidden transition-transform hover:-translate-y-2 hover:shadow-[0_10px_30px_rgba(244,63,94,0.3)]">
    <div className="aspect-[2/3] relative">
      <img src={movie.poster} className="w-full h-full object-cover" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity" />
      <div className="absolute top-2 right-2 bg-black/60 backdrop-blur-md px-2 py-1 rounded text-xs font-bold border border-white/10 flex items-center gap-1">
        ⭐ {movie.rating}
      </div>
      {movie.demand === 'high' && <div className="absolute top-2 left-2 badge badge-red text-[10px]">High Demand</div>}
      {movie.demand === 'low' && <div className="absolute top-2 left-2 badge badge-green text-[10px]">Offers</div>}
    </div>
    <div className="absolute bottom-0 w-full p-4">
      <h3 className="font-bold text-lg leading-tight truncate">{movie.title}</h3>
      <p className="text-xs text-gray-400 mt-1">{movie.genre.join(', ')} • {movie.lang}</p>
    </div>
  </div>
);

const MoviesPage = ({ navigate, user }) => {
  const [langFilter, setLangFilter] = useState('All');
  const [moodText, setMoodText] = useState('');
  const [isAiSearching, setIsAiSearching] = useState(false);
  
  const langs = ['All', ...new Set(KC.MOVIES.flatMap(m => m.langs || [m.lang]))];
  
  const filtered = useMemo(() => {
    let list = KC.MOVIES;
    if (langFilter !== 'All') list = list.filter(m => (m.langs||[m.lang]).includes(langFilter));
    
    if (moodText.trim()) {
      const q = moodText.toLowerCase();
      list = list.filter(m => {
        const text = (m.title + ' ' + m.desc + ' ' + m.genre.join(' ') + ' ' + m.tags.join(' ')).toLowerCase();
        
        // Advanced Mood Mapping
        if (q.includes('stress') || q.includes('sad') || q.includes('depress') || q.includes('relax')) {
          if (m.genre.includes('Comedy') || m.genre.includes('Family') || m.genre.includes('Animation')) return true;
        }
        if (q.includes('bored') || q.includes('thrill') || q.includes('excit')) {
          if (m.genre.includes('Action') || m.genre.includes('Sci-Fi') || m.genre.includes('Thriller')) return true;
        }
        if (q.includes('scare') || q.includes('spooky')) {
          if (m.genre.includes('Horror')) return true;
        }
        if (q.includes('love') || q.includes('romantic')) {
          if (m.genre.includes('Romance') || m.genre.includes('Drama')) return true;
        }
        
        return text.includes(q);
      });
    }
    
    // Sort so user's preferred languages come first if logged in
    if (user?.prefLangs?.length && langFilter === 'All' && !moodText) {
      list.sort((a,b) => {
        const aPref = a.langs?.some(l => user.prefLangs.includes(l)) ? 1 : 0;
        const bPref = b.langs?.some(l => user.prefLangs.includes(l)) ? 1 : 0;
        return bPref - aPref;
      });
    }
    return list;
  }, [langFilter, user, moodText]);

  return (
    <div className="animate-fade-in">
      <div className="glass p-6 rounded-2xl mb-8 flex flex-col md:flex-row gap-4 justify-between items-center relative overflow-hidden border border-white/10 shadow-[0_0_30px_rgba(255,255,255,0.05)]">
        <div className="absolute top-0 left-0 w-1 h-full bg-gradient-to-b from-blue-400 to-purple-500"></div>
        <div className="flex-1 w-full pl-4">
          <h2 className="text-xl font-bold mb-2 flex items-center gap-2">✨ AI Mood Matcher</h2>
          <div className="relative">
            <input 
              type="text" 
              placeholder="How are you feeling today? (e.g., 'I feel stressed', 'Bored out of my mind')" 
              className="w-full bg-black/40 border border-white/20 rounded-xl pl-4 pr-12 py-3 outline-none focus:border-blue-500 transition-colors shadow-inner"
              value={moodText}
              onChange={(e) => {
                setMoodText(e.target.value);
                setIsAiSearching(e.target.value.length > 2);
              }}
            />
            {isAiSearching && (
              <div className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full border-2 border-blue-500 border-t-transparent animate-spin"></div>
            )}
          </div>
        </div>
        
        <div className="flex flex-col items-end gap-2 w-full md:w-auto">
          <div className="flex items-center gap-3">
            <span className="text-sm text-gray-400">Language:</span>
            <select className="bg-black/50 border border-white/20 rounded-lg px-3 py-2 text-sm outline-none focus:border-white/40 transition-colors cursor-pointer" value={langFilter} onChange={e=>setLangFilter(e.target.value)}>
              {langs.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
          </div>
          {user?.prefLangs?.length > 0 && (
            <p className="text-[10px] text-gray-400 mt-1 max-w-[200px] text-right">Prioritizing: <span className="text-white">{user.prefLangs.join(', ')}</span></p>
          )}
        </div>
      </div>
      
      {moodText.trim() && filtered.length > 0 && (
        <div className="mb-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-xl">
          <p className="text-blue-400 font-bold text-sm flex items-center gap-2">
            <span>💡</span> AI Suggests: Comedy, Light-hearted movies, and nearby shows for you!
          </p>
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="text-center p-12 text-gray-400">No movies found matching your mood or filters.</div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-6">
          {filtered.map(m => <MovieCard key={m.id} movie={m} onClick={() => navigate('movie', {id:m.id})} />)}
        </div>
      )}
    </div>
  );
};

const MovieDetails = ({ navigate, movieId }) => {
  const movie = KC.MOVIES.find(m => m.id === movieId);
  const [shows, setShows] = useState([]);
  
  useEffect(() => {
    if(movie) setShows(KC.generateShows(movie.id));
  }, [movie]);

  if (!movie) return <div>Movie not found</div>;

  const dates = [...new Set(shows.map(s => s.showDate))].sort();
  const [selDate, setSelDate] = useState(dates[0]);

  const dateShows = shows.filter(s => s.showDate === selDate);
  const byScreen = dateShows.reduce((acc, s) => {
    if(!acc[s.screen]) acc[s.screen] = [];
    acc[s.screen].push(s);
    return acc;
  }, {});

  return (
    <div className="animate-fade-in pb-20">
      <div className="relative h-[400px] rounded-3xl overflow-hidden mb-10 border border-white/10 shadow-2xl">
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent z-10" />
        <img src={movie.backdrop} className="absolute inset-0 w-full h-full object-cover opacity-50" />
        <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-[#0a0a0f] to-transparent z-10" />
        
        <div className="relative z-20 flex p-8 h-full items-end gap-8">
          <img src={movie.poster} className="w-48 h-72 rounded-xl shadow-[0_0_30px_rgba(0,0,0,0.8)] border border-white/10 hidden md:block" />
          <div>
            <div className="flex gap-2 mb-3">
              {movie.tags.map(t => <span key={t} className="badge badge-yellow">{t}</span>)}
              <span className="badge badge-blue">{movie.cert}</span>
            </div>
            <h1 className="text-4xl font-black mb-2">{movie.title}</h1>
            <p className="text-gray-300 text-sm mb-4">
              {movie.duration} min • {movie.genre.join(', ')} • ⭐ {movie.rating} / 10
            </p>
            <p className="max-w-2xl text-gray-400 mb-6">{movie.desc}</p>
            <p className="text-sm text-gray-500 mb-2">Available in: <span className="text-white">{movie.langs?.join(', ')}</span></p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white/5 border border-white/10 rounded-2xl p-6">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2">🎟️ Book Tickets</h2>
          
          <div className="flex gap-2 mb-8 overflow-x-auto pb-2 hide-scrollbar">
            {dates.map(d => {
              const dt = new Date(d);
              return (
                <button 
                  key={d} 
                  onClick={() => setSelDate(d)}
                  className={`min-w-[80px] rounded-xl py-3 text-center border transition-all ${selDate === d ? 'bg-red-500/20 border-red-500 text-red-400' : 'bg-black/50 border-white/10 text-gray-400 hover:bg-white/5'}`}
                >
                  <div className="text-xs uppercase">{dt.toLocaleDateString('en-US',{weekday:'short'})}</div>
                  <div className="font-bold text-lg">{dt.getDate()}</div>
                  <div className="text-[10px] uppercase">{dt.toLocaleDateString('en-US',{month:'short'})}</div>
                </button>
              )
            })}
          </div>

          <div className="space-y-6">
            {Object.entries(byScreen).map(([screen, scrShows]) => (
              <div key={screen} className="glass p-5 rounded-xl">
                <h3 className="font-bold mb-4">{screen} <span className="text-xs text-gray-500 font-normal ml-2">Standard & VIP</span></h3>
                <div className="flex flex-wrap gap-3">
                  {scrShows.map(s => (
                    <button 
                      key={s.id} 
                      onClick={() => navigate('book', {showId: s.id})}
                      className="relative group border border-green-500/30 bg-green-500/10 hover:bg-green-500/20 text-green-400 px-4 py-2 rounded-lg text-sm transition-all"
                    >
                      {s.showTime}
                      <div className="text-[10px] opacity-70 mt-0.5">{s.lang}</div>
                      
                      {s.surge && <div className="absolute -top-2 -right-2 bg-gradient-to-r from-red-600 to-orange-500 text-white font-bold text-[9px] px-1.5 py-0.5 rounded shadow z-20 shadow-[0_0_10px_rgba(239,68,68,0.5)]">⚡ AI Surge</div>}
                      
                      <div className="absolute -top-14 left-1/2 -translate-x-1/2 bg-black/95 border border-white/20 text-white px-3 py-2 rounded-xl opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-30 shadow-2xl flex flex-col items-center min-w-[120px]">
                        <span className="font-bold text-lg text-green-400">₹{s.price}</span>
                        <span className="text-[10px] text-gray-400 whitespace-nowrap">{s.avail} seats left</span>
                        {s.surgeReason && <span className="text-[9px] text-orange-400 mt-1 text-center leading-tight font-bold border-t border-white/10 pt-1 w-full">{s.surgeReason}</span>}
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            ))}
            {Object.keys(byScreen).length === 0 && (
              <div className="text-center py-10 text-gray-500">No shows available for this date.</div>
            )}
          </div>
        </div>

        <div className="bg-white/5 border border-white/10 rounded-2xl p-6 h-fit">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2 text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-400">✨ CineAI Spoiler-Free Review</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center bg-white/5 p-3 rounded-lg border border-white/5">
              <span className="text-xs text-gray-400 font-medium">Critical Consensus Vibe</span>
              <span className="text-sm font-bold text-yellow-400">🔥 {Math.min(98, Math.round(movie.rating * 10 + 8))}% Vibe Score</span>
            </div>
            
            <div className="text-xs text-gray-400 leading-relaxed border-b border-white/10 pb-4">
              <p className="font-bold text-white mb-1">🍿 The Spoiler-Free Verdict</p>
              "An absolute masterclass in cinematic execution. The story balances pacing and high-impact visual design while respecting audience intelligence. Highly recommended to experience in premium formats like IMAX."
            </div>
            
            <div className="space-y-3 pt-2">
              <p className="text-xs font-bold text-white uppercase tracking-wider">AI Vibe Meter</p>
              <div className="space-y-2">
                <div>
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-gray-400">Pacing</span>
                    <span className="text-blue-400 font-bold">Fast & Engaging</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-blue-500 h-full rounded-full" style={{width: '85%'}}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-gray-400">Emotional Depth</span>
                    <span className="text-purple-400 font-bold">Resonant</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-purple-500 h-full rounded-full" style={{width: '90%'}}></div>
                  </div>
                </div>
                
                <div>
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-gray-400">Spoiler Risk Level</span>
                    <span className="text-green-400 font-bold">0% Safe</span>
                  </div>
                  <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-green-500 h-full rounded-full" style={{width: '5%'}}></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════
// COMING SOON PAGE
// ═══════════════════════════════════════════════════════════
const ComingSoonPage = ({ navigate }) => {
  const [reminders, setReminders] = useState({});
  const toggleReminder = (id) => {
    setReminders(r => { const n = {...r, [id]: !r[id]}; return n; });
    alert(reminders[id] ? 'Reminder removed!' : '🔔 Reminder set! We will notify you when booking opens.');
  };
  return (
    <div className="animate-fade-in space-y-8 pb-12">
      <div className="text-center py-10">
        <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500 mb-3">🎭 Coming Soon</h1>
        <p className="text-gray-400">Set reminders for your most-anticipated movies. Be the first to book!</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {COMING_SOON.map(cs => {
          const daysLeft = Math.ceil((new Date(cs.releaseDate) - new Date()) / (1000*60*60*24));
          return (
            <div key={cs.id} className="glass border border-white/10 rounded-2xl overflow-hidden hover:border-purple-500/40 transition-all hover:-translate-y-1">
              <div className="relative h-48 overflow-hidden">
                <img src={cs.poster} className="w-full h-full object-cover" alt={cs.title} onError={e=>{e.target.src='https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=600&fit=crop';}} />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 to-transparent" />
                <div className="absolute top-3 left-3 bg-purple-600 text-white text-xs font-bold px-2 py-1 rounded-lg">{cs.hype}</div>
                <div className="absolute bottom-3 right-3 bg-black/80 text-white text-xs font-bold px-2 py-1 rounded-lg border border-white/20">
                  {daysLeft > 0 ? `${daysLeft} days away` : 'Releasing Soon!'}
                </div>
              </div>
              <div className="p-5">
                <h3 className="font-black text-lg text-white mb-1">{cs.title}</h3>
                <p className="text-xs text-gray-400 mb-1">{cs.genre.join(', ')}</p>
                <p className="text-xs text-purple-400 font-bold mb-3">🗓 {new Date(cs.releaseDate).toLocaleDateString('en-IN', {day:'numeric',month:'long',year:'numeric'})}</p>
                <p className="text-sm text-gray-300 mb-4 leading-relaxed">{cs.desc}</p>
                {/* Hype meter */}
                <div className="mb-4">
                  <div className="flex justify-between text-[10px] mb-1">
                    <span className="text-gray-500">Audience Hype</span>
                    <span className="text-purple-400 font-bold">{cs.hype.includes('Extreme') ? '98%' : cs.hype.includes('Massive') ? '95%' : cs.hype.includes('Very') ? '88%' : '75%'}</span>
                  </div>
                  <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-purple-500 to-pink-500 h-full rounded-full" style={{width: cs.hype.includes('Extreme') ? '98%' : cs.hype.includes('Massive') ? '95%' : cs.hype.includes('Very') ? '88%' : '75%'}}></div>
                  </div>
                </div>
                <button onClick={() => toggleReminder(cs.id)} className={`w-full py-2.5 rounded-xl text-sm font-bold transition-all border ${ reminders[cs.id] ? 'bg-purple-600 border-purple-500 text-white' : 'bg-white/5 border-white/10 text-gray-300 hover:bg-purple-600/20 hover:border-purple-500/50' }`}>
                  {reminders[cs.id] ? '🔔 Reminder Set!' : '+ Set Reminder'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════
// OFFERS PAGE
// ═══════════════════════════════════════════════════════════
const OffersPage = ({ navigate, user, getPoints }) => {
  const [copiedCode, setCopiedCode] = useState(null);
  const copyCode = (code) => {
    navigator.clipboard?.writeText(code).catch(() => {});
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };
  const offers = [
    { code:'SAVE30', label:'30% OFF', type:'Weekend Special', desc:'Get 30% off on all bookings this weekend. Valid on all movies and screens.', color:'from-red-600 to-orange-500', expiry:'Valid till Sunday', minTickets:1 },
    { code:'FLAT200', label:'₹200 OFF', type:'Flash Deal', desc:'Instant ₹200 discount on bookings of ₹500 or more. Limited time!', color:'from-purple-600 to-pink-500', expiry:'Today Only', minTickets:2 },
    { code:'EARLYBIRD20', label:'20% OFF', type:'Morning Show', desc:'20% off on all shows before 12 PM. Perfect for early birds!', color:'from-blue-600 to-cyan-500', expiry:'Every Day', minTickets:1 },
    { code:'FAMILY30', label:'30% OFF', type:'Family Pack', desc:'Book 4+ tickets and save 30%. Perfect for family movie nights!', color:'from-green-600 to-emerald-500', expiry:'Weekends', minTickets:4 },
    { code:'NIGHTOWL15', label:'15% OFF', type:'Late Night', desc:'15% off on shows after 10 PM. For the night owls!', color:'from-indigo-600 to-violet-500', expiry:'Every Night', minTickets:1 },
    { code:'WELCOMEBACK15', label:'15% OFF', type:'Loyalty Reward', desc:'Exclusive comeback offer for users who haven\'t booked in 30+ days.', color:'from-yellow-600 to-amber-500', expiry:'Your account', minTickets:1 },
    { code:'FLAT150', label:'₹150 OFF', type:'New User', desc:'₹150 off on your first booking. Welcome to KaraiCini!', color:'from-teal-600 to-cyan-500', expiry:'First booking only', minTickets:1 },
    { code:'WEEKENDFUN', label:'10% OFF', type:'Combo Deal', desc:'10% off when you add snacks to your booking this weekend!', color:'from-rose-600 to-red-500', expiry:'Fri-Sun', minTickets:1 },
  ];
  const points = user ? getPoints(user.id) : 0;
  const tier = points >= 2000 ? { name:'Platinum', color:'text-cyan-400', icon:'💎', next:null } :
               points >= 1000 ? { name:'Gold', color:'text-yellow-400', icon:'🥇', next:2000 } :
               points >= 500  ? { name:'Silver', color:'text-gray-300', icon:'🥈', next:1000 } :
                                { name:'Bronze', color:'text-orange-400', icon:'🥉', next:500 };
  return (
    <div className="animate-fade-in space-y-10 pb-12">
      <div className="text-center py-8">
        <h1 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-orange-500 mb-3">🎁 Offers & Rewards</h1>
        <p className="text-gray-400">Exclusive deals, promo codes, and loyalty rewards for KaraiCini members.</p>
      </div>

      {/* Loyalty Points Card */}
      {user ? (
        <div className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-500/30 rounded-3xl p-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
            <div>
              <p className="text-yellow-400 font-bold text-sm mb-1">Your Loyalty Status</p>
              <div className="flex items-center gap-3">
                <span className="text-5xl">{tier.icon}</span>
                <div>
                  <h2 className="text-3xl font-black text-white">{tier.name} Member</h2>
                  <p className="text-yellow-300 font-bold text-lg">⭐ {points} Points</p>
                </div>
              </div>
              {tier.next && (
                <div className="mt-4">
                  <div className="flex justify-between text-xs mb-1">
                    <span className="text-gray-400">Progress to next tier</span>
                    <span className="text-yellow-400 font-bold">{points} / {tier.next} pts</span>
                  </div>
                  <div className="w-full bg-white/10 h-2 rounded-full overflow-hidden">
                    <div className="bg-gradient-to-r from-yellow-500 to-orange-500 h-full rounded-full transition-all" style={{width:`${Math.min(100,(points/tier.next)*100)}%`}}></div>
                  </div>
                  <p className="text-xs text-gray-500 mt-1">{tier.next - points} more points to unlock next tier</p>
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3 text-center">
              <div className="bg-white/10 border border-white/10 rounded-2xl p-4">
                <p className="text-2xl font-black text-white">{KC.BOOKINGS.filter(b=>b.userId===user.id).length}</p>
                <p className="text-xs text-gray-400">Total Bookings</p>
              </div>
              <div className="bg-white/10 border border-white/10 rounded-2xl p-4">
                <p className="text-2xl font-black text-yellow-400">{points}</p>
                <p className="text-xs text-gray-400">Points Earned</p>
              </div>
            </div>
          </div>
          <div className="mt-6 p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl text-sm text-yellow-200">
            💡 Earn <strong>10 points</strong> per ticket booked. Redeem <strong>100 points = ₹10 discount</strong> on your next booking!
          </div>
        </div>
      ) : (
        <div className="bg-gradient-to-r from-yellow-600/10 to-orange-600/10 border border-yellow-500/20 rounded-3xl p-8 text-center">
          <div className="text-5xl mb-4">⭐</div>
          <h2 className="text-2xl font-black text-white mb-2">Join & Earn Loyalty Points!</h2>
          <p className="text-gray-400 mb-4">Sign up to earn points on every booking and unlock exclusive tier rewards.</p>
          <button onClick={() => {}} className="btn-primary px-8 py-3">Sign In to Earn Points</button>
        </div>
      )}

      {/* Promo Codes Grid */}
      <div>
        <h2 className="text-2xl font-bold mb-6">🏷️ Active Promo Codes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {offers.map(o => (
            <div key={o.code} className="glass border border-white/10 rounded-2xl overflow-hidden hover:border-white/20 transition-all">
              <div className={`bg-gradient-to-r ${o.color} p-5`}>
                <div className="flex justify-between items-start">
                  <div>
                    <span className="text-xs font-bold bg-white/20 px-2 py-0.5 rounded text-white uppercase">{o.type}</span>
                    <div className="text-4xl font-black text-white mt-2">{o.label}</div>
                  </div>
                  <span className="text-3xl opacity-40">🎁</span>
                </div>
              </div>
              <div className="p-5">
                <p className="text-sm text-gray-300 mb-3">{o.desc}</p>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-black/40 border border-white/10 rounded-lg px-4 py-2 font-mono font-bold text-white tracking-widest text-sm">{o.code}</div>
                  <button onClick={() => copyCode(o.code)} className={`px-4 py-2 rounded-lg text-sm font-bold transition-all ${ copiedCode === o.code ? 'bg-green-500 text-white' : 'bg-white/10 hover:bg-white/20 text-white' }`}>
                    {copiedCode === o.code ? '✓ Copied!' : 'Copy'}
                  </button>
                </div>
                <div className="flex justify-between mt-3">
                  <span className="text-[10px] text-gray-500">🕐 {o.expiry}</span>
                  <span className="text-[10px] text-gray-500">Min. {o.minTickets} ticket(s)</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════
// USER PROFILE PAGE
// ═══════════════════════════════════════════════════════════
const UserProfilePage = ({ navigate, user, getPoints, addPoints, setShowAuth, setAuthMode }) => {
  const [editMode, setEditMode] = useState(false);
  const [editName, setEditName] = useState(user?.name || '');
  const [editLangs, setEditLangs] = useState(user?.prefLangs || []);
  const [activeTab, setActiveTab] = useState('overview');

  if (!user) return (
    <div className="flex flex-col items-center justify-center min-h-[50vh] gap-6">
      <div className="text-7xl">👤</div>
      <h2 className="text-3xl font-black">Sign In to View Profile</h2>
      <p className="text-gray-400">Access your bookings, loyalty points, and personalized settings.</p>
      <button onClick={() => { setAuthMode('login'); setShowAuth(true); }} className="btn-primary px-8 py-3 text-lg">Sign In</button>
    </div>
  );

  const points = getPoints(user.id);
  const myBookings = KC.BOOKINGS.filter(b => b.userId === user.id);
  const totalSpent = myBookings.reduce((s,b) => s + (b.grandTotal||0), 0);
  const tier = points >= 2000 ? {name:'Platinum', icon:'💎', color:'text-cyan-400', bg:'from-cyan-600/20 to-blue-600/20', border:'border-cyan-500/30'} :
               points >= 1000 ? {name:'Gold', icon:'🥇', color:'text-yellow-400', bg:'from-yellow-600/20 to-orange-600/20', border:'border-yellow-500/30'} :
               points >= 500  ? {name:'Silver', icon:'🥈', color:'text-gray-300', bg:'from-gray-600/20 to-gray-500/20', border:'border-gray-500/30'} :
                                {name:'Bronze', icon:'🥉', color:'text-orange-400', bg:'from-orange-600/20 to-red-600/20', border:'border-orange-500/30'};

  const badges = [
    { icon:'🎬', name:'First Booking', desc:'Completed your first movie booking', earned: myBookings.length >= 1 },
    { icon:'🍿', name:'Snack Lover', desc:'Added snacks to 3+ bookings', earned: myBookings.filter(b=>b.snacks?.length>0).length >= 1 },
    { icon:'🌙', name:'Night Owl', desc:'Booked a show after 10 PM', earned: myBookings.some(b=>(b.showTime||'').includes('10:30 PM')) },
    { icon:'⭐', name:'Loyal Fan', desc:'Earned 500+ loyalty points', earned: points >= 500 },
    { icon:'🚗', name:'VIP Parker', desc:'Used parking reservation', earned: myBookings.some(b=>b.parking) },
    { icon:'💎', name:'Elite Member', desc:'Reached Platinum tier', earned: points >= 2000 },
  ];

  const saveProfile = () => {
    const u = KC.USERS.find(u2 => u2.id === user.id);
    if (u) { u.name = editName; u.prefLangs = editLangs; if(KC.saveUsers) KC.saveUsers(); }
    setEditMode(false);
    alert('Profile updated successfully!');
  };

  const tabs = ['overview','bookings','badges','settings'];

  return (
    <div className="animate-fade-in pb-12 space-y-6">
      {/* Profile Header */}
      <div className={`bg-gradient-to-r ${tier.bg} border ${tier.border} rounded-3xl p-8`}>
        <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
          <div className="relative">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-red-500 to-orange-500 flex items-center justify-center text-5xl font-black shadow-[0_0_30px_rgba(244,63,94,0.4)]">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="absolute -bottom-2 -right-2 text-2xl">{tier.icon}</div>
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap">
              <h1 className="text-3xl font-black text-white">{user.name}</h1>
              <span className={`text-sm font-bold px-3 py-1 rounded-full bg-white/10 ${tier.color}`}>{tier.name} Member</span>
            </div>
            <p className="text-gray-400 mt-1">{user.email}</p>
            <div className="flex gap-6 mt-4 flex-wrap">
              <div>
                <p className="text-2xl font-black text-white">{points}</p>
                <p className="text-xs text-gray-400">Loyalty Points</p>
              </div>
              <div>
                <p className="text-2xl font-black text-white">{myBookings.length}</p>
                <p className="text-xs text-gray-400">Total Bookings</p>
              </div>
              <div>
                <p className="text-2xl font-black text-white">₹{totalSpent.toLocaleString()}</p>
                <p className="text-xs text-gray-400">Total Spent</p>
              </div>
              <div>
                <p className="text-2xl font-black text-white">{badges.filter(b=>b.earned).length}</p>
                <p className="text-xs text-gray-400">Badges Earned</p>
              </div>
            </div>
          </div>
          <button onClick={() => setEditMode(!editMode)} className="btn-secondary text-sm px-4 py-2">✏️ Edit Profile</button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 border-b border-white/10 pb-0">
        {tabs.map(t => (
          <button key={t} onClick={() => setActiveTab(t)} className={`capitalize px-5 py-3 text-sm font-bold border-b-2 transition-all ${ activeTab === t ? 'border-red-500 text-white' : 'border-transparent text-gray-400 hover:text-white' }`}>{t}</button>
        ))}
      </div>

      {/* Overview Tab */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {editMode && (
            <div className="glass border border-white/10 rounded-2xl p-6 space-y-4">
              <h3 className="font-bold text-lg">✏️ Edit Profile</h3>
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-1">Display Name</label>
                <input value={editName} onChange={e=>setEditName(e.target.value)} className="input-field" />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider block mb-2">Preferred Languages</label>
                <div className="flex flex-wrap gap-2">
                  {['English','Hindi','Tamil','Telugu','Malayalam','Kannada'].map(l => (
                    <button key={l} onClick={() => setEditLangs(prev => prev.includes(l) ? prev.filter(x=>x!==l) : [...prev,l])} className={`px-3 py-1.5 rounded-lg text-xs font-bold border transition-all ${ editLangs.includes(l) ? 'bg-red-600 border-red-500 text-white' : 'bg-white/5 border-white/10 text-gray-400 hover:text-white' }`}>{l}</button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3">
                <button onClick={saveProfile} className="btn-primary px-6 py-2 text-sm">Save Changes</button>
                <button onClick={() => setEditMode(false)} className="btn-secondary px-6 py-2 text-sm">Cancel</button>
              </div>
            </div>
          )}
          {/* Recent Bookings Preview */}
          <div className="glass border border-white/10 rounded-2xl p-6">
            <h3 className="font-bold text-lg mb-4">Recent Activity</h3>
            {myBookings.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <div className="text-5xl mb-3">🎟️</div>
                <p>No bookings yet. <button onClick={() => navigate('movies')} className="text-red-400 underline">Book your first movie!</button></p>
              </div>
            ) : (
              <div className="space-y-3">
                {myBookings.slice(-3).reverse().map(b => (
                  <div key={b.id} className="flex items-center justify-between p-3 bg-white/5 rounded-xl border border-white/5">
                    <div>
                      <p className="font-bold text-sm text-white">{b.movieTitle}</p>
                      <p className="text-xs text-gray-400">{b.showDate} · {b.showTime} · {b.seats?.length} seat(s)</p>
                    </div>
                    <div className="text-right">
                      <p className="text-red-400 font-bold">₹{b.grandTotal}</p>
                      <p className={`text-[10px] font-bold ${b.status==='cancelled'?'text-red-400':'text-green-400'}`}>{b.status||'Confirmed'}</p>
                    </div>
                  </div>
                ))}
                <button onClick={() => navigate('dashboard')} className="text-sm text-red-400 font-bold hover:text-red-300">View all bookings →</button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Bookings Tab */}
      {activeTab === 'bookings' && (
        <div className="space-y-3">
          {myBookings.length === 0 ? (
            <div className="text-center py-16 text-gray-500">
              <div className="text-6xl mb-4">🎟️</div>
              <h3 className="text-xl font-bold mb-2">No Bookings Yet</h3>
              <button onClick={() => navigate('movies')} className="btn-primary mt-4 px-8 py-3">Browse Movies</button>
            </div>
          ) : (
            myBookings.slice().reverse().map(b => (
              <div key={b.id} className="glass border border-white/10 rounded-2xl p-5 flex justify-between items-center gap-4">
                <div>
                  <h3 className="font-bold text-base text-white">{b.movieTitle}</h3>
                  <p className="text-xs text-gray-400 mt-0.5">{b.showDate} · {b.showTime} · Seats: {b.seats?.join(', ')}</p>
                  <p className="text-xs text-gray-500 mt-0.5">Booking ID: {b.id}</p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-red-400 font-black text-lg">₹{b.grandTotal}</p>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${ b.status==='cancelled' ? 'bg-red-500/20 text-red-400' : 'bg-green-500/20 text-green-400' }`}>{b.status||'Confirmed'}</span>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* Badges Tab */}
      {activeTab === 'badges' && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-5">
          {badges.map((b,i) => (
            <div key={i} className={`glass border rounded-2xl p-6 text-center transition-all ${ b.earned ? 'border-yellow-500/40 bg-yellow-500/5' : 'border-white/5 opacity-40 grayscale' }`}>
              <div className="text-5xl mb-3">{b.icon}</div>
              <h3 className="font-bold text-white mb-1">{b.name}</h3>
              <p className="text-xs text-gray-400">{b.desc}</p>
              {b.earned && <div className="mt-3 text-xs text-yellow-400 font-bold">✅ Earned!</div>}
            </div>
          ))}
        </div>
      )}

      {/* Settings Tab */}
      {activeTab === 'settings' && (
        <div className="glass border border-white/10 rounded-2xl p-6 space-y-5">
          <h3 className="font-bold text-lg">⚙️ Account Settings</h3>
          <div className="space-y-4">
            <div className="flex justify-between items-center py-3 border-b border-white/5">
              <div>
                <p className="text-sm font-bold text-white">Email Notifications</p>
                <p className="text-xs text-gray-400">Receive booking confirmations and offers</p>
              </div>
              <div className="w-12 h-6 bg-red-500 rounded-full flex items-center justify-end px-1 cursor-pointer"><div className="w-4 h-4 bg-white rounded-full"></div></div>
            </div>
            <div className="flex justify-between items-center py-3 border-b border-white/5">
              <div>
                <p className="text-sm font-bold text-white">Push Notifications</p>
                <p className="text-xs text-gray-400">Show reminders and exclusive deals</p>
              </div>
              <div className="w-12 h-6 bg-red-500 rounded-full flex items-center justify-end px-1 cursor-pointer"><div className="w-4 h-4 bg-white rounded-full"></div></div>
            </div>
            <div className="flex justify-between items-center py-3 border-b border-white/5">
              <div>
                <p className="text-sm font-bold text-white">AI Recommendations</p>
                <p className="text-xs text-gray-400">Let AI personalize your movie feed</p>
              </div>
              <div className="w-12 h-6 bg-red-500 rounded-full flex items-center justify-end px-1 cursor-pointer"><div className="w-4 h-4 bg-white rounded-full"></div></div>
            </div>
            <div className="pt-4">
              <p className="text-xs text-gray-500 mb-2">Account: <span className="text-white">{user.email}</span></p>
              {user.role === 'admin' && <p className="text-xs text-red-400 font-bold">🛡️ Admin Account — Full system access</p>}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const AIAssistant = () => {
  const [open, setOpen] = useState(false);
  const [msg, setMsg] = useState('');
  const [chat, setChat] = useState([
    { role: 'ai', text: 'Hi! I am your CineAI Assistant. Need help picking a movie, reserving seats, or navigating the platform?' }
  ]);

  const send = (e) => {
    e.preventDefault();
    if(!msg.trim()) return;
    const newChat = [...chat, { role: 'user', text: msg }];
    setChat(newChat);
    setMsg('');
    
    // Simulate AI response
    setTimeout(() => {
      let reply = "I'm currently in demo mode, but I can help you navigate to Movies or check out the AI Seat Recommendations during booking!";
      if(msg.toLowerCase().includes('stress')) reply = "I recommend checking out our Comedy section. Try our AI Mood Matcher on the Movies page!";
      if(msg.toLowerCase().includes('seat')) reply = "Our platform uses AI to recommend seats based on acoustic centers, screen angles, and real-time occupancy. Try it during booking!";
      
      setChat([...newChat, { role: 'ai', text: reply }]);
    }, 800);
  };

  return (
    <>
      <button 
        onClick={() => setOpen(!open)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-full shadow-[0_0_20px_rgba(79,70,229,0.5)] flex items-center justify-center text-2xl hover:scale-110 transition-transform z-[100] border-2 border-white/20"
      >
        ✨
      </button>

      {open && (
        <div className="fixed bottom-24 right-6 w-80 glass-dark border border-white/10 rounded-2xl shadow-2xl flex flex-col z-[100] overflow-hidden animate-fade-in h-[400px]">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-600 p-4 font-bold flex justify-between items-center shadow-md">
            <span className="flex items-center gap-2">✨ CineAI Assistant</span>
            <button onClick={() => setOpen(false)} className="hover:text-gray-300">✕</button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-black/40">
            {chat.map((c, i) => (
              <div key={i} className={`flex ${c.role==='user'?'justify-end':'justify-start'}`}>
                <div className={`max-w-[80%] p-3 rounded-xl text-sm ${c.role==='user'?'bg-red-600 rounded-br-none':'bg-white/10 rounded-bl-none border border-white/5'}`}>
                  {c.text}
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={send} className="p-3 border-t border-white/10 flex gap-2 bg-black/60">
            <input 
              type="text" 
              value={msg}
              onChange={e=>setMsg(e.target.value)}
              placeholder="Ask me anything..." 
              className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 transition-colors"
            />
            <button className="bg-blue-600 hover:bg-blue-500 text-white p-2 rounded-lg transition-colors">🚀</button>
          </form>
        </div>
      )}
    </>
  );
};

const AIVoiceBooking = ({ navigate }) => {
  const [active, setActive] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [status, setStatus] = useState('Click to Speak');
  const [error, setError] = useState(null);
  
  const recognitionRef = React.useRef(null);
  
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const rec = new SpeechRecognition();
      rec.continuous = false;
      rec.interimResults = false;
      rec.lang = 'en-US';
      
      rec.onstart = () => {
        setStatus('Listening...');
        setError(null);
      };
      
      rec.onerror = (e) => {
        console.error(e);
        setError('Voice command failed. Please try again.');
        setStatus('Click to Speak');
        setActive(false);
      };
      
      rec.onend = () => {
        setStatus('Click to Speak');
        setActive(false);
      };
      
      rec.onresult = (event) => {
        const text = event.results[0][0].transcript;
        setTranscript(text);
        processCommand(text);
      };
      
      recognitionRef.current = rec;
    }
  }, []);
  
  const speakText = (text) => {
    if (window.speechSynthesis) {
      const utterance = new SpeechSynthesisUtterance(text);
      window.speechSynthesis.speak(utterance);
    }
  };

  const processCommand = (text) => {
    setStatus('Processing...');
    const t = text.toLowerCase();
    
    let matchedMovie = null;
    for (let m of KC.MOVIES) {
      if (t.includes(m.title.toLowerCase()) || (m.title.toLowerCase().split(' ')[0].length > 3 && t.includes(m.title.toLowerCase().split(' ')[0]))) {
        matchedMovie = m;
        break;
      }
    }
    
    setTimeout(() => {
      if (matchedMovie) {
        speakText(`Booking seats for ${matchedMovie.title}. Redirecting you now.`);
        setStatus('Success!');
        
        const shows = KC.generateShows(matchedMovie.id);
        const targetShow = shows[0];
        
        setTimeout(() => {
          setActive(false);
          if (targetShow) {
            navigate('book', { showId: targetShow.id });
          } else {
            navigate('movie', { id: matchedMovie.id });
          }
        }, 1500);
      } else {
        speakText("Sorry, I couldn't identify the movie. Try saying Book tickets for Deadpool or Moana.");
        setStatus('Movie not found');
        setError("Could not match movie. Try: 'Book tickets for Moana'");
      }
    }, 1500);
  };
  
  const startListening = () => {
    if (!recognitionRef.current) {
      setActive(true);
      setStatus('Listening (Simulated)...');
      setTimeout(() => {
        const mockPhrases = [
          "Book tickets for Moana 2",
          "I want to watch Gladiator 2 tomorrow",
          "Search for Deadpool and Wolverine",
          "Book show for Dune part two"
        ];
        const phrase = mockPhrases[Math.floor(Math.random() * mockPhrases.length)];
        setTranscript(phrase);
        processCommand(phrase);
      }, 3000);
      return;
    }
    
    try {
      setActive(true);
      recognitionRef.current.start();
    } catch (e) {
      console.error(e);
      recognitionRef.current.stop();
    }
  };
  
  return (
    <>
      <button 
        onClick={startListening}
        className="fixed bottom-6 right-24 w-14 h-14 bg-gradient-to-r from-red-600 to-orange-500 rounded-full shadow-[0_0_20px_rgba(239,68,68,0.5)] flex items-center justify-center text-2xl hover:scale-110 transition-transform z-[100] border-2 border-white/20"
        title="AI Voice Booking"
      >
        🎙️
      </button>
      
      {active && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center z-[110] animate-fade-in">
          <div className="glass-dark p-8 rounded-3xl w-full max-w-md text-center relative border border-white/10 shadow-2xl">
            <button onClick={() => { if(recognitionRef.current) recognitionRef.current.stop(); setActive(false); }} className="absolute top-4 right-4 text-xl text-gray-400 hover:text-white transition-colors">✕</button>
            <h2 className="text-2xl font-black mb-2 text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-orange-500">🎙️ CineAI Voice Booking</h2>
            <p className="text-xs text-gray-400 mb-6">Say something like: "Book tickets for Deadpool" or "I want to watch Moana 2"</p>
            
            <div className="flex justify-center items-center h-24 mb-6">
              {status.includes('Listening') ? (
                <div className="flex items-center gap-1">
                  <div className="w-1.5 bg-red-500 rounded-full animate-bounce h-12" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-1.5 bg-orange-500 rounded-full animate-bounce h-16" style={{ animationDelay: '0.2s' }}></div>
                  <div className="w-1.5 bg-yellow-500 rounded-full animate-bounce h-20" style={{ animationDelay: '0.3s' }}></div>
                  <div className="w-1.5 bg-orange-500 rounded-full animate-bounce h-16" style={{ animationDelay: '0.4s' }}></div>
                  <div className="w-1.5 bg-red-500 rounded-full animate-bounce h-12" style={{ animationDelay: '0.5s' }}></div>
                </div>
              ) : (
                <div className="w-16 h-16 bg-white/5 rounded-full flex items-center justify-center border border-white/10 animate-pulse text-3xl">🎙️</div>
              )}
            </div>
            
            <p className="text-lg font-bold text-white mb-2 min-h-[1.75rem]">
              {transcript ? `"${transcript}"` : 'Listening...'}
            </p>
            
            <div className="text-sm font-semibold text-gray-400">
              Status: <span className="text-red-400">{status}</span>
            </div>
            
            {error && (
              <p className="text-xs text-red-500 mt-4 bg-red-500/10 border border-red-500/20 p-2 rounded-lg">{error}</p>
            )}
          </div>
        </div>
      )}
    </>
  );
};

// Export to window for global access between separate Babel scripts
window.App = App;
window.HomePage = HomePage;
window.MovieCard = MovieCard;
window.MoviesPage = MoviesPage;
window.MovieDetails = MovieDetails;
window.AIAssistant = AIAssistant;
window.AIVoiceBooking = AIVoiceBooking;

